/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/**
 * Common logic shared by RemoteSettingsWorker.js (Worker) and the main thread.
 */

export var SharedUtils = {
  /**
   * Check that the specified content matches the expected size and SHA-256 hash.
   *
   * @param {ArrayBuffer} buffer binary content
   * @param {number} size expected file size
   * @param {string} size expected file SHA-256 as hex string
   * @returns {boolean}
   */
  async checkContentHash(buffer, size, hash) {
    const bytes = new Uint8Array(buffer);
    // Has expected size? (saves computing hash)
    if (bytes.length !== size) {
      return false;
    }
    // Has expected content?
    const hashBuffer = await crypto.subtle.digest("SHA-256", bytes);
    const hashBytes = new Uint8Array(hashBuffer);
    const toHex = b => b.toString(16).padStart(2, "0");
    const hashStr = Array.from(hashBytes, toHex).join("");
    return hashStr == hash;
  },

  /**
   * Load (from disk) the JSON file distributed with the release for this collection.
   *
   * @param {string}  bucket
   * @param {string}  collection
   * @param {string}  allowedCollections
   * @param {string}  allowedCollectionsFromDump
   */
  async loadJSONDump(bucket, collection, allowedCollections, allowedCollectionsFromDump) {
    if (!this.isCollectionAllowedFromDump(bucket, collection, allowedCollections, allowedCollectionsFromDump)) {
      return { data: null, timestamp: null };
    }
    // When using the preview bucket, we still want to load the main dump.
    // But we store it locally in the preview bucket.
    const jsonBucket = bucket.replace("-preview", "");
    const fileURI = `resource://app/defaults/settings/${jsonBucket}/${collection}.json`;
    let response;
    try {
      response = await fetch(fileURI);
    } catch (e) {
      // Return null if file is missing.
      return { data: null, timestamp: null };
    }
    // Will throw if JSON is invalid.
    return response.json();
  },

  /**
   * Internal code to determine whether the bucket and collection are allowed to
   * be loaded by the remote settings client for a given list of allowed
   * bucket/collection combinations.
   * @param {string} bucket
   * @param {string} collection
   * @param {Array<string>} allowedCollections
   * @returns {boolean} whether the bucket and collection are allowed to load
   */
  _isCollectionAllowedInternal(bucket, collection, allowedCollections) {
    return (
      allowedCollections.includes(`${bucket}/${collection}`) ||
      allowedCollections.includes(`${bucket}/*`) ||
      allowedCollections.includes("*")
    );
  },

  /**
   * Determines whether the bucket and collection are allowed to be loaded by the
   * remote settings client.
   * @param {string} bucket
   * @param {string} collection
   * @param {string} allowedCollections
   * @returns {boolean} whether the bucket and collection are allowed to load
   */
  isCollectionAllowed(bucket, collection, allowedCollections) {
    if (
      this._isCollectionAllowedInternal(
        bucket,
        collection,
        allowedCollections
      )
    ) {
      return true;
    }
    console.warn(
      `Connection attempt to RS collection "${bucket}/${collection}" was blocked/filtered.`
    );
    return false;
  },

  /**
   * Determines whether the bucket and collection are allowed to be loaded from
   * an in-tree remote settings dump.
   * @param {string} bucket
   * @param {string} collection
   * @param {string} allowedCollections
   * @param {string} allowedCollectionsFromDump
   * @returns {boolean} whether the bucket and collection are allowed to load
   */
  isCollectionAllowedFromDump(bucket, collection, allowedCollections, allowedCollectionsFromDump) {
    if (
      this._isCollectionAllowedInternal(
        bucket,
        collection,
        allowedCollectionsFromDump
      ) ||
      this._isCollectionAllowedInternal(
        bucket,
        collection,
        allowedCollections
      )
    ) {
      return true;
    }
    console.warn(
      `Access attempt to RS collection "${bucket}/${collection}" from local dump was blocked/filtered.`
    );
    return false;
  },
};
