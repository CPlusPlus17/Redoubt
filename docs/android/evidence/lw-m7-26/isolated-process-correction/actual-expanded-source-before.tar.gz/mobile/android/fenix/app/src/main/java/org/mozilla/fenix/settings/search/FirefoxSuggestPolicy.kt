/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.fenix.settings.search

import android.content.Context
import android.content.SharedPreferences
import androidx.preference.Preference
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import mozilla.components.feature.fxsuggest.FxSuggestAdmission
import mozilla.components.feature.fxsuggest.FxSuggestChoices
import mozilla.components.feature.fxsuggest.FxSuggestIngestionScheduler
import mozilla.components.feature.fxsuggest.GlobalFxSuggestDependencyProvider
import org.mozilla.fenix.R
import org.mozilla.fenix.utils.Settings

/** Actual Android policy reader; ordinary search-engine suggestions use different keys. */
object FirefoxSuggestPolicy {
    private var preferences: SharedPreferences? = null
    private var listener: SharedPreferences.OnSharedPreferenceChangeListener? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** Called from attachBaseContext before persisted workers can revive Suggest work. */
    fun initialize(context: Context) {
        listener?.let { preferences?.unregisterOnSharedPreferenceChangeListener(it) }
        val preferences = context.getSharedPreferences(Settings.FENIX_PREFERENCES, Context.MODE_PRIVATE)
        val master = context.getString(R.string.pref_key_enable_fxsuggest)
        val web = context.getString(R.string.pref_key_show_nonsponsored_suggestions)
        val sponsored = context.getString(R.string.pref_key_show_sponsored_suggestions)
        val online = context.getString(R.string.pref_key_search_optimization_cards)
        val onlineFeature = context.getString(R.string.pref_key_search_optimization_feature)
        val keys = setOf(master, web, sponsored, online, onlineFeature)
        this.preferences = preferences
        FxSuggestAdmission.configure {
            FxSuggestChoices(
                enabled = preferences.getBoolean(master, false),
                web = preferences.getBoolean(web, false),
                sponsored = preferences.getBoolean(sponsored, false),
                online = preferences.getBoolean(online, false) && preferences.getBoolean(onlineFeature, true),
            )
        }
        listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == null || key in keys) {
                FxSuggestAdmission.choicesChanged()
                if (!FxSuggestAdmission.snapshot().choices.localEnabled) {
                    GlobalFxSuggestDependencyProvider.cancelActiveReads()
                }
            }
        }.also { preferences.registerOnSharedPreferenceChangeListener(it) }
    }

    /** Wire both normal and existing debug controls to the same real service boundary. */
    fun updater(onChanged: () -> Unit = {}): Preference.OnPreferenceChangeListener =
        Preference.OnPreferenceChangeListener { preference, value ->
            val enabled = value as? Boolean ?: return@OnPreferenceChangeListener false
            val context = preference.context
            val editor = context.getSharedPreferences(Settings.FENIX_PREFERENCES, Context.MODE_PRIVATE)
                .edit().putBoolean(preference.key, enabled)
            if (enabled && preference.key == context.getString(R.string.pref_key_search_optimization_cards)) {
                // A new explicit online opt-in also enables its formerly hidden availability flag.
                editor.putBoolean(context.getString(R.string.pref_key_search_optimization_feature), true)
            }
            editor.apply()
            onChoiceChanged(context.applicationContext ?: context)
            onChanged()
            true
        }

    fun onChoiceChanged(context: Context) {
        val admission = FxSuggestAdmission.snapshot()
        val scheduler = FxSuggestIngestionScheduler(context)
        if (admission.choices.localEnabled) {
            scheduler.startPeriodicIngestion()
            scope.launch {
                if (FxSuggestAdmission.isCurrent(admission)) {
                    GlobalFxSuggestDependencyProvider.storageIfEnabled()?.runStartupIngestion()
                }
            }
        } else {
            scheduler.stopPeriodicIngestion()
            GlobalFxSuggestDependencyProvider.cancelActiveReads()
        }
    }
}
