/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.fenix.gecko

import android.content.Context
import androidx.annotation.VisibleForTesting
import mozilla.components.browser.engine.gecko.autofill.GeckoAutocompleteStorageDelegate
import mozilla.components.browser.engine.gecko.ext.toContentBlockingSetting
import mozilla.components.concept.engine.EngineSession.TrackingProtectionPolicy
import mozilla.components.concept.storage.CreditCardsAddressesStorage
import mozilla.components.concept.storage.LoginsStorage
import mozilla.components.experiment.NimbusExperimentDelegate
import mozilla.components.lib.crash.handler.CrashHandlerService
import mozilla.components.service.sync.autofill.GeckoCreditCardsAddressesStorageDelegate
import mozilla.components.service.sync.logins.GeckoLoginStorageDelegate
import org.mozilla.fenix.Config
import org.mozilla.fenix.ext.components
import org.mozilla.fenix.nimbus.FxNimbus
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings

object GeckoProvider {
    private var runtime: GeckoRuntime? = null

    @Synchronized
    fun getOrCreateRuntime(
        context: Context,
        autofillStorage: Lazy<CreditCardsAddressesStorage>,
        loginStorage: Lazy<LoginsStorage>,
        trackingProtectionPolicy: TrackingProtectionPolicy,
    ): GeckoRuntime {
        if (runtime == null) {
            runtime =
                createRuntime(context, autofillStorage, loginStorage, trackingProtectionPolicy)
        }

        return runtime!!
    }

    private fun createRuntime(
        context: Context,
        autofillStorage: Lazy<CreditCardsAddressesStorage>,
        loginStorage: Lazy<LoginsStorage>,
        policy: TrackingProtectionPolicy,
    ): GeckoRuntime {
        val runtimeSettings = createRuntimeSettings(context, policy)

        val settings = context.components.settings
        if (!settings.shouldUseAutoSize) {
            runtimeSettings.automaticFontSizeAdjustment = false
            val fontSize = settings.fontSizeFactor
            runtimeSettings.fontSizeFactor = fontSize
        }

        val geckoRuntime = GeckoRuntime.create(context, runtimeSettings)

        geckoRuntime.autocompleteStorageDelegate = GeckoAutocompleteStorageDelegate(
            GeckoCreditCardsAddressesStorageDelegate(
                storage = autofillStorage,
                isCreditCardAutofillEnabled = { context.components.settings.shouldAutofillCreditCardDetails },
                isAddressAutofillEnabled = { context.components.settings.shouldAutofillAddressDetails },
            ),
            GeckoLoginStorageDelegate(
                loginStorage = loginStorage,
                isLoginAutofillEnabled = { context.components.settings.shouldAutofillLogins },
            ),
        )

        // LibreWolf (patches/android/no-crashreporter.patch): no crashPullDelegate.  Setting one
        // makes GeckoView send "GeckoView:CrashPullController.Delegate:Attached", which is what
        // starts RemoteSettingsCrashPull -- the Remote Settings channel by which Mozilla asks a
        // particular user to upload particular pending minidumps.  We have no upload path and no
        // minidumps (--disable-crashreporter), and RemoteSettingsCrashPull.sys.mjs is not even
        // packaged (toolkit/components/crashes/moz.build gates it on MOZ_CRASHREPORTER, and the
        // built omni.ja does not contain it), so the delegate could only ever have re-opened the
        // solicitation if the crash reporter were re-enabled.

        return geckoRuntime
    }

    @VisibleForTesting
    internal fun createRuntimeSettings(
        context: Context,
        policy: TrackingProtectionPolicy,
    ): GeckoRuntimeSettings {
        val builder = GeckoRuntimeSettings.Builder()
            .crashHandler(CrashHandlerService::class.java)
            .experimentDelegate(NimbusExperimentDelegate())
            .contentBlocking(
                policy.toContentBlockingSetting(
                    cookieBannerHandlingMode = context.components.settings.getCookieBannerHandling(),
                    cookieBannerHandlingModePrivateBrowsing = context.components.settings
                        .getCookieBannerHandlingPrivateMode(),
                    cookieBannerHandlingDetectOnlyMode =
                    context.components.settings.shouldEnableCookieBannerDetectOnly,
                    cookieBannerGlobalRulesEnabled =
                    context.components.settings.shouldEnableCookieBannerGlobalRules,
                    cookieBannerGlobalRulesSubFramesEnabled =
                    context.components.settings.shouldEnableCookieBannerGlobalRulesSubFrame,
                    queryParameterStripping = false,
                    queryParameterStrippingPrivateBrowsing = false,
                    queryParameterStrippingAllowList = "",
                    queryParameterStrippingStripList = "",
                    allowListBaselineTrackingProtection =
                    context.components.settings.strictAllowListBaselineTrackingProtection,
                    allowListConvenienceTrackingProtection =
                    context.components.settings.strictAllowListConvenienceTrackingProtection,
                    safeBrowsingGlobalCacheEnabled = Config.channel.isNightlyOrDebug,
                    safeBrowsingRealTimeEnabled = Config.channel.isNightlyOrDebug,
                    safeBrowsingRealTimeSimulationEnabled = Config.channel.isNightlyOrDebug,
                    safeBrowsingRealTimeSimulationHitProbability = 5,
                    safeBrowsingRealTimeSimulationCacheTTLSec = 300,
                    safeBrowsingRealTimeSimulationNegativeCacheEnabled = false,
                    safeBrowsingRealTimeSimulationNegativeCacheTTLSec = 300,
                ),
            )
            .consoleOutput(context.components.settings.enableGeckoLogs)
            .debugLogging(Config.channel.isDebug || context.components.settings.enableGeckoLogs)
            // LibreWolf (LW-M4-09): about:config is enabled on every channel,
            // including release. Upstream gates it on beta/nightly/debug, which
            // leaves the shipping build with no way to inspect or change a pref;
            // LibreWolf's whole configuration story is prefs, so that gate has to
            // go. Hard-coded `true` rather than a Settings or Nimbus lookup for the
            // same reason LW-M5-02 hard-codes its two: the value must not be
            // lowerable by an experiment, a Fenix settings write or an upstream
            // default flip. Nothing about the page's own safety copy changes -- see
            // the patch header, which records that Android's about:config is
            // GeckoView's config.xhtml and has never had desktop's interstitial.
            .aboutConfigEnabled(true)
            .extensionsProcessEnabled(true)
            .extensionsWebAPIEnabled(true)
            .translationsOfferPopup(context.components.settings.offerTranslation)
            .crashPullNeverShowAgain(context.components.settings.crashPullNeverShowAgain)
            .setSameDocumentNavigationOverridesLoadType(
                FxNimbus.features.sameDocumentNavigationOverridesLoadType.value().enabled,
            )
            .setSameDocumentNavigationOverridesLoadTypeForceDisable(
                FxNimbus.features.sameDocumentNavigationOverridesLoadType.value().forceDisableUri,
            )
            // LibreWolf (LW-M5-02): both of these are forced on, and are deliberately
            // NOT read from Settings/Nimbus any more. Gecko's own content sandbox is
            // not compiled on Android (MOZ_SANDBOX is absent from the Android
            // config.status, so every security.sandbox.* pref is inert), so Android's
            // own per-process isolation is the only containment a content process
            // gets. That is a security decision and must not sit on a channel that a
            // remote experiment, a Fenix settings write or an upstream default flip
            // can lower.
            //
            // appZygoteProcessEnabled(true) is safe on every API level we ship to:
            // GeckoRuntimeSettings.Builder itself refuses it below SDK 29 (Android 10)
            // and stores false, and GeckoProcessType.determineContentProcessType()
            // re-checks SDK_INT, so an API 26-28 device silently falls back to plain
            // isolatedProcess (CONTENT_ISOLATED) instead of the zygote variant.
            .isolatedProcessEnabled(true)
            .appZygoteProcessEnabled(true)

        if (FxNimbus.features.fission.value().shouldUseNimbus) {
            builder
                .fissionEnabled(FxNimbus.features.fission.value().enabled)
        }

        return builder.build()
    }
}
