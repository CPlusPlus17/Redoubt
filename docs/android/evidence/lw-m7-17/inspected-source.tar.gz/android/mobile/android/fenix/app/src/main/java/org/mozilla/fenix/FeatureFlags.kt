/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.fenix

/**
 * A single source for setting feature flags that are mostly based on build type.
 */
object FeatureFlags {

    /**
     * Enables custom extension collection feature,
     * This feature does not only depend on this flag. It requires the AMO collection override to
     * be enabled which is behind the Secret Settings.
     * */
    val customExtensionCollectionFeature = Config.channel.isNightlyOrDebug || Config.channel.isBeta

    /**
     * Pull-to-refresh allows you to pull the web content down far enough to have the page to
     * reload.
     */
    const val PULL_TO_REFRESH_ENABLED = true

    /**
     * Allows users to enable Firefox Suggest.
     */
    const val FX_SUGGEST = true

    /**
     * LibreWolf (LW-M4-10): the Fenix onboarding flow is REMOVED, not switched off for debug
     * builds. Upstream computed this flag from `!Config.channel.isDebug`, i.e. the flow was
     * live on release, beta and nightly and only absent from debug builds; it is now a
     * compiled `false` on every channel.
     *
     * ⚠️ Setting this back to `true` does NOT bring the flow back, and is not a supported
     * configuration: `Settings.shouldShowOnboarding()` ignores both of its arguments,
     * `ContinuousOnboardingFeatureDefault.shouldShowContinuousOnboarding()` is false too, and
     * with them go the six onboarding cards (terms-of-service, default-browser,
     * add-search-widget, sync-sign-in, notification-permission, toolbar-placement) and the
     * default-browser SYSTEM prompt, which is raised only from OnboardingFragment.
     *
     * Named in SCREAMING_SNAKE_CASE like its `const val` neighbours above: ktlint's
     * standard:property-naming rule requires it, and the camelCase name upstream used was
     * legal only because upstream's declaration was not `const`.
     */
    const val ONBOARDING_FEATURE_ENABLED = false

    /**
     * Enables Firefox Labs.
     */
    const val FIREFOX_LABS = false
}
