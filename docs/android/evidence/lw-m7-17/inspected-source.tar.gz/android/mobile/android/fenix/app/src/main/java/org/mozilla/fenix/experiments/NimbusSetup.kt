/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.fenix.experiments

import android.content.Context
import mozilla.appservices.remotesettings.RemoteSettingsService
import mozilla.components.service.nimbus.NimbusApi
import mozilla.components.service.nimbus.NimbusAppInfo
import mozilla.components.service.nimbus.NimbusBuilder
import mozilla.components.service.nimbus.messaging.FxNimbusMessaging
import mozilla.components.service.nimbus.messaging.NimbusSystem
import mozilla.components.support.base.log.logger.Logger
import org.mozilla.experiments.nimbus.NimbusInterface
import org.mozilla.experiments.nimbus.internal.GeckoPrefHandler
import org.mozilla.experiments.nimbus.internal.NimbusException
import org.mozilla.experiments.nimbus.internal.NimbusServerSettings
import org.mozilla.fenix.BuildConfig
import org.mozilla.fenix.ext.components
import org.mozilla.fenix.messaging.CustomAttributeProvider
import org.mozilla.fenix.nimbus.FxNimbus
import org.mozilla.fenix.utils.Settings

/**
 * The maximum amount of time the app launch will be blocked to load experiments from disk.
 *
 * ⚠️ This value was decided from analyzing the Focus metrics (nimbus_initial_fetch) for the ideal
 * timeout. We should NOT change this value without collecting more metrics first.
 */
private const val TIME_OUT_LOADING_EXPERIMENT_FROM_DISK_MS = 200L

private val logger = Logger("service/Nimbus")

/**
 * Create the Nimbus singleton object for the Fenix app.
 */
fun createNimbus(
    context: Context,
    settings: Settings,
    urlString: String?,
    remoteSettingsService: RemoteSettingsService?,
    geckoPrefHandler: GeckoPrefHandler,
): NimbusApi {
    // These values can be used in the JEXL expressions when targeting experiments.
    val customTargetingAttributes = CustomAttributeProvider.getCustomTargetingAttributes(context)

    val isAppFirstRun = settings.isFirstNimbusRun
    if (isAppFirstRun) {
        settings.isFirstNimbusRun = false
    }

    val recordedNimbusContext = RecordedNimbusContext.create(
        context = context,
        isFirstRun = isAppFirstRun,
    )

    // LibreWolf: Nimbus has no server, and `remoteSettingsService` is ignored here.
    //
    // A null NimbusServerSettings is not "an endpoint that happens to be empty".
    // It changes which SettingsClient the Rust SDK constructs: create_client() in
    // components/nimbus/src/stateful/client/mod.rs builds a NullClient when this
    // is None, and only reaches RemoteSettingsService::make_client(collection)
    // in the Some(..) arm. So no remote-settings client for the experiment
    // collection is ever registered on the shared RemoteSettingsService, which
    // also means RemoteSettingsService::sync() -- the periodic worker in
    // mozilla.components.support.remotesettings -- has no experiment collection
    // among its active_clients() to sync. There is no periodic beacon left to
    // fingerprint on, and the compiled-in FML defaults become the only source of
    // feature configuration.
    //
    // Do not "restore" this by pointing it at a dead URL: a Custom URL still
    // produces a live RemoteSettingsClient and still emits requests.
    val serverSettings: NimbusServerSettings? = null

    // The name "fenix" here corresponds to the app_name defined for the family of apps
    // that encompasses all of the channels for the Fenix app.  This is defined upstream in
    // the telemetry system. For more context on where the app_name come from see:
    // https://probeinfo.telemetry.mozilla.org/v2/glean/app-listings
    // and
    // https://github.com/mozilla/probe-scraper/blob/master/repositories.yaml
    val appInfo = NimbusAppInfo(
        appName = "fenix",
        // Note: Using BuildConfig.BUILD_TYPE is important here so that it matches the value
        // passed into Glean. `Config.channel.toString()` turned out to be non-deterministic
        // and would mostly produce the value `Beta` and rarely would produce `beta`.
        channel = BuildConfig.BUILD_TYPE.let { if (it == "debug") "developer" else it },
        customTargetingAttributes = customTargetingAttributes,
    )

    return NimbusBuilder(context).apply {
        // LibreWolf: `urlString` (BuildConfig.NIMBUS_ENDPOINT) is ignored. It is
        // only read by AbstractNimbusBuilder.isLocalBuild(); it is NOT what the
        // SDK fetches from in 153, so setting it null is not on its own a fix.
        url = null
        errorReporter = context::reportError
        // LibreWolf: do not seed enrolments from res/raw/initial_experiments.json.
        // That file is a snapshot of live Mozilla experiment recipes (9 of them
        // targeting the release channel in 153.0), regenerated upstream by
        // taskcluster/docker/periodic-updates/scripts/periodic_file_updates.sh.
        // With no `.nimbus` endpoint file in the tree, BuildConfig.NIMBUS_ENDPOINT
        // is null, so AbstractNimbusBuilder.isLocalBuild() would be true and those
        // recipes would be applied on EVERY launch, not merely the first -- they
        // would override the FML defaults this task is meant to make authoritative.
        // Null here makes build() take the applyPendingExperiments() branch, and
        // with a NullClient nothing is ever pending.
        initialExperiments = null
        timeoutLoadingExperiment = TIME_OUT_LOADING_EXPERIMENT_FROM_DISK_MS
        sharedPreferences = settings.preferences
        isFirstRun = isAppFirstRun
        featureManifest = FxNimbus
        onFetchCallback = {
            settings.nimbusExperimentsFetched = true
        }
        recordedContext = recordedNimbusContext
        this.geckoPrefHandler = geckoPrefHandler
    }.build(appInfo, serverSettings).also { nimbusApi ->
        // LibreWolf: third barrier, at the Rust layer this time.
        // NimbusClient::fetch_experiments() consults DB_KEY_FETCH_ENABLED before
        // it asks the SettingsClient for anything, so this also covers fetch call
        // sites this patch does not edit -- notably
        // MessageNotificationWorker.setupNimbusMessaging()'s fetchExperiments().
        nimbusApi.setFetchEnabled(false)
        nimbusApi.recordIsReady(FxNimbus.features.nimbusIsReady.value().eventCount)
    }
}

private fun Context.reportError(message: String, e: Throwable) {
    if (BuildConfig.BUILD_TYPE == "debug") {
        logger.error("Nimbus error: $message", e)
    }
    if (e !is NimbusException || e.isReportableError()) {
        @Suppress("TooGenericExceptionCaught")
        try {
            this.components.analytics.crashReporter.submitCaughtException(e)
        } catch (e: Throwable) {
            logger.error(message, e)
        }
    }
}

/**
 * Classifies which errors we should forward to our crash reporter or not. We want to filter out the
 * non-reportable ones if we know there is no reasonable action that we can perform.
 *
 * This fix should be upstreamed as part of: https://github.com/mozilla/application-services/issues/4333
 */
fun NimbusException.isReportableError(): Boolean {
    return when (this) {
        is NimbusException.ClientException -> false
        else -> true
    }
}

/**
 * LibreWolf: permanently a no-op. Upstream this called `fetchExperiments()` on a
 * `refreshIntervalForeground` schedule, which is exactly the recurring beacon this
 * build must not have -- a periodic, network-visible request whose timing and TLS
 * fingerprint identify the browser even when the response is empty.
 *
 * The signature, including the [NimbusSystem] default argument, is kept so the one
 * caller (FenixApplication.onForeground) still compiles unedited; keeping this
 * file the only Kotlin one the patch touches keeps the rebase surface small.
 */
fun NimbusInterface.maybeFetchExperiments(
    settings: Settings,
    feature: NimbusSystem = FxNimbusMessaging.features.nimbusSystem.value(),
    currentTimeMillis: Long = System.currentTimeMillis(),
) {
    logger.debug("LibreWolf: Nimbus experiment fetching is disabled; not contacting any server")
}
