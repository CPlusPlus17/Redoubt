/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

const lazy = {};
ChromeUtils.defineESModuleGetters(lazy, {
  AppConstants: "resource://gre/modules/AppConstants.sys.mjs",
  setTimeout: "resource://gre/modules/Timer.sys.mjs",
  clearTimeout: "resource://gre/modules/Timer.sys.mjs",
});

const DATA_ROOT = "chrome://global/content/translations/android-data/";
const CATALOG_SIZE = 245592;
const CATALOG_HASH =
  "ce8c163e97d9d5b136cd673f7e63684dada00b45514442bf282b387174100d96";
const ATTACHMENT_ROOT = "https://firefox-settings-attachments.cdn.mozilla.net/";
const MAX_COMPRESSED = 48 * 1024 * 1024;
const MAX_DECOMPRESSED = 64 * 1024 * 1024;
const OPERATION_TIMEOUT_MS = 15 * 60 * 1000;
const TRANSFER_TIMEOUT_MS = 60 * 1000;
const HASH = /^[a-f0-9]{64}$/;
const UUID = /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/;

function abortError() {
  return new DOMException("Translation download was cancelled", "AbortError");
}
function checkSignal(signal) {
  if (signal?.aborted) {
    throw abortError();
  }
}
async function abortable(promise, signal) {
  let abort;
  const cancelled = new Promise((_, reject) => {
    abort = () => reject(abortError());
    signal.addEventListener("abort", abort, { once: true });
    if (signal.aborted) {
      abort();
    }
  });
  try {
    return await Promise.race([promise, cancelled]);
  } finally {
    signal.removeEventListener("abort", abort);
  }
}

function validSize(value, maximum) {
  return Number.isSafeInteger(value) && value > 0 && value <= maximum;
}
async function verifyHash(bytes, size, hash) {
  if (bytes.byteLength !== size || !HASH.test(hash)) {
    throw new Error("Translation asset size or hash pin is invalid");
  }
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  const actual = Array.from(new Uint8Array(digest), byte =>
    byte.toString(16).padStart(2, "0")
  ).join("");
  if (actual !== hash) {
    throw new Error("Translation asset integrity check failed");
  }
}

async function readBounded(stream, size, signal) {
  if (!stream) {
    throw new Error("Translation asset has no response body");
  }
  checkSignal(signal);
  const reader = stream.getReader();
  const abort = () => reader.cancel(abortError()).catch(() => {});
  signal?.addEventListener("abort", abort, { once: true });
  const chunks = [];
  let length = 0;
  try {
    while (true) {
      checkSignal(signal);
      const { value, done } = await reader.read();
      checkSignal(signal);
      if (done) {
        break;
      }
      length += value.byteLength;
      if (length > size) {
        throw new Error("Translation asset exceeds its pinned size");
      }
      chunks.push(value);
    }
    if (length !== size) {
      throw new Error("Translation asset is incomplete");
    }
    const bytes = new Uint8Array(length);
    let offset = 0;
    for (const chunk of chunks) {
      bytes.set(chunk, offset);
      offset += chunk.byteLength;
    }
    return bytes;
  } finally {
    signal?.removeEventListener("abort", abort);
    await reader.cancel().catch(() => {});
    reader.releaseLock();
  }
}

// Used again at the inference boundary, including cached data after a restart.
export async function decompressAndroidTranslationAsset(blob, record, signal) {
  if (
    !validSize(record?.decompressedSize, MAX_DECOMPRESSED) ||
    !HASH.test(record.decompressedHash)
  ) {
    throw new Error("Translation decompression pins are invalid");
  }
  const bytes = await readBounded(
    blob.stream().pipeThrough(new DecompressionStream("zstd")),
    record.decompressedSize,
    signal
  );
  await verifyHash(bytes, record.decompressedSize, record.decompressedHash);
  checkSignal(signal);
  return bytes.buffer;
}

function isEligible(record) {
  switch (record.filter_expression ?? "") {
    case "":
    case "env.appinfo.OS == 'Android'":
      return true;
    case "env.appinfo.OS != 'Android'":
      return false;
    case "env.channel == 'default' || env.channel == 'nightly'":
      return ["default", "nightly"].includes(lazy.AppConstants.MOZ_UPDATE_CHANNEL);
    default:
      throw new Error("Unsupported translation catalog targeting");
  }
}

function validateRecord(record, kind) {
  const attachment = record?.attachment;
  if (
    !UUID.test(record?.id) ||
    typeof record.name !== "string" || !record.name ||
    !Number.isSafeInteger(record.last_modified) ||
    !Number.isSafeInteger(record.schema) ||
    !validSize(attachment?.size, MAX_COMPRESSED) ||
    !HASH.test(attachment.hash) ||
    attachment.mimetype !== "application/zstd" ||
    !validSize(record.decompressedSize, MAX_DECOMPRESSED) ||
    !HASH.test(record.decompressedHash) ||
    !new RegExp(`^main-workspace/translations-${kind}-v2/[a-f0-9-]+\\.zst$`).test(attachment.location) ||
    !/^[^/\\]+\.zst$/.test(attachment.filename) ||
    !/^\d+\.\d+(?:a\d+)?$/.test(record.version)
  ) {
    throw new Error("Invalid pinned translation record");
  }
  // Evaluate every targeting expression, including currently ineligible records.
  isEligible(record);
  if (kind === "models") {
    if (
      !["model", "lex", "vocab", "srcvocab", "trgvocab"].includes(record.fileType) ||
      !["tiny", "base", "base-memory"].includes(record.architecture) ||
      typeof record.sourceLanguage !== "string" ||
      typeof record.targetLanguage !== "string" ||
      record.sourceLanguage === record.targetLanguage ||
      record.variant !== undefined ||
      !record.version.startsWith("3.")
    ) {
      throw new Error("Unsupported pinned translation model");
    }
    new Intl.Locale(record.sourceLanguage);
    new Intl.Locale(record.targetLanguage);
  } else if (record.version !== "4.0" || record.license !== "MPL-2.0") {
    throw new Error("Unsupported pinned translations engine");
  }
}

export class AndroidTranslationAssets {
  static #instance;
  static get instance() {
    return (this.#instance ??= new AndroidTranslationAssets());
  }

  #catalog;
  #operations = new Set();
  #mutations = Promise.resolve();
  #transfers = Promise.resolve();
  #shuttingDown = false;

  constructor() {
    Services.obs.addObserver(() => {
      this.#shuttingDown = true;
      for (const operation of this.#operations) {
        operation.controller.abort();
      }
    }, "quit-application");
  }

  async #getCatalog() {
    if (!this.#catalog) {
      const pending = (async () => {
        const response = await fetch(DATA_ROOT + "catalog.json");
        if (!response.ok) {
          throw new Error("Packaged translations catalog is unavailable");
        }
        const bytes = await readBounded(response.body, CATALOG_SIZE);
        await verifyHash(bytes, CATALOG_SIZE, CATALOG_HASH);
        const data = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(bytes));
        if (
          data.format !== 1 || data.models?.length !== 377 ||
          data.wasm?.length !== 1 ||
          Object.keys(data).some(key => !["format", "models", "wasm"].includes(key))
        ) {
          throw new Error("Invalid translations catalog envelope");
        }
        const ids = new Set();
        for (const kind of ["models", "wasm"]) {
          for (const record of data[kind]) {
            validateRecord(record, kind);
            if (ids.has(record.id)) {
              throw new Error("Duplicate translation catalog ID");
            }
            ids.add(record.id);
          }
        }
        return data;
      })();
      this.#catalog = pending;
      pending.catch(() => {
        if (this.#catalog === pending) {
          this.#catalog = null;
        }
      });
    }
    return this.#catalog;
  }

  async #resolve(record) {
    const catalog = await this.#getCatalog();
    const pinned = [...catalog.models, ...catalog.wasm].find(r => r.id === record?.id);
    if (!pinned || !isEligible(pinned) || JSON.stringify(pinned) !== JSON.stringify(record)) {
      throw new Error("Unlisted or altered translation asset");
    }
    return pinned;
  }

  #path(record) {
    return PathUtils.join(PathUtils.profileDir, "redoubt-translations-v1", record.attachment.hash + ".zst");
  }

  async #verify(bytes, record, signal) {
    await verifyHash(bytes, record.attachment.size, record.attachment.hash);
    await decompressAndroidTranslationAsset(new Blob([bytes]), record, signal);
    checkSignal(signal);
    return { buffer: bytes.buffer, record };
  }

  async read(record) {
    record = await this.#resolve(record);
    if (record.name === "bergamot-translator") {
      const response = await fetch(DATA_ROOT + "bergamot-translator.wasm.zst");
      if (!response.ok) {
        throw new Error("Packaged translations engine is unavailable");
      }
      const bytes = await readBounded(response.body, record.attachment.size);
      return this.#verify(bytes, record);
    }
    const bytes = await IOUtils.read(this.#path(record), { maxBytes: record.attachment.size + 1 });
    // Cache commits already verified decompression. Rehash compressed bytes for
    // status/use without repeatedly expanding every installed language model;
    // the engine child independently checks expanded bounds/hash before use.
    await verifyHash(bytes, record.attachment.size, record.attachment.hash);
    return { buffer: bytes.buffer, record };
  }

  // A local adapter for existing selection/status/delete code. Its download()
  // deliberately means verified cache-only retrieval; it never grants network.
  client(kind) {
    if (!["models", "wasm"].includes(kind)) {
      throw new Error("Unknown translation catalog");
    }
    return {
      get: async ({ filters = {} } = {}) => {
        const catalog = await this.#getCatalog();
        return structuredClone(catalog[kind].filter(record =>
          isEligible(record) && Object.entries(filters).every(([key, value]) => record[key] === value)
        ));
      },
      sync: async () => { throw new Error("Translation collection sync is disabled"); },
      attachments: {
        download: record => this.read(record),
        isDownloaded: async record => {
          try {
            await this.read(record);
            return true;
          } catch (_) {
            return false;
          }
        },
        deleteDownloaded: record => this.delete(record),
      },
    };
  }

  #checkOperation(operation) {
    if (!this.#operations.has(operation) || this.#shuttingDown) {
      throw abortError();
    }
    checkSignal(operation.controller.signal);
    operation.checkCurrent();
  }

  async withDownloadOperation(callback, signal, checkCurrent = () => {}) {
    checkSignal(signal);
    if (this.#shuttingDown) {
      throw abortError();
    }
    const operation = { controller: new AbortController(), records: null, checkCurrent };
    const abort = () => operation.controller.abort();
    signal?.addEventListener("abort", abort, { once: true });
    const timer = lazy.setTimeout(abort, OPERATION_TIMEOUT_MS);
    this.#operations.add(operation);
    try {
      return await abortable(callback(operation), operation.controller.signal);
    } finally {
      abort();
      lazy.clearTimeout(timer);
      signal?.removeEventListener("abort", abort);
      this.#operations.delete(operation);
    }
  }

  async downloadRecords(records, operation) {
    this.#checkOperation(operation);
    // Seal each operation to exactly one selected record set.
    if (operation.records) {
      throw new Error("Translation operation already has a selected asset set");
    }
    const pinned = await Promise.all(records.map(record => this.#resolve(record)));
    this.#checkOperation(operation);
    operation.records = new Set(pinned.map(record => record.id));
    for (const record of pinned) {
      this.#checkOperation(operation);
      try {
        await this.read(record);
        this.#checkOperation(operation);
        continue;
      } catch (error) {
        this.#checkOperation(operation);
        if (record.name === "bergamot-translator") {
          throw error; // Broken bundled WASM must never trigger a network fallback.
        }
      }
      // Serialize transfers to bound memory even with concurrent tabs/downloads.
      const transfer = this.#transfers.then(() => this.#download(record, operation));
      this.#transfers = transfer.catch(() => {});
      await transfer;
    }
  }

  async #download(record, operation) {
    this.#checkOperation(operation);
    const signal = operation.controller.signal;
    const timer = lazy.setTimeout(() => operation.controller.abort(), TRANSFER_TIMEOUT_MS);
    try {
      const url = ATTACHMENT_ROOT + record.attachment.location;
      // No discovery, credentials, referrer, ambient cache or cross-origin redirect.
      const response = await fetch(url, {
        credentials: "omit", referrerPolicy: "no-referrer", cache: "no-store",
        redirect: "error", signal,
      });
      this.#checkOperation(operation);
      if (!response.ok || response.redirected || response.url !== url) {
        throw new Error("Translation asset response is not the pinned URL");
      }
      const length = response.headers.get("content-length");
      if (length !== null && length !== String(record.attachment.size)) {
        throw new Error("Translation response length differs from its pin");
      }
      const bytes = await readBounded(response.body, record.attachment.size, signal);
      await this.#verify(bytes, record, signal);
      this.#checkOperation(operation);
      await this.#mutate(async () => {
        this.#checkOperation(operation);
        const file = this.#path(record);
        await IOUtils.makeDirectory(PathUtils.parent(file), { permissions: 0o700 });
        this.#checkOperation(operation);
        const temporary = file + "." + Services.uuid.generateUUID().toString() + ".tmp";
        let committed = false;
        let validatedCommit = false;
        try {
          await IOUtils.write(temporary, bytes, { mode: "create" });
          this.#checkOperation(operation);
          await IOUtils.move(temporary, file);
          committed = true;
          this.#checkOperation(operation);
          validatedCommit = true;
        } finally {
          await IOUtils.remove(temporary, { ignoreAbsent: true });
          if (committed && (!validatedCommit || signal.aborted)) {
            await IOUtils.remove(file, { ignoreAbsent: true });
          }
        }
      });
    } finally {
      lazy.clearTimeout(timer);
    }
  }

  #mutate(callback) {
    const next = this.#mutations.then(callback);
    this.#mutations = next.catch(() => {});
    return next;
  }

  async delete(record) {
    record = await this.#resolve(record);
    for (const operation of this.#operations) {
      if (!operation.records || operation.records.has(record.id)) {
        operation.controller.abort();
      }
    }
    await this.#mutate(() => IOUtils.remove(this.#path(record), { ignoreAbsent: true }));
  }

  async deleteAll() {
    for (const operation of this.#operations) {
      operation.controller.abort();
    }
    const catalog = await this.#getCatalog();
    await this.#mutate(() => IOUtils.remove(
      PathUtils.join(PathUtils.profileDir, "redoubt-translations-v1"),
      { recursive: true, ignoreAbsent: true }
    ));
    return catalog.models.map(record => record.id);
  }
}
