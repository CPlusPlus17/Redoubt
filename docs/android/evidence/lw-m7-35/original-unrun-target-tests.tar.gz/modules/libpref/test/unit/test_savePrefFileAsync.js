/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

"use strict";

// LW-M7-35: real native file I/O, not a mocked preference service. Android's
// xpcshell head initializes a profile before loading tests, so no-profile
// rejection requires separate native/startup coverage and is not claimed here.
const PREF = "test.librewolf.savePrefFileAsync.value";
let profile;
let prefsFile;
let prefsObserver;

function childFile(name) {
  const file = profile.clone();
  file.append(name);
  return file;
}

async function savedValues(file) {
  const values = new Map();
  const record = (_kind, name, value) => values.set(name, value);
  Services.prefs.parsePrefsFromBuffer(await IOUtils.read(file.path), {
    onStringPref: record,
    onIntPref: record,
    onBoolPref: record,
    onError(message) {
      Assert.ok(false, `Malformed saved preference file: ${message}`);
    },
  });
  return values;
}

function suspendSave() {
  // Invoke this service directly to observe its nsresult. notifyObservers()
  // discards individual observer errors and cannot prove an acknowledgment.
  prefsObserver.observe(null, "suspend_process_notification", null);
}

async function rejectsSave(pattern = /NS_ERROR_/) {
  // Account for both an XPIDL synchronous error and a returned rejected Promise.
  await Assert.rejects(
    Promise.resolve().then(() => Services.prefs.savePrefFileAsync()),
    pattern
  );
}

async function withBlockedCurrentFile(task) {
  await Services.prefs.savePrefFileAsync();
  suspendSave();
  const saved = childFile("lw-m7-35-prefs.saved");
  Assert.ok(!saved.exists(), "Failure fixture never overwrites an existing file");
  // A directory at prefs.js produces a real I/O failure even as root; chmod is
  // not a reliable error fixture. Transitions are synchronous so an autosave
  // cannot run on the main thread between removing the directory and restore.
  prefsFile.clone().moveTo(profile, saved.leafName);
  prefsFile.create(Ci.nsIFile.DIRECTORY_TYPE, 0o700);
  try {
    await task();
    Assert.ok(prefsFile.isDirectory(), "Failure target remained a directory");
  } finally {
    // Drain any already queued writer before restoring the fixture. Failure
    // here is expected, but target failure assertions belong to task() above.
    try {
      suspendSave();
    } catch (_) {}
    prefsFile.remove(false);
    saved.moveTo(profile, prefsFile.leafName);
  }
}

add_setup(async function initialize() {
  Assert.equal(typeof Services.prefs.savePrefFileAsync, "function");
  profile = do_get_profile();
  prefsFile = childFile("prefs.js");
  Assert.ok(
    Services.dirsvc.get("PrefF", Ci.nsIFile).equals(prefsFile),
    "Test uses the actual current profile preferences file"
  );
  Assert.ok(
    Services.prefs.getBoolPref("preferences.allow.omt-write"),
    "Manifest enables the queued native writer before its first use"
  );
  prefsObserver = Services.prefs.QueryInterface(Ci.nsIObserver);
  await Services.prefs.savePrefFileAsync();
});

add_task(async function current_and_backup_snapshots_have_separate_outcomes() {
  const backupA = childFile("lw-m7-35-backup-a.js");
  const backupB = childFile("lw-m7-35-backup-b.js");
  const badBackup = childFile("lw-m7-35-backup-directory");
  for (const file of [backupA, backupB, badBackup]) {
    Assert.ok(!file.exists());
  }
  badBackup.create(Ci.nsIFile.DIRECTORY_TYPE, 0o700);
  try {
    // Queue distinct states/destinations without yielding. Each promise belongs
    // to its own captured snapshot, not a shared newest global snapshot.
    Services.prefs.setStringPref(PREF, "first-current");
    const firstCurrent = Services.prefs.savePrefFileAsync();
    Services.prefs.setStringPref(PREF, "backup-a");
    const firstBackup = Services.prefs.backupPrefFile(backupA);
    Services.prefs.setStringPref(PREF, "backup-failure");
    const failure = Assert.rejects(
      Services.prefs.backupPrefFile(badBackup),
      /NS_ERROR_/
    );
    Services.prefs.setStringPref(PREF, "backup-b");
    const secondBackup = Services.prefs.backupPrefFile(backupB);
    Services.prefs.setStringPref(PREF, "final-current");
    const finalCurrent = Services.prefs.savePrefFileAsync();
    await Promise.all([
      firstCurrent,
      firstBackup,
      failure,
      secondBackup,
      finalCurrent,
    ]);
    Assert.equal((await savedValues(backupA)).get(PREF), "backup-a");
    Assert.equal((await savedValues(backupB)).get(PREF), "backup-b");
    Assert.equal((await savedValues(prefsFile)).get(PREF), "final-current");
    Assert.ok(badBackup.isDirectory(), "Failed request did not replace its target");
  } finally {
    suspendSave();
    for (const file of [backupA, backupB, badBackup]) {
      if (file.exists()) {
        file.remove(false);
      }
    }
  }
});

add_task(async function clean_state_still_forces_a_write_and_reset_is_saved() {
  Services.prefs.setStringPref(PREF, "clean-state");
  suspendSave();
  Assert.ok(!Services.prefs.dirty, "Blocking save left the native service clean");
  prefsFile.remove(false);
  Assert.ok(!Services.prefs.dirty, "Removing the file did not mutate native prefs");
  await Services.prefs.savePrefFileAsync();
  Assert.equal((await savedValues(prefsFile)).get(PREF), "clean-state");

  Services.prefs.clearUserPref(PREF);
  await Services.prefs.savePrefFileAsync();
  Assert.ok(!(await savedValues(prefsFile)).has(PREF), "Reset reached disk");
});

add_task(async function actual_write_failure_rejects_and_can_be_retried() {
  await withBlockedCurrentFile(async () => {
    Services.prefs.setStringPref(PREF, "after-disk-error");
    await rejectsSave();
    Assert.throws(suspendSave, /NS_ERROR_/, "Suspend acknowledgment reports I/O failure");
    Assert.equal(Services.prefs.getStringPref(PREF), "after-disk-error");
  });
  await Services.prefs.savePrefFileAsync();
  Assert.equal((await savedValues(prefsFile)).get(PREF), "after-disk-error");
  suspendSave();
  Assert.ok(!Services.prefs.dirty, "Successful blocking retry clears dirty state");
});

// Must be last: successful profile shutdown intentionally cannot be undone.
add_task(async function shutdown_failure_does_not_close_profile_then_success_does() {
  await withBlockedCurrentFile(async () => {
    Services.prefs.setStringPref(PREF, "shutdown-retry");
    await rejectsSave();
    Assert.throws(
      () => prefsObserver.observe(null, "profile-before-change-telemetry", null),
      /NS_ERROR_/,
      "Failed final save is not a successful shutdown acknowledgment"
    );
  });
  // This call would reject ILLEGAL_DURING_SHUTDOWN if the failed observer had
  // incorrectly closed the profile. Verify actual bytes after the retry too.
  await Services.prefs.savePrefFileAsync();
  Assert.equal((await savedValues(prefsFile)).get(PREF), "shutdown-retry");

  Services.prefs.setStringPref(PREF, "shutdown-final");
  prefsObserver.observe(null, "profile-before-change-telemetry", null);
  Assert.equal((await savedValues(prefsFile)).get(PREF), "shutdown-final");
  await rejectsSave(/NS_ERROR_ILLEGAL_DURING_SHUTDOWN/);
  // The xpcshell harness owns removal of this dedicated profile. Do not mutate
  // the preference service after its successful final shutdown.
});
