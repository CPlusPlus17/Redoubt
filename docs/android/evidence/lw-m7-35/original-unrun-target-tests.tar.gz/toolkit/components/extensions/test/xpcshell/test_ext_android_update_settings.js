/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
"use strict";

AddonTestUtils.init(this);
AddonTestUtils.createAppInfo("xpcshell@tests.mozilla.org", "XPCShell", "1", "42");
const { GeckoViewWebExtension: controller } = ChromeUtils.importESModule(
  "resource://gre/modules/GeckoViewWebExtension.sys.mjs"
);
const { AddonRepository } = ChromeUtils.importESModule(
  "resource://gre/modules/addons/AddonRepository.sys.mjs"
);
const { sinon } = ChromeUtils.importESModule("resource://testing-common/Sinon.sys.mjs");
const NAMES = ["extensions.update.enabled", "extensions.update.autoUpdateDefault"];
let previous;

add_setup(async function setup() {
  previous = NAMES.map(name => ({name, hasUser: Services.prefs.prefHasUserValue(name),
    value: Services.prefs.getBoolPref(name, true)}));
  await AddonTestUtils.promiseStartupManager();
  registerCleanupFunction(async () => {
    for (const entry of previous) {
      Services.prefs.unlockPref(entry.name);
      if (entry.hasUser) Services.prefs.setBoolPref(entry.name, entry.value);
      else Services.prefs.clearUserPref(entry.name);
    }
    await Services.prefs.savePrefFileAsync();
    await AddonTestUtils.promiseShutdownManager();
  });
});

add_task(async function combined_settings_save_actual_profile_and_report_locks() {
  Services.prefs.setBoolPref(NAMES[0], true);
  Services.prefs.setBoolPref(NAMES[1], false);
  Assert.ok(!controller.getAutomaticUpdateSettings().enabled, "Mixed values are unchecked");
  const state = await controller.setAutomaticUpdateSettings(false);
  Assert.ok(!state.updateEnabled && !state.autoUpdateDefault);
  const saved = new Map();
  Services.prefs.parsePrefsFromBuffer(
    await IOUtils.read(PathUtils.join(do_get_profile().path, "prefs.js")),
    {onBoolPref: (_kind, name, value) => saved.set(name, value),
     onStringPref() {}, onIntPref() {}, onError: message => Assert.ok(false, message)}
  );
  for (const name of NAMES) Assert.equal(saved.get(name), false, name);
  Services.prefs.lockPref(NAMES[1]);
  try {
    Assert.ok(controller.getAutomaticUpdateSettings().locked);
    await Assert.rejects(controller.setAutomaticUpdateSettings(true), /locked/);
    Assert.equal(Services.prefs.getBoolPref(NAMES[0]), false, "No partial first write");
  } finally {
    Services.prefs.unlockPref(NAMES[1]);
  }
  Assert.ok((await controller.setAutomaticUpdateSettings(true)).enabled);
});

add_task(async function automatic_off_prevents_metadata_and_extension_lookup() {
  await controller.setAutomaticUpdateSettings(false);
  const sandbox = sinon.createSandbox();
  try {
    const metadata = sandbox.stub(AddonRepository, "isMetadataStale").returns(true);
    const fetch = sandbox.stub(AddonRepository, "backgroundUpdateCheck").resolves();
    const lookup = sandbox.stub(controller, "extensionById").throws(new Error("unreachable"));
    Assert.equal(await controller.updateWebExtension("not-installed", true), null);
    Assert.ok(metadata.notCalled && fetch.notCalled && lookup.notCalled);
  } finally { sandbox.restore(); }
});

add_task(async function off_during_metadata_prevents_manifest() {
  await controller.setAutomaticUpdateSettings(true);
  const sandbox = sinon.createSandbox();
  let finish;
  try {
    sandbox.stub(AddonRepository, "isMetadataStale").returns(true);
    sandbox.stub(AddonRepository, "backgroundUpdateCheck").returns(new Promise(resolve => { finish = resolve; }));
    const lookup = sandbox.stub(controller, "extensionById").throws(new Error("unreachable"));
    const update = controller.updateWebExtension("test", true);
    await controller.setAutomaticUpdateSettings(false);
    finish();
    Assert.equal(await update, null);
    Assert.ok(lookup.notCalled);
  } finally { sandbox.restore(); }
});

add_task(async function automatic_install_respects_per_addon_policy() {
  await controller.setAutomaticUpdateSettings(true);
  const sandbox = sinon.createSandbox();
  try {
    sandbox.stub(AddonRepository, "isMetadataStale").returns(false);
    sandbox.stub(controller, "extensionById").resolves({
      applyBackgroundUpdates: AddonManager.AUTOUPDATE_DISABLE,
      permissions: AddonManager.PERM_CAN_UPGRADE,
    });
    const install = { install: sandbox.spy(), addListener: sandbox.spy() };
    sandbox.stub(controller, "checkForUpdate").resolves(install);
    Assert.equal(await controller.updateWebExtension("test", true), null);
    Assert.ok(install.install.notCalled && install.addListener.notCalled);
  } finally { sandbox.restore(); }
});

add_task(async function off_during_manifest_prevents_install() {
  await controller.setAutomaticUpdateSettings(true);
  const sandbox = sinon.createSandbox();
  let finish;
  try {
    sandbox.stub(AddonRepository, "isMetadataStale").returns(false);
    sandbox.stub(controller, "extensionById").resolves({});
    const manifest = sandbox.stub(controller, "checkForUpdate").returns(new Promise(resolve => { finish = resolve; }));
    const update = controller.updateWebExtension("test", true);
    await Promise.resolve();
    Assert.ok(manifest.calledOnce);
    await controller.setAutomaticUpdateSettings(false);
    const install = { install: sandbox.spy(), addListener: sandbox.spy() };
    finish(install);
    Assert.equal(await update, null);
    Assert.ok(install.install.notCalled);
  } finally { sandbox.restore(); }
});

add_task(async function explicit_check_remains_available_with_automatic_off() {
  await controller.setAutomaticUpdateSettings(false);
  const sandbox = sinon.createSandbox();
  try {
    sandbox.stub(AddonRepository, "isMetadataStale").returns(false);
    sandbox.stub(controller, "extensionById").resolves({});
    const check = sandbox.stub(controller, "checkForUpdate").resolves(null);
    Assert.equal(await controller.updateWebExtension("test", false), null);
    Assert.ok(check.calledOnce);
    Assert.equal(check.firstCall.args[1], false);
  } finally { sandbox.restore(); }
});
