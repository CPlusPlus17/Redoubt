/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.fenix.settings

import android.annotation.SuppressLint
import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.VisibleForTesting
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.edit
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.NavDirections
import androidx.navigation.findNavController
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.SwitchPreferenceCompat
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import mozilla.components.browser.state.state.selectedOrDefaultSearchEngine
import mozilla.components.concept.engine.Engine
import mozilla.components.concept.sync.AccountObserver
import mozilla.components.concept.sync.AuthType
import mozilla.components.concept.sync.OAuthAccount
import mozilla.components.concept.sync.Profile
import mozilla.components.feature.addons.ui.AddonFilePicker
import mozilla.components.feature.ipprotection.store.IPProtectionStore
import mozilla.components.feature.ipprotection.store.state.isEligible
import mozilla.components.service.fxa.AccountServices
import mozilla.components.service.fxrelay.eligibility.Eligible
import mozilla.components.support.base.feature.ViewBoundFeatureWrapper
import mozilla.components.support.ktx.android.view.showKeyboard
import mozilla.components.support.utils.BuildManufacturerChecker
import mozilla.components.support.utils.DateTimeProvider
import mozilla.components.support.utils.DefaultDateTimeProvider
import mozilla.components.support.utils.ext.navigateToDefaultBrowserAppsSettings
import mozilla.components.ui.widgets.withCenterAlignedButtons
import mozilla.telemetry.glean.private.NoExtras
import org.mozilla.fenix.Config
import org.mozilla.fenix.FeatureFlags
import org.mozilla.fenix.GleanMetrics.Addons
import org.mozilla.fenix.GleanMetrics.CookieBanners
import org.mozilla.fenix.GleanMetrics.Events
import org.mozilla.fenix.GleanMetrics.SettingsSearch
import org.mozilla.fenix.GleanMetrics.TrackingProtection
import org.mozilla.fenix.GleanMetrics.Translations
import org.mozilla.fenix.GleanMetrics.Vpn
import org.mozilla.fenix.HomeActivity
import org.mozilla.fenix.R
import org.mozilla.fenix.components.Components
import org.mozilla.fenix.components.accounts.FenixFxAEntryPoint
import org.mozilla.fenix.databinding.AmoCollectionOverrideDialogBinding
import org.mozilla.fenix.e2e.SystemInsetsPaddedFragment
import org.mozilla.fenix.ext.application
import org.mozilla.fenix.ext.components
import org.mozilla.fenix.ext.getPreferenceKey
import org.mozilla.fenix.ext.navigateToNotificationsSettings
import org.mozilla.fenix.ext.openInNewTab
import org.mozilla.fenix.ext.requireComponents
import org.mozilla.fenix.ext.showToolbar
import org.mozilla.fenix.ext.showToolbarWithIconButton
import org.mozilla.fenix.home.maybeNavigateToSystemSetToDefaultAction
import org.mozilla.fenix.home.maybeRequestDefaultBrowserPrompt
import org.mozilla.fenix.nimbus.FxNimbus
import org.mozilla.fenix.perf.ProfilerViewModel
import org.mozilla.fenix.perf.ProfilerViewModelFactory
import org.mozilla.fenix.settings.account.AccountUiView
import org.mozilla.fenix.snackbar.FenixSnackbarDelegate
import org.mozilla.fenix.snackbar.SnackbarBinding
import org.mozilla.fenix.utils.Settings
import java.lang.ref.WeakReference
import kotlin.system.exitProcess
import mozilla.components.ui.icons.R as iconsR
import org.mozilla.fenix.GleanMetrics.Settings as SettingsMetrics

/**
 * Main settings screen.
 */
@Suppress("LargeClass", "TooManyFunctions")
class SettingsFragment : PreferenceFragmentCompat(), SystemInsetsPaddedFragment {

    private val args by navArgs<SettingsFragmentArgs>()
    private lateinit var accountUiView: AccountUiView
    private lateinit var addonFilePicker: AddonFilePicker
    private lateinit var components: Components
    private val profilerViewModel: ProfilerViewModel by activityViewModels {
        ProfilerViewModelFactory(requireActivity().application)
    }
    private val snackbarBinding = ViewBoundFeatureWrapper<SnackbarBinding>()
    private val dateTimeProvider: DateTimeProvider by lazy { DefaultDateTimeProvider() }

    @VisibleForTesting
    internal val accountObserver = object : AccountObserver {
        private fun updateAccountUi(profile: Profile? = null) {
            val context = context ?: return
            if (!AccountServices.isEnabled || !::accountUiView.isInitialized) return
            lifecycleScope.launch {
                if (!AccountServices.isEnabled) return@launch
                accountUiView.updateAccountUIState(
                    context = context,
                    profile = profile
                        ?: context.components.backgroundServices.accountManager.accountProfile(),
                )
            }
        }

        override fun onAuthenticated(account: OAuthAccount, authType: AuthType) = updateAccountUi()
        override fun onLoggedOut() = updateAccountUi()
        override fun onProfileUpdated(profile: Profile) = updateAccountUi(profile)
        override fun onAuthenticationProblems() = updateAccountUi()
    }

    // A flag used to track if we're going through the onCreate->onStart->onResume lifecycle chain.
    // If it's set to `true`, code in `onResume` can assume that `onCreate` executed a moment prior.
    // This flag is set to `false` at the end of `onResume`.
    private var creatingFragment = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        components = requireContext().components

        if (AccountServices.isEnabled) {
            accountUiView = AccountUiView(
                fragment = this,
                scope = lifecycleScope,
                accountManager = requireComponents.backgroundServices.accountManager,
                httpClient = requireComponents.core.client,
            )
        }
        AccountServicesPreference.addTo(this)

        addonFilePicker = AddonFilePicker(requireContext(), requireComponents.addonManager)
        addonFilePicker.registerForResults(this)

        // It's important to update the account UI state in onCreate since that ensures we'll never
        // display an incorrect state in the UI. We take care to not also call it as part of onResume
        // if it was just called here (via the 'creatingFragment' flag).
        // For example, if user is signed-in, and we don't perform this call in onCreate, we'll briefly
        // display a "Sign In" preference, which will then get replaced by the correct account information
        // once this call is ran in onResume shortly after.
        if (::accountUiView.isInitialized) {
            accountUiView.updateAccountUIState(
                requireContext(),
                requireComponents.backgroundServices.accountManager.accountProfile(),
            )
        }

        val booleanPreferenceTelemetryAllowList = with(requireContext()) {
            listOf(
                getString(R.string.pref_key_show_search_suggestions),
                getString(R.string.pref_key_remote_debugging),
                getString(R.string.pref_key_telemetry),
                getString(R.string.pref_key_marketing_telemetry),
                getString(R.string.pref_key_learn_about_marketing_telemetry),
                getString(R.string.pref_key_tracking_protection),
                getString(R.string.pref_key_search_bookmarks),
                getString(R.string.pref_key_search_browsing_history),
                getString(R.string.pref_key_show_clipboard_suggestions),
                getString(R.string.pref_key_open_links_in_a_private_tab),
                getString(R.string.pref_key_sync_logins),
                getString(R.string.pref_key_sync_bookmarks),
                getString(R.string.pref_key_sync_history),
                getString(R.string.pref_key_show_voice_search),
                getString(R.string.pref_key_show_search_suggestions_in_private),
                getString(R.string.pref_key_show_trending_search_suggestions),
                getString(R.string.pref_key_show_recent_search_suggestions),
            )
        }

        preferenceManager?.sharedPreferences
            ?.registerOnSharedPreferenceChangeListener(this) { sharedPreferences, key ->
                try {
                    if (key in booleanPreferenceTelemetryAllowList) {
                        val enabled = sharedPreferences.getBoolean(key, false)
                        Events.preferenceToggled.record(Events.PreferenceToggledExtra(enabled, key))
                    }
                } catch (e: ClassCastException) {
                    // The setting is not a boolean, not tracked
                }
            }

        findPreference<Preference>(
            getPreferenceKey(R.string.pref_key_translation),
        )?.isVisible = FxNimbus.features.translations.value().globalSettingsEnabled &&
            components.core.store.state.translationEngine.isEngineSupported == true

        findPreference<Preference>(
            getPreferenceKey(R.string.pref_key_page_summaries),
        )?.isVisible = components.settings.shakeToSummarizeFeatureFlagEnabled

        findPreference<Preference>(
            getPreferenceKey(R.string.pref_key_ai_controls),
        )?.isVisible = requireComponents.settings.aiControlsFeatureFlagEnabled
    }

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.preferences, rootKey)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                profilerViewModel.isProfilerActive.collect { isActive ->
                    updateProfilerUI(isActive)
                }
            }
        }

        snackbarBinding.set(
            feature = SnackbarBinding(
                context = requireContext(),
                browserStore = components.core.store,
                appStore = components.appStore,
                snackbarDelegate = FenixSnackbarDelegate(view),
                navController = findNavController(),
                tabsUseCases = components.useCases.tabsUseCases,
                sendTabUseCases = null,
                customTabSessionId = null,
            ),
            owner = this,
            view = view,
        )
    }

    @SuppressLint("RestrictedApi")
    override fun onResume() {
        super.onResume()

        // Use nimbus to set the title, and a trivial addition
        val nimbusValidation = FxNimbus.features.nimbusValidation.value()

        val title = nimbusValidation.settingsTitle
        val suffix = nimbusValidation.settingsPunctuation
        val toolbarTitle = "$title$suffix"

        val showSearch = !args.searchInProgress

        if (showSearch) {
            showToolbarWithIconButton(
                title = toolbarTitle,
                contentDescription = getString(R.string.settings_search_button_content_description),
                iconResId = iconsR.drawable.mozac_ic_search_24,
                onClick = {
                    SettingsSearch.opened.record()
                    findNavController().navigate(R.id.action_settingsFragment_to_settingsSearchFragment)
                },
            )
        } else {
            showToolbar(toolbarTitle)
        }

        // Account UI state is updated as part of `onCreate`. To not do it twice in a row, we only
        // update it here if we're not going through the `onCreate->onStart->onResume` lifecycle chain.
        update(
            shouldUpdateAccountUIState = !creatingFragment,
            settings = requireComponents.settings,
        )

        requireView().findViewById<RecyclerView>(R.id.recycler_view)
            ?.hideInitialScrollBar(viewLifecycleOwner.lifecycleScope)

        args.preferenceToScrollTo?.let {
            scrollToPreferenceWithHighlight(it)
        }
        // Consider finish of `onResume` to be the point at which we consider this fragment as 'created'.
        creatingFragment = false
    }

    override fun onStart() {
        super.onStart()
        if (!AccountServices.isEnabled) return
        // Observe account changes to keep the UI up-to-date.
        requireComponents.backgroundServices.accountManager.register(
            accountObserver,
            owner = this,
            autoPause = true,
        )
    }

    override fun onStop() {
        super.onStop()
        if (!::accountUiView.isInitialized) return
        // If the screen isn't visible we don't need to show updates.
        // Also prevent the observer registered to the FXA singleton causing memory leaks.
        requireComponents.backgroundServices.accountManager.unregister(accountObserver)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        if (::accountUiView.isInitialized) accountUiView.cancel()
    }

    private fun update(
        shouldUpdateAccountUIState: Boolean,
        settings: Settings,
    ) {
        val aboutPreference = requirePreference<Preference>(R.string.pref_key_about)
        val appName = getString(R.string.app_name)
        aboutPreference.title = getString(R.string.preferences_about, appName)

        val deleteBrowsingDataPreference =
            requirePreference<Preference>(R.string.pref_key_delete_browsing_data_on_quit_preference)
        deleteBrowsingDataPreference.summary = if (settings.shouldDeleteBrowsingDataOnQuit) {
            getString(R.string.delete_browsing_data_quit_on)
        } else {
            getString(R.string.delete_browsing_data_quit_off)
        }

        val tabSettingsPreference =
            requirePreference<Preference>(R.string.pref_key_tabs)
        tabSettingsPreference.summary = settings.getTabTimeoutString()

        val autofillPreference = requirePreference<Preference>(R.string.pref_key_credit_cards)
        autofillPreference.title = if (settings.addressFeature) {
            getString(R.string.preferences_autofill)
        } else {
            getString(R.string.preferences_credit_cards_2)
        }

        val openLinksInAppsSettingsPreference =
            requirePreference<Preference>(R.string.pref_key_open_links_in_apps)
        openLinksInAppsSettingsPreference.summary = settings.getOpenLinksInAppsString()

        setupPreferences(settings)

        if (shouldUpdateAccountUIState && AccountServices.isEnabled && ::accountUiView.isInitialized) {
            accountUiView.updateAccountUIState(
                requireContext(),
                requireComponents.backgroundServices.accountManager.accountProfile(),
            )
        }
    }

    @SuppressLint("InflateParams")
    @Suppress("LongMethod", "CyclomaticComplexMethod")
    override fun onPreferenceTreeClick(preference: Preference): Boolean {
        if (!AccountServices.isEnabled && preference.key in listOf(
                getString(R.string.pref_key_sign_in),
                getString(R.string.pref_key_account),
                getString(R.string.pref_key_account_auth_error),
            )
        ) {
            AccountServicesPreference.showChangeDialog(this, true)
            return true
        }
        // Hide the scrollbar so the animation looks smoother
        val recyclerView = requireView().findViewById<RecyclerView>(R.id.recycler_view)
        recyclerView.isVerticalScrollBarEnabled = false

        val directions: NavDirections? = when (preference.key) {
            /* Top level account preferences.
            Note: Only ONE of these preferences is visible at a time. */
            resources.getString(R.string.pref_key_sign_in) -> {
                SettingsMetrics.signIntoSync.add()
                SettingsFragmentDirections.actionSettingsFragmentToTurnOnSyncFragment(
                    entrypoint = FenixFxAEntryPoint.SettingsMenu,
                )
            }

            resources.getString(R.string.pref_key_account) -> {
                SettingsFragmentDirections.actionSettingsFragmentToAccountSettingsFragment()
            }

            resources.getString(R.string.pref_key_account_auth_error) -> {
                SettingsFragmentDirections.actionSettingsFragmentToAccountProblemFragment(
                    entrypoint = FenixFxAEntryPoint.SettingsMenu,
                )
            }

            // General preferences
            resources.getString(R.string.pref_key_search_settings) -> {
                SettingsFragmentDirections.actionSettingsFragmentToSearchEngineFragment()
            }

            resources.getString(R.string.pref_key_tabs) -> {
                SettingsFragmentDirections.actionSettingsFragmentToTabsSettingsFragment()
            }

            resources.getString(R.string.pref_key_home) -> {
                SettingsFragmentDirections.actionSettingsFragmentToHomeSettingsFragment()
            }

            resources.getString(R.string.pref_key_customize) -> {
                SettingsFragmentDirections.actionSettingsFragmentToCustomizationFragment()
            }

            resources.getString(R.string.pref_key_passwords) -> {
                SettingsMetrics.passwords.record()
                SettingsFragmentDirections.actionSettingsFragmentToSavedLoginsAuthFragment()
            }

            resources.getString(R.string.pref_key_email_masks) -> {
                SettingsFragmentDirections.actionSettingsFragmentToEmailMasksSettingsFragment()
            }

            resources.getString(R.string.pref_key_credit_cards) -> {
                SettingsMetrics.autofill.record()
                SettingsFragmentDirections.actionSettingsFragmentToAutofillSettingFragment()
            }

            resources.getString(R.string.pref_key_accessibility) -> {
                SettingsFragmentDirections.actionSettingsFragmentToAccessibilityFragment()
            }

            resources.getString(R.string.pref_key_language) -> {
                SettingsFragmentDirections.actionSettingsFragmentToLocaleSettingsFragment()
            }

            resources.getString(R.string.pref_key_translation) -> {
                Translations.action.record(Translations.ActionExtra("global_settings_from_preferences"))
                SettingsFragmentDirections.actionSettingsFragmentToTranslationsSettingsFragment()
            }

            resources.getString(R.string.pref_key_page_summaries) -> {
                SettingsFragmentDirections.actionSettingsFragmentToPageSummariesSettingsFragment()
            }

            resources.getString(R.string.pref_key_ai_controls) -> {
                SettingsFragmentDirections.actionSettingsFragmentToAiControlsFragment()
            }

            // Privacy and security preferences
            resources.getString(R.string.pref_key_private_browsing) -> {
                SettingsFragmentDirections.actionSettingsFragmentToPrivateBrowsingFragment()
            }

            resources.getString(R.string.pref_key_https_only_settings) -> {
                SettingsFragmentDirections.actionSettingsFragmentToHttpsOnlyFragment()
            }

            resources.getString(R.string.pref_key_ip_protection_settings) -> {
                Vpn.settingsPageTapped.record(Vpn.SettingsPageTappedExtra(entrypoint = "Settings"))
                SettingsFragmentDirections.actionSettingsFragmentToIpProtectionFragment(
                    entrypoint = FenixFxAEntryPoint.IPProtectionSettings,
                )
            }

            resources.getString(R.string.pref_key_tracking_protection_settings) -> {
                TrackingProtection.etpSettings.record(NoExtras())
                SettingsFragmentDirections.actionSettingsFragmentToTrackingProtectionFragment()
            }

            resources.getString(R.string.pref_key_doh_settings) -> {
                SettingsFragmentDirections.actionSettingsFragmentToDohSettingsFragment()
            }

            resources.getString(R.string.pref_key_site_permissions) -> {
                SettingsFragmentDirections.actionSettingsFragmentToSitePermissionsFragment()
            }

            resources.getString(R.string.pref_key_delete_browsing_data) -> {
                SettingsFragmentDirections.actionSettingsFragmentToDeleteBrowsingDataFragment()
            }

            resources.getString(R.string.pref_key_delete_browsing_data_on_quit_preference) -> {
                SettingsFragmentDirections.actionSettingsFragmentToDeleteBrowsingDataOnQuitFragment()
            }

            resources.getString(R.string.pref_key_notifications) -> {
                context?.navigateToNotificationsSettings {}
                null
            }

            resources.getString(R.string.pref_key_data_choices) -> {
                SettingsFragmentDirections.actionSettingsFragmentToDataChoicesFragment()
            }

            // Advanced preferences
            resources.getString(R.string.pref_key_addons) -> {
                Addons.openAddonsInSettings.record(NoExtras())
                SettingsFragmentDirections.actionSettingsFragmentToAddonsFragment()
            }

            // Only displayed when secret settings are enabled
            resources.getString(R.string.pref_key_install_local_addon) -> {
                addonFilePicker.launch()
                null
            }

            // Only displayed when secret settings are enabled
            resources.getString(R.string.pref_key_override_amo_collection) -> {
                val context = requireContext()
                val dialogView = LayoutInflater.from(context)
                    .inflate(R.layout.amo_collection_override_dialog, null)

                val binding = AmoCollectionOverrideDialogBinding.bind(dialogView)
                MaterialAlertDialogBuilder(context).apply {
                    setTitle(context.getString(R.string.preferences_customize_extension_collection))
                    setView(dialogView)
                    setNegativeButton(R.string.customize_addon_collection_cancel) { dialog: DialogInterface, _ ->
                        dialog.cancel()
                    }

                    setPositiveButton(R.string.customize_addon_collection_ok) { _, _ ->
                        context.components.settings.overrideAmoUser = binding.customAmoUser.text.toString()
                        context.components.settings.overrideAmoCollection =
                            binding.customAmoCollection.text.toString()

                        Toast.makeText(
                            context,
                            getString(R.string.toast_customize_extension_collection_done),
                            Toast.LENGTH_LONG,
                        ).show()

                        Handler(Looper.getMainLooper()).postDelayed(
                            {
                                exitProcess(0)
                            },
                            AMO_COLLECTION_OVERRIDE_EXIT_DELAY,
                        )
                    }

                    binding.customAmoCollection.setText(context.components.settings.overrideAmoCollection)
                    binding.customAmoUser.setText(context.components.settings.overrideAmoUser)
                    binding.customAmoUser.requestFocus()
                    binding.customAmoUser.showKeyboard()
                    create().withCenterAlignedButtons()
                }.show()

                null
            }

            resources.getString(R.string.pref_key_link_sharing) -> {
                SettingsFragmentDirections.actionSettingsFragmentToLinkSharingFragment()
            }

            resources.getString(R.string.pref_key_remote_improvements) -> {
                SettingsFragmentDirections.actionSettingsFragmentToRemoteImprovementsFragment()
            }

            resources.getString(R.string.pref_key_open_links_in_apps) -> {
                SettingsFragmentDirections.actionSettingsFragmentToOpenLinksInAppsFragment()
            }

            resources.getString(R.string.pref_key_downloads) -> {
                SettingsFragmentDirections.actionSettingsFragmentToOpenDownloadsSettingsFragment()
            }

            resources.getString(R.string.pref_key_firefox_labs) -> {
                SettingsMetrics.firefoxLabs.record()
                SettingsFragmentDirections.actionSettingsFragmentToFirefoxLabsFragment()
            }

            resources.getString(R.string.pref_key_sync_debug) -> {
                SettingsFragmentDirections.actionSettingsFragmentToSyncDebugFragment()
            }

            // About preferences
            resources.getString(R.string.pref_key_rate) -> {
                components.playStoreReviewPromptController.tryLaunchPlayStoreReview(requireActivity(), ::openInNewTab)
                null
            }

            resources.getString(R.string.pref_key_about) -> {
                SettingsFragmentDirections.actionSettingsFragmentToAboutFragment()
            }

            // Only displayed when secret settings are enabled
            resources.getString(R.string.pref_key_debug_settings) -> {
                SettingsFragmentDirections.actionSettingsFragmentToSecretSettingsFragment()
            }

            // Only displayed when secret settings are enabled
            resources.getString(R.string.pref_key_nimbus_experiments) -> {
                SettingsFragmentDirections.actionSettingsFragmentToNimbusExperimentsFragment()
            }

            // Only displayed when secret settings are enabled
            resources.getString(R.string.pref_key_start_profiler) -> {
                if (profilerViewModel.isProfilerActive.value) {
                    SettingsFragmentDirections.actionSettingsFragmentToStopProfilerDialog()
                } else {
                    SettingsFragmentDirections.actionSettingsFragmentToStartProfilerDialog()
                }
            }

            else -> null
        }
        directions?.let { navigateFromSettings(directions) }
        return super.onPreferenceTreeClick(preference)
    }

    private fun setupPreferences(settings: Settings) {
        val leakKey = getPreferenceKey(R.string.pref_key_leakcanary)
        val debuggingKey = getPreferenceKey(R.string.pref_key_remote_debugging)
        val preferenceLeakCanary = findPreference<Preference>(leakKey)
        val preferenceRemoteDebugging = findPreference<Preference>(debuggingKey)
        val preferenceMakeDefaultBrowser =
            requirePreference<DefaultBrowserPreference>(R.string.pref_key_make_default_browser)

        if (!Config.channel.isReleased) {
            preferenceLeakCanary?.setOnPreferenceChangeListener { _, newValue ->
                val isEnabled = newValue == true
                context?.application?.updateLeakCanaryState(isEnabled)
                true
            }
        }

        preferenceRemoteDebugging?.isVisible = true
        preferenceRemoteDebugging?.setOnPreferenceChangeListener<Boolean> { preference, newValue ->
            settings.preferences.edit { putBoolean(preference.key, newValue) }
            requireComponents.core.engine.settings.remoteDebuggingEnabled = newValue
            true
        }

        preferenceMakeDefaultBrowser.apply {
            updateSwitch()
            onPreferenceClickListener =
                getClickListenerForMakeDefaultBrowser()
        }

        val preferenceStartProfiler =
            findPreference<Preference>(getPreferenceKey(R.string.pref_key_start_profiler))

        with(settings) {
            findPreference<Preference>(
                getPreferenceKey(R.string.pref_key_nimbus_experiments),
            )?.isVisible = showSecretDebugMenuThisSession
            findPreference<Preference>(
                getPreferenceKey(R.string.pref_key_debug_settings),
            )?.isVisible = showSecretDebugMenuThisSession
            findPreference<Preference>(
                getPreferenceKey(R.string.pref_key_sync_debug),
            )?.isVisible = showSecretDebugMenuThisSession
            findPreference<Preference>(
                getPreferenceKey(R.string.pref_key_firefox_labs),
            )?.isVisible = enableFirefoxLabs
            preferenceStartProfiler?.isVisible = showSecretDebugMenuThisSession &&
                (components.core.engine.profiler?.isProfilerActive() != null)
        }
        // LibreWolf (LW-M6-06): the update-check row exists only on builds that
        // carry a verification key; a store build (F-Droid, Accrescent) has none
        // and must not offer a second update channel.
        findPreference<Preference>(
            getPreferenceKey(R.string.pref_key_lw_update_check),
        )?.isVisible = org.mozilla.fenix.lw.UpdateCheck.isCompiledIn
        setupCookieBannerPreference(settings)
        setupInstallAddonFromFilePreference(settings)
        setLinkSharingPreference()
        setupAmoCollectionOverridePreference(
            settings,
            FeatureFlags.customExtensionCollectionFeature,
        )
        setupGeckoLogsPreference(settings)
        setupHttpsOnlyPreferences(settings)
        setupIPProtectionPreferences(components.ipProtection.store)
        setupNotificationPreference(
            NotificationManagerCompat.from(requireContext()).areNotificationsEnabled(),
        )
        setupSearchPreference(
            components.core.store.state.search.selectedOrDefaultSearchEngine?.name,
        )
        setupHomepagePreference(settings)
        setupTrackingProtectionPreference(settings)
        setupDnsOverHttpsPreference(settings)
        setupEmailMaskPreference(settings, requireComponents)
    }

    private val setToDefaultPromptRequestLauncher: ActivityResultLauncher<Intent> =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            with(requireContext()) {
                maybeNavigateToSystemSetToDefaultAction(result.resultCode, components.settings, dateTimeProvider) {
                    navigateToDefaultBrowserAppsSettings(BuildManufacturerChecker())
                }
            }
        }

    /**
     * For >=Q -> Use new RoleManager API to show in-app browser switching dialog.
     * For <Q && >=N -> Navigate user to Android Default Apps Settings.
     * For <N -> Open sumo page to show user how to change default app.
     */
    private fun getClickListenerForMakeDefaultBrowser(): Preference.OnPreferenceClickListener {
        return Preference.OnPreferenceClickListener {
            maybeRequestDefaultBrowserPrompt(
                WeakReference((requireActivity() as? HomeActivity)),
                setToDefaultPromptRequestLauncher,
            )
            true
        }
    }

    private fun navigateFromSettings(directions: NavDirections) {
        view?.findNavController()?.let { navController ->
            if (navController.currentDestination?.id == R.id.settingsFragment) {
                navController.navigate(directions)
            }
        }
    }

    // Extension function for hiding the scroll bar on initial loading. We must do this so the
    // animation to the next screen doesn't animate the initial scroll bar (it ignores
    // isVerticalScrollBarEnabled being set to false).
    private fun RecyclerView.hideInitialScrollBar(scope: CoroutineScope) {
        scope.launch {
            val originalSize = scrollBarSize
            scrollBarSize = 0
            delay(SCROLL_INDICATOR_DELAY)
            scrollBarSize = originalSize
        }
    }

    @VisibleForTesting
    internal fun setupAmoCollectionOverridePreference(
        settings: Settings,
        customExtensionCollectionFeature: Boolean,
    ) {
        val preferenceAmoCollectionOverride =
            findPreference<Preference>(getPreferenceKey(R.string.pref_key_override_amo_collection))

        val show = (
            customExtensionCollectionFeature && (
                settings.amoCollectionOverrideConfigured() || settings.showSecretDebugMenuThisSession
                )
            )
        preferenceAmoCollectionOverride?.apply {
            isVisible = show
            summary = settings.overrideAmoCollection.ifEmpty { null }
        }
    }

    @VisibleForTesting
    internal fun setupGeckoLogsPreference(settings: Settings) {
        val preferenceEnabledGeckoLogs =
            findPreference<Preference>(getPreferenceKey(R.string.pref_key_enable_gecko_logs))

        val show = settings.showSecretDebugMenuThisSession
        preferenceEnabledGeckoLogs?.isVisible = show

        preferenceEnabledGeckoLogs?.onPreferenceChangeListener =
            Preference.OnPreferenceChangeListener { _, newValue ->
                settings.enableGeckoLogs = newValue as Boolean
                Toast.makeText(
                    context,
                    getString(R.string.quit_application),
                    Toast.LENGTH_LONG,
                ).show()
                Handler(Looper.getMainLooper()).postDelayed(
                    {
                        exitProcess(0)
                    },
                    FXA_SYNC_OVERRIDE_EXIT_DELAY,
                )
                true
            }
    }

    @VisibleForTesting
    internal fun setupNotificationPreference(areNotificationsEnabled: Boolean) {
        with(requirePreference<Preference>(R.string.pref_key_notifications)) {
            summary = if (areNotificationsEnabled) {
                getString(R.string.notifications_allowed_summary)
            } else {
                getString(R.string.notifications_not_allowed_summary)
            }
        }
    }

    @VisibleForTesting
    internal fun setupHomepagePreference(settings: Settings) {
        with(requirePreference<Preference>(R.string.pref_key_home)) {
            summary = when {
                settings.alwaysOpenTheHomepageWhenOpeningTheApp ->
                    getString(R.string.opening_screen_homepage_summary)

                settings.openHomepageAfterFourHoursOfInactivity ->
                    getString(R.string.opening_screen_after_four_hours_of_inactivity_summary)

                settings.alwaysOpenTheLastTabWhenOpeningTheApp ->
                    getString(R.string.opening_screen_last_tab_summary)

                else -> null
            }
        }
    }

    @VisibleForTesting
    internal fun setupSearchPreference(selectedOrDefaultSearchEngineName: String?) {
        with(requirePreference<Preference>(R.string.pref_key_search_settings)) {
            summary = selectedOrDefaultSearchEngineName
        }
    }

    @VisibleForTesting
    internal fun setupTrackingProtectionPreference(settings: Settings) {
        with(requirePreference<Preference>(R.string.pref_key_tracking_protection_settings)) {
            summary = when {
                !settings.shouldUseTrackingProtection -> getString(R.string.tracking_protection_off)
                settings.useStandardTrackingProtection -> getString(R.string.tracking_protection_standard)
                settings.useStrictTrackingProtection -> getString(R.string.tracking_protection_strict)
                settings.useCustomTrackingProtection -> getString(R.string.tracking_protection_custom)
                else -> null
            }
        }
    }

    private fun setupDnsOverHttpsPreference(settings: Settings) {
        with(requirePreference<Preference>(R.string.pref_key_doh_settings)) {
            isVisible = settings.showDohEntryPoint
            summary = when (settings.getDohSettingsMode()) {
                Engine.DohSettingsMode.DEFAULT -> getString(R.string.preference_doh_default_protection)
                Engine.DohSettingsMode.OFF -> getString(R.string.preference_doh_off)
                Engine.DohSettingsMode.INCREASED -> getString(R.string.preference_doh_increased_protection)
                Engine.DohSettingsMode.MAX -> getString(R.string.preference_doh_max_protection)
            }
        }
    }

    @VisibleForTesting
    internal fun setupEmailMaskPreference(settings: Settings, components: Components) {
        findPreference<Preference>(getPreferenceKey(R.string.pref_key_email_masks))?.let {
            it.isVisible = settings.isEmailMaskFeatureEnabled &&
                    components.relayEligibilityStore.state.eligibilityState is Eligible
        }
    }

    @VisibleForTesting
    internal fun setupCookieBannerPreference(settings: Settings) {
        FxNimbus.features.cookieBanners.recordExposure()
        if (settings.shouldShowCookieBannerUI) {
            with(requirePreference<SwitchPreferenceCompat>(R.string.pref_key_cookie_banner_normal_mode)) {
                isVisible = true
                isChecked = settings.shouldUseCookieBanner
                onPreferenceChangeListener = Preference.OnPreferenceChangeListener { _, newValue ->
                    settings.shouldUseCookieBanner = newValue as Boolean
                    requireComponents.core.engine.settings.cookieBannerHandlingMode = settings.getCookieBannerHandling()
                    requireComponents.useCases.sessionUseCases.reload()
                    true
                }
            }
            with(requirePreference<SwitchPreferenceCompat>(R.string.pref_key_cookie_banner_private_mode)) {
                isVisible = settings.shouldShowCookieBannerUI
                isChecked = settings.shouldUseCookieBannerPrivateMode
                onPreferenceChangeListener = object : SharedPreferenceUpdater() {
                    override fun onPreferenceChange(
                        preference: Preference,
                        newValue: Any?,
                    ): Boolean {
                        val metricTag = if (newValue == true) {
                            "reject_all"
                        } else {
                            "disabled"
                        }
                        val engineSettings = components.core.engine.settings
                        settings.shouldUseCookieBannerPrivateMode = newValue as Boolean
                        val mode = settings.getCookieBannerHandlingPrivateMode()
                        engineSettings.cookieBannerHandlingModePrivateBrowsing = mode
                        CookieBanners.settingChangedPmb.record(CookieBanners.SettingChangedPmbExtra(metricTag))
                        components.useCases.sessionUseCases.reload()
                        return super.onPreferenceChange(preference, newValue)
                    }
                }
            }
        }
    }

    @VisibleForTesting
    internal fun setupInstallAddonFromFilePreference(settings: Settings) {
        with(requirePreference<Preference>(R.string.pref_key_install_local_addon)) {
            isVisible = settings.showSecretDebugMenuThisSession
        }
    }

    @VisibleForTesting
    internal fun setLinkSharingPreference() {
        with(requirePreference<Preference>(R.string.pref_key_link_sharing)) {
            isVisible = FxNimbus.features.sentFromFirefox.value().enabled
        }
    }

    @VisibleForTesting
    internal fun setupHttpsOnlyPreferences(settings: Settings) {
        val httpsOnlyPreference =
            requirePreference<Preference>(R.string.pref_key_https_only_settings)
        httpsOnlyPreference.summary =
            when {
                !settings.shouldUseHttpsOnly -> getString(R.string.preferences_https_only_off)
                settings.shouldUseHttpsOnlyInAllTabs -> getString(R.string.preferences_https_only_on_all)
                settings.shouldUseHttpsOnlyInPrivateTabsOnly ->
                    getString(R.string.preferences_https_only_on_private)
                else -> null
            }
    }

    @VisibleForTesting
    internal fun setupIPProtectionPreferences(ipProtectionStore: IPProtectionStore) {
        findPreference<IPProtectionPreference>(
            getPreferenceKey(R.string.pref_key_ip_protection_settings),
        )?.apply {
            isVisible = ipProtectionStore.state.isEligible
            showBetaBadge = FxNimbus.features.ipProtection.value().showBetaBadge
        }
    }

    private fun updateProfilerUI(profilerStatus: Boolean) {
        if (profilerStatus) {
            findPreference<Preference>(getPreferenceKey(R.string.pref_key_start_profiler))?.title =
                resources.getString(R.string.profiler_stop)
            findPreference<Preference>(getPreferenceKey(R.string.pref_key_start_profiler))?.summary =
                resources.getString(R.string.profiler_running)
        } else {
            findPreference<Preference>(getPreferenceKey(R.string.pref_key_start_profiler))?.title =
                resources.getString(R.string.preferences_start_profiler)
            findPreference<Preference>(getPreferenceKey(R.string.pref_key_start_profiler))?.summary = ""
        }
    }

    companion object {
        private const val SCROLL_INDICATOR_DELAY = 10L
        private const val FXA_SYNC_OVERRIDE_EXIT_DELAY = 2000L
        private const val AMO_COLLECTION_OVERRIDE_EXIT_DELAY = 3000L
    }
}
