/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.fenix.components

import io.mockk.every
import io.mockk.mockk
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.async
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import mozilla.components.concept.engine.webextension.Metadata
import mozilla.components.concept.engine.webextension.PermissionPromptResponse
import mozilla.components.concept.engine.webextension.WebExtension
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import org.mozilla.fenix.components.LibreWolfUboPreinstaller.Installed
import org.mozilla.fenix.components.LibreWolfUboPreinstaller.State
import org.mozilla.fenix.components.LibreWolfUboPreinstaller.VerifiedAsset
import java.io.File
import java.io.IOException
import java.nio.file.Files

@OptIn(ExperimentalCoroutinesApi::class)
class LibreWolfUboPreinstallerTest {
    @Test
    fun `runtime asset verifier preserves bytes matching the pinned size and hash`() = withTemporaryAsset { destination ->
        val contents = "abc".toByteArray(Charsets.UTF_8)

        contents.inputStream().use { input ->
            LibreWolfUboPreinstaller.copyAndVerifyAsset(input, destination, 3L, ABC_SHA256)
        }

        assertArrayEquals(contents, destination.readBytes())
    }

    @Test
    fun `runtime asset verifier rejects changed bytes with the same length`() = withTemporaryAsset { destination ->
        try {
            "abd".toByteArray(Charsets.UTF_8).inputStream().use { input ->
                LibreWolfUboPreinstaller.copyAndVerifyAsset(input, destination, 3L, ABC_SHA256)
            }
            fail("The same-length replacement must fail SHA-256 verification")
        } catch (exception: IllegalArgumentException) {
            assertTrue(exception.message.orEmpty().contains("SHA-256"))
        }
    }

    @Test
    fun `runtime asset verifier rejects wrong length even with the correct hash`() = withTemporaryAsset { destination ->
        try {
            "abc".toByteArray(Charsets.UTF_8).inputStream().use { input ->
                LibreWolfUboPreinstaller.copyAndVerifyAsset(input, destination, 2L, ABC_SHA256)
            }
            fail("A matching hash must not bypass the pinned length")
        } catch (exception: IllegalArgumentException) {
            assertTrue(exception.message.orEmpty().contains("size"))
        }
    }

    @Test
    fun `first launch installs once and holds navigation until filtering is ready`() = runTest {
        val dependencies = FakeDependencies().apply {
            installBarrier = CompletableDeferred()
            filteringBarrier = CompletableDeferred()
        }
        val preinstaller = LibreWolfUboPreinstaller(dependencies, backgroundScope)
        val navigation = backgroundScope.async { preinstaller.awaitReady() }

        preinstaller.start()
        preinstaller.start()
        runCurrent()

        assertEquals(1, dependencies.installCalls)
        assertEquals(listOf("attempted"), dependencies.decisionsAtInstall)
        assertEquals(State.Preparing, preinstaller.state.value)
        assertFalse(navigation.isCompleted)

        dependencies.installBarrier!!.complete(Unit)
        runCurrent()

        assertEquals(listOf(VERSION), dependencies.filteringVersions)
        assertEquals("attempted", dependencies.decision)
        assertFalse(navigation.isCompleted)

        dependencies.filteringBarrier!!.complete(Unit)
        runCurrent()

        assertEquals(State.Ready(installed = true, enabled = true), preinstaller.state.value)
        assertEquals("complete", dependencies.decision)
        assertTrue(navigation.isCompleted)
        preinstaller.start()
        preinstaller.retry()
        runCurrent()
        assertEquals(1, dependencies.installCalls)
    }

    @Test
    fun `existing disabled extension stays disabled without installation or a filtering wait`() = runTest {
        val existing = Installed(enabled = false, version = "1.72.0")
        val dependencies = FakeDependencies().apply { registry = existing }
        val preinstaller = LibreWolfUboPreinstaller(dependencies, backgroundScope)

        preinstaller.start()
        runCurrent()

        assertEquals(State.Ready(installed = true, enabled = false), preinstaller.state.value)
        assertEquals(existing, dependencies.registry)
        assertEquals("complete", dependencies.decision)
        assertEquals(0, dependencies.prepareCalls)
        assertEquals(0, dependencies.installCalls)
        assertTrue(dependencies.filteringVersions.isEmpty())
        assertFalse(requestPermission(preinstaller, extension(), mutableListOf()))
    }

    @Test
    fun `existing updated extension waits for its installed version without replacing it`() = runTest {
        val dependencies = FakeDependencies().apply {
            registry = Installed(enabled = true, version = "1.75.0")
            filteringBarrier = CompletableDeferred()
        }
        val preinstaller = LibreWolfUboPreinstaller(dependencies, backgroundScope)

        preinstaller.start()
        runCurrent()

        assertEquals(State.Preparing, preinstaller.state.value)
        assertEquals(listOf("1.75.0"), dependencies.filteringVersions)
        assertEquals(0, dependencies.prepareCalls)
        assertEquals(0, dependencies.installCalls)

        dependencies.filteringBarrier!!.complete(Unit)
        runCurrent()
        assertEquals(State.Ready(installed = true, enabled = true), preinstaller.state.value)
        assertEquals("1.75.0", dependencies.registry!!.version)
    }

    @Test
    fun `completed removal survives restart and a different bundled version`() = runTest {
        val dependencies = FakeDependencies().apply { decision = "complete" }
        val first = LibreWolfUboPreinstaller(dependencies, backgroundScope)
        first.start()
        runCurrent()

        dependencies.asset = dependencies.asset.copy(version = "1.75.0")
        val upgraded = LibreWolfUboPreinstaller(dependencies, backgroundScope)
        upgraded.start()
        upgraded.retry()
        runCurrent()

        assertEquals(State.Ready(installed = false, enabled = false), first.state.value)
        assertEquals(State.Ready(installed = false, enabled = false), upgraded.state.value)
        assertEquals(0, dependencies.prepareCalls)
        assertEquals(0, dependencies.installCalls)
        assertTrue(dependencies.filteringVersions.isEmpty())
        assertNull(dependencies.registry)
    }

    @Test
    fun `interrupted absent installation requires an explicit retry even after restart`() = runTest {
        val dependencies = FakeDependencies().apply { decision = "attempted" }
        val first = LibreWolfUboPreinstaller(dependencies, backgroundScope)
        first.start()
        runCurrent()

        assertFailed(first, "Retry is required")
        first.start()
        val restarted = LibreWolfUboPreinstaller(dependencies, backgroundScope)
        restarted.start()
        runCurrent()

        assertFailed(restarted, "Retry is required")
        assertEquals(0, dependencies.installCalls)

        restarted.retry()
        restarted.retry()
        runCurrent()

        assertEquals(State.Ready(installed = true, enabled = true), restarted.state.value)
        assertEquals(1, dependencies.installCalls)
        assertEquals("complete", dependencies.decision)
    }

    @Test
    fun `asset hash denial blocks installation and never grants trusted permissions`() = runTest {
        val dependencies = FakeDependencies().apply {
            prepareFailure = IOException("Bundled uBlock Origin does not match its pinned size and SHA-256")
        }
        val preinstaller = LibreWolfUboPreinstaller(dependencies, backgroundScope)
        val navigation = backgroundScope.async { preinstaller.awaitReady() }

        preinstaller.start()
        runCurrent()

        assertFailed(preinstaller, "SHA-256")
        assertFalse(navigation.isCompleted)
        assertNull(dependencies.decision)
        assertEquals(0, dependencies.installCalls)
        assertFalse(requestPermission(preinstaller, extension(), mutableListOf()))
    }

    @Test
    fun `wrong verified asset ID cannot activate an installation transaction`() = runTest {
        val dependencies = FakeDependencies().apply { asset = asset.copy(id = "other@example.invalid") }
        val preinstaller = LibreWolfUboPreinstaller(dependencies, backgroundScope)

        preinstaller.start()
        runCurrent()

        assertFailed(preinstaller, "ID does not match")
        assertEquals(0, dependencies.installCalls)
        assertNull(dependencies.decision)
        assertFalse(requestPermission(preinstaller, extension(), mutableListOf()))
    }

    @Test
    fun `registry query failures before and after installation remain visible and block readiness`() = runTest {
        for (query in listOf(1, 2)) {
            val dependencies = FakeDependencies().apply { failingRegistryQuery = query }
            val preinstaller = LibreWolfUboPreinstaller(dependencies, backgroundScope)
            val navigation = backgroundScope.async { preinstaller.awaitReady() }

            preinstaller.start()
            runCurrent()

            assertFailed(preinstaller, "registry unavailable")
            assertFalse(navigation.isCompleted)
            assertEquals(if (query == 1) 0 else 1, dependencies.installCalls)
            assertEquals(if (query == 1) null else "attempted", dependencies.decision)
            assertFalse(requestPermission(preinstaller, extension(), mutableListOf()))
        }
    }

    @Test
    fun `failed install remains failed until retry and never records completion`() = runTest {
        val dependencies = FakeDependencies().apply { installFailure = IOException("signature rejected") }
        val preinstaller = LibreWolfUboPreinstaller(dependencies, backgroundScope)

        preinstaller.start()
        runCurrent()

        assertFailed(preinstaller, "signature rejected")
        assertEquals("attempted", dependencies.decision)
        assertFalse(requestPermission(preinstaller, extension(), mutableListOf()))
        preinstaller.start()
        runCurrent()
        assertEquals(1, dependencies.installCalls)

        dependencies.installFailure = null
        preinstaller.retry()
        runCurrent()

        assertEquals(2, dependencies.installCalls)
        assertEquals(State.Ready(installed = true, enabled = true), preinstaller.state.value)
    }

    @Test
    fun `install callback alone is insufficient when the registry is absent or disabled`() = runTest {
        for (result in listOf(null, Installed(enabled = false, version = VERSION))) {
            val dependencies = FakeDependencies().apply { installedResult = result }
            val preinstaller = LibreWolfUboPreinstaller(dependencies, backgroundScope)

            preinstaller.start()
            runCurrent()

            assertTrue(preinstaller.state.value is State.Failed)
            assertEquals("attempted", dependencies.decision)
            assertTrue(dependencies.filteringVersions.isEmpty())
        }
    }

    @Test
    fun `filtering readiness failure keeps navigation blocked after a successful install`() = runTest {
        val dependencies = FakeDependencies().apply { filteringFailure = IOException("filter engine not ready") }
        val preinstaller = LibreWolfUboPreinstaller(dependencies, backgroundScope)
        val navigation = backgroundScope.async { preinstaller.awaitReady() }

        preinstaller.start()
        runCurrent()

        assertFailed(preinstaller, "filter engine not ready")
        assertFalse(navigation.isCompleted)
        assertEquals(Installed(enabled = true, version = VERSION), dependencies.registry)
        assertEquals("attempted", dependencies.decision)
    }

    @Test
    fun `timeout cancels the active install and revokes permission trust`() = runTest {
        val dependencies = FakeDependencies().apply { installBarrier = CompletableDeferred() }
        val preinstaller = LibreWolfUboPreinstaller(dependencies, backgroundScope, timeoutMillis = 1_000)
        preinstaller.start()
        runCurrent()

        advanceTimeBy(1_000)
        runCurrent()

        assertTrue(preinstaller.state.value is State.Failed)
        assertEquals(1, dependencies.cancelledInstalls)
        assertEquals("attempted", dependencies.decision)
        assertFalse(requestPermission(preinstaller, extension(), mutableListOf()))
        dependencies.installBarrier!!.complete(Unit)
        runCurrent()
        assertNull(dependencies.registry)
        assertTrue(preinstaller.state.value is State.Failed)
    }

    @Test
    fun `restart recovers installation committed before completion marker without reinstalling`() = runTest {
        val dependencies = FakeDependencies().apply { completionFailure = IOException("marker write interrupted") }
        val first = LibreWolfUboPreinstaller(dependencies, backgroundScope)
        first.start()
        runCurrent()

        assertFailed(first, "marker write interrupted")
        assertEquals("attempted", dependencies.decision)
        assertEquals(Installed(enabled = true, version = VERSION), dependencies.registry)

        dependencies.completionFailure = null
        val restarted = LibreWolfUboPreinstaller(dependencies, backgroundScope)
        restarted.start()
        runCurrent()

        assertEquals(State.Ready(installed = true, enabled = true), restarted.state.value)
        assertEquals("complete", dependencies.decision)
        assertEquals(1, dependencies.prepareCalls)
        assertEquals(1, dependencies.installCalls)
        assertEquals(listOf(VERSION, VERSION), dependencies.filteringVersions)
    }

    @Test
    fun `permission trust requires a verified active transaction and exact ID version and file URI`() = runTest {
        val dependencies = FakeDependencies().apply {
            prepareBarrier = CompletableDeferred()
            installBarrier = CompletableDeferred()
            filteringBarrier = CompletableDeferred()
        }
        val preinstaller = LibreWolfUboPreinstaller(dependencies, backgroundScope)
        val approvals = mutableListOf<PermissionPromptResponse>()

        assertFalse(requestPermission(preinstaller, extension(), approvals))
        preinstaller.start()
        runCurrent()
        assertFalse(requestPermission(preinstaller, extension(), approvals))
        dependencies.prepareBarrier!!.complete(Unit)
        runCurrent()

        for (untrusted in listOf(
            extension(extensionId = "other@example.invalid"),
            extension(extensionVersion = "1.73.0"),
            extension(extensionVersion = null),
            extension(extensionUrl = "file:///private/different.xpi"),
            extension(extensionUrl = "https://addons.mozilla.org/ublock_origin.xpi"),
        )) {
            assertFalse(requestPermission(preinstaller, untrusted, approvals))
        }
        assertTrue(approvals.isEmpty())
        assertTrue(requestPermission(preinstaller, extension(), approvals))
        assertEquals(
            listOf(
                PermissionPromptResponse(
                    isPermissionsGranted = true,
                    isPrivateModeGranted = true,
                    isTechnicalAndInteractionDataGranted = false,
                ),
            ),
            approvals,
        )
        assertFalse(requestPermission(preinstaller, extension(), approvals))
        assertEquals(1, approvals.size)

        dependencies.installBarrier!!.complete(Unit)
        runCurrent()
        assertEquals(State.Preparing, preinstaller.state.value)
        assertFalse(requestPermission(preinstaller, extension(), approvals))
        dependencies.filteringBarrier!!.complete(Unit)
        runCurrent()
        assertFalse(requestPermission(preinstaller, extension(), approvals))
        assertEquals(1, approvals.size)
    }

    private fun withTemporaryAsset(test: (File) -> Unit) {
        val directory = Files.createTempDirectory("librewolf-ubo-verifier-").toFile()
        val destination = File(directory, "asset.xpi")
        try {
            test(destination)
        } finally {
            destination.setWritable(true)
            directory.deleteRecursively()
        }
    }

    private fun assertFailed(preinstaller: LibreWolfUboPreinstaller, reason: String) {
        val state = preinstaller.state.value
        assertTrue("Expected a visible failure, got $state", state is State.Failed)
        assertTrue((state as State.Failed).reason.contains(reason))
    }

    private fun extension(
        extensionId: String = ID,
        extensionUrl: String = FILE_URI,
        extensionVersion: String? = VERSION,
    ): WebExtension {
        val metadata = extensionVersion?.let { value ->
            mockk<Metadata> { every { version } returns value }
        }
        return mockk {
            every { id } returns extensionId
            every { url } returns extensionUrl
            every { getMetadata() } returns metadata
        }
    }

    private fun requestPermission(
        preinstaller: LibreWolfUboPreinstaller,
        extension: WebExtension,
        approvals: MutableList<PermissionPromptResponse>,
    ) = preinstaller.onInstallPermissionRequest(
        extension = extension,
        permissions = listOf("webRequest", "webRequestBlocking"),
        origins = listOf("<all_urls>"),
        dataCollectionPermissions = emptyList(),
        onConfirm = { approvals.add(it) },
    )

    /** Models durable decisions and Gecko registry state across coordinator instances. */
    private class FakeDependencies : LibreWolfUboPreinstaller.Dependencies {
        var decision: String? = null
        var registry: Installed? = null
        var asset = VerifiedAsset(ID, VERSION, FILE_URI)
        var installedResult: Installed? = Installed(enabled = true, version = VERSION)
        var prepareBarrier: CompletableDeferred<Unit>? = null
        var installBarrier: CompletableDeferred<Unit>? = null
        var filteringBarrier: CompletableDeferred<Unit>? = null
        var prepareFailure: Exception? = null
        var installFailure: Exception? = null
        var filteringFailure: Exception? = null
        var completionFailure: Exception? = null
        var failingRegistryQuery: Int? = null
        var prepareCalls = 0
        var installCalls = 0
        var cancelledInstalls = 0
        private var registryQueries = 0
        val decisionsAtInstall = mutableListOf<String?>()
        val filteringVersions = mutableListOf<String>()

        override suspend fun readDecision() = decision

        override suspend fun writeDecision(decision: String) {
            if (decision == "complete") completionFailure?.let { throw it }
            this.decision = decision
        }

        override suspend fun installed(): Installed? {
            registryQueries++
            if (registryQueries == failingRegistryQuery) throw IOException("registry unavailable")
            return registry
        }

        override suspend fun prepareAsset(): VerifiedAsset {
            prepareCalls++
            prepareBarrier?.await()
            prepareFailure?.let { throw it }
            return asset
        }

        override suspend fun install(asset: VerifiedAsset) {
            installCalls++
            decisionsAtInstall.add(decision)
            try {
                installBarrier?.await()
                installFailure?.let { throw it }
                registry = installedResult
            } catch (exception: CancellationException) {
                cancelledInstalls++
                throw exception
            }
        }

        override suspend fun awaitFilteringReady(version: String) {
            filteringVersions.add(version)
            filteringBarrier?.await()
            filteringFailure?.let { throw it }
        }
    }

    private companion object {
        const val ABC_SHA256 = "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        const val ID = "uBlock0@raymondhill.net"
        const val VERSION = "1.74.0"
        const val FILE_URI = "file:///private/verified-ublock-origin.xpi"
    }
}
