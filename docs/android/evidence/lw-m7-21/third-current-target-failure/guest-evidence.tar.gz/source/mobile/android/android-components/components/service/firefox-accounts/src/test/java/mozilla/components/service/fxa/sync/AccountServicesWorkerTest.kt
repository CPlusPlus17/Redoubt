/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package mozilla.components.service.fxa.sync

import android.content.Context
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.work.ListenableWorker
import androidx.work.testing.TestListenableWorkerBuilder
import kotlinx.coroutines.test.runTest
import mozilla.components.service.fxa.AccountServices
import mozilla.components.support.test.robolectric.testContext
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class AccountServicesWorkerTest {
    @After
    fun tearDown() {
        AccountServices.initialize(testContext, defaultEnabled = true)
    }

    @Test
    fun `old sync work exits successfully before stores Rust and retry logic while off`() = runTest {
        testContext.getSharedPreferences(AccountServices.PREFERENCES, Context.MODE_PRIVATE).edit().clear().commit()
        AccountServices.initialize(testContext, defaultEnabled = false)
        setLastSynced(testContext, 42)
        val worker = TestListenableWorkerBuilder<WorkManagerSyncWorker>(testContext).build()
        assertEquals(ListenableWorker.Result.success(), worker.doWork())
        assertEquals(42L, getLastSynced(testContext))
        clearSyncState(testContext)
    }
}
