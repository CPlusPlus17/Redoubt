/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.fenix.components

import io.mockk.every
import io.mockk.mockk
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import mozilla.components.browser.state.action.BrowserAction
import mozilla.components.browser.state.action.EngineAction
import mozilla.components.browser.state.action.RestoreCompleteAction
import mozilla.components.browser.state.state.BrowserState
import mozilla.components.lib.state.Store
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.mozilla.fenix.components.LibreWolfUboPreinstaller.State

@OptIn(ExperimentalCoroutinesApi::class)
class LibreWolfUboPreinstallMiddlewareTest {
    @Test
    fun `navigation queued through preparation and failure replays once in order after retry`() = runTest {
        val gate = FakeGate()
        val middleware = LibreWolfUboPreinstallMiddleware(gate, backgroundScope)
        val store = mockk<Store<BrowserState, BrowserAction>>()
        val dispatched = mutableListOf<BrowserAction>()
        val delivered = mutableListOf<BrowserAction>()
        every { store.dispatch(any()) } answers {
            val action = firstArg<BrowserAction>()
            dispatched.add(action)
            middleware.invoke(store, { delivered.add(it) }, action)
        }
        val incoming = EngineAction.CreateEngineSessionAction("incoming-url")
        val restored = EngineAction.CreateEngineSessionAction("restored-tab", skipLoading = true)
        val custom = EngineAction.CreateEngineSessionAction("custom-tab", includeParent = true)

        middleware.invoke(store, { delivered.add(it) }, incoming)
        middleware.invoke(store, { delivered.add(it) }, restored)
        runCurrent()
        assertTrue(delivered.isEmpty())
        assertTrue(dispatched.isEmpty())
        assertEquals(1, gate.waiters)

        gate.state.value = State.Failed("installation needs retry")
        middleware.invoke(store, { delivered.add(it) }, custom)
        runCurrent()
        assertTrue(delivered.isEmpty())
        assertTrue(dispatched.isEmpty())
        assertEquals(1, gate.waiters)

        gate.state.value = State.Preparing
        runCurrent()
        assertTrue(delivered.isEmpty())
        gate.state.value = State.Ready(installed = true, enabled = true)
        runCurrent()

        assertEquals(listOf(incoming, restored, custom), dispatched)
        assertEquals(listOf(incoming, restored, custom), delivered)

        gate.state.value = State.Ready(installed = false, enabled = false)
        runCurrent()
        assertEquals(listOf(incoming, restored, custom), dispatched)
        assertEquals(listOf(incoming, restored, custom), delivered)
    }

    @Test
    fun `creation arriving at readiness cannot overtake already queued navigation`() = runTest {
        val gate = FakeGate()
        val middleware = LibreWolfUboPreinstallMiddleware(gate, backgroundScope)
        val store = mockk<Store<BrowserState, BrowserAction>>()
        val delivered = mutableListOf<BrowserAction>()
        every { store.dispatch(any()) } answers {
            middleware.invoke(store, { delivered.add(it) }, firstArg())
        }
        val first = EngineAction.CreateEngineSessionAction("first")
        val second = EngineAction.CreateEngineSessionAction("second")
        val afterReady = EngineAction.CreateEngineSessionAction("arrived-before-replay")
        middleware.invoke(store, { delivered.add(it) }, first)
        middleware.invoke(store, { delivered.add(it) }, second)
        runCurrent()

        gate.state.value = State.Ready(installed = true, enabled = true)
        // Intentionally invoke before the scheduled readiness waiter runs.
        middleware.invoke(store, { delivered.add(it) }, afterReady)
        runCurrent()

        assertEquals(listOf(first, second, afterReady), delivered)
    }

    @Test
    fun `non-session actions remain available while provisioning has failed`() = runTest {
        val gate = FakeGate().apply { state.value = State.Failed("retry required") }
        val middleware = LibreWolfUboPreinstallMiddleware(gate, backgroundScope)
        val delivered = mutableListOf<BrowserAction>()
        val store = mockk<Store<BrowserState, BrowserAction>>()

        middleware.invoke(store, { delivered.add(it) }, RestoreCompleteAction)
        runCurrent()

        assertEquals(listOf(RestoreCompleteAction), delivered)
        assertEquals(0, gate.waiters)
    }

    @Test
    fun `ready state permits new sessions when the user removed or disabled the extension`() = runTest {
        for (ready in listOf(
            State.Ready(installed = false, enabled = false),
            State.Ready(installed = true, enabled = false),
        )) {
            val gate = FakeGate().apply { state.value = ready }
            val middleware = LibreWolfUboPreinstallMiddleware(gate, backgroundScope)
            val store = mockk<Store<BrowserState, BrowserAction>>()
            val delivered = mutableListOf<BrowserAction>()
            val action = EngineAction.CreateEngineSessionAction("user-choice")

            middleware.invoke(store, { delivered.add(it) }, action)
            runCurrent()

            assertEquals(listOf(action), delivered)
            assertEquals(0, gate.waiters)
        }
    }

    private class FakeGate : LibreWolfUboStartupGate {
        override val state = MutableStateFlow<State>(State.Preparing)
        var waiters = 0

        override suspend fun awaitReady() {
            waiters++
            state.first { it is State.Ready }
        }
    }
}
