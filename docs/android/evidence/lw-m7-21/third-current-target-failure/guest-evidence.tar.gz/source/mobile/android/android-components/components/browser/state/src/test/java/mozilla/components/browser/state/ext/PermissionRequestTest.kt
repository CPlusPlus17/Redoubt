/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package mozilla.components.browser.state.ext

import mozilla.components.concept.engine.permission.OriginBoundPermissionRequest
import mozilla.components.concept.engine.permission.Permission
import mozilla.components.concept.engine.permission.PermissionRequest
import mozilla.components.support.test.mock
import mozilla.components.support.test.whenever
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.mockito.Mockito.never
import org.mockito.Mockito.verify

class PermissionRequestTest {
    @Test
    fun `two documents at the same origin must keep independent origin-bound decisions`() {
        val first = request("document-1")
        val second = request("document-2")
        val pending = listOf(first)
        assertFalse(pending.containsPermission(second))
        pending.mergePermissions(second)
        verify(first, never()).merge(second)
        assertTrue(pending.containsPermission(first))
    }

    @Test
    fun `legacy permissions continue to merge by URI and permission kind`() {
        val first = mock<PermissionRequest>()
        val second = mock<PermissionRequest>()
        listOf(first, second).forEach {
            whenever(it.uri).thenReturn("https://example.test")
            whenever(it.permissions).thenReturn(listOf(Permission.ContentGeoLocation()))
        }
        assertTrue(listOf(first).containsPermission(second))
        listOf(first).mergePermissions(second)
        verify(first).merge(second)
    }

    private fun request(id: String): OriginBoundPermissionRequest = mock<OriginBoundPermissionRequest>().also {
        whenever(it.id).thenReturn(id)
        whenever(it.uri).thenReturn("https://example.test")
        whenever(it.permissions).thenReturn(listOf(Permission.ContentWebGL()))
    }
}
