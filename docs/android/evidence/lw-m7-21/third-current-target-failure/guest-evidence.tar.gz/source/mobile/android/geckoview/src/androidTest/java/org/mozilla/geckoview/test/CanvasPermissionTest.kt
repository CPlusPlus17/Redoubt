/* Any copyright is dedicated to the Public Domain.
   http://creativecommons.org/publicdomain/zero/1.0/ */

package org.mozilla.geckoview.test

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.MediumTest
import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSession.PermissionDelegate
import org.mozilla.geckoview.GeckoSession.PermissionDelegate.ContentPermission
import org.mozilla.geckoview.GeckoSession.PermissionDelegate.PermissionDecision
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.StorageController
import org.mozilla.geckoview.test.rule.GeckoSessionTestRule.WithDisplay
import org.mozilla.geckoview.test.util.TestServer

/** Native permission enforcement and document-identity integration tests. */
@RunWith(AndroidJUnit4::class)
@MediumTest
@WithDisplay(width = 100, height = 100)
class CanvasPermissionTest : BaseSessionTest() {
    private val storage get() = sessionRule.runtime.storageController
    private lateinit var requested: GeckoResult<ContentPermission>
    private lateinit var answer: GeckoResult<PermissionDecision>

    @Before
    fun prepare() {
        sessionRule.waitForResult(storage.clearData(StorageController.ClearFlags.PERMISSIONS))
        sessionRule.setPrefsUntilTestEnd(
            mapOf(
                "librewolf.webgl.prompt" to true,
                "librewolf.webgl.prompt.hide" to true,
                "privacy.resistFingerprinting" to false,
                "privacy.fingerprintingProtection" to true,
                "privacy.fingerprintingProtection.pbmode" to true,
                "privacy.fingerprintingProtection.overrides" to
                    "-AllTargets,+CanvasImageExtractionPrompt,+CanvasRandomization,+CanvasExtractionBeforeUserInputIsBlocked",
            ),
        )
        nextRequest()
        sessionRule.delegateUntilTestEnd(
            object : PermissionDelegate {
                override fun onContentPermissionRequestWithOptions(
                    session: GeckoSession,
                    perm: ContentPermission,
                ): GeckoResult<PermissionDecision> {
                    requested.complete(perm)
                    return answer
                }
            },
        )
        mainSession.loadTestPath(HELLO_HTML_PATH)
        mainSession.waitForPageStop()
    }

    private fun nextRequest() {
        requested = GeckoResult()
        answer = GeckoResult()
    }

    private fun allow(perm: ContentPermission, permanent: Boolean = false) {
        answer.complete(PermissionDecision(ContentPermission.VALUE_ALLOW, permanent))
        assertTrue(sessionRule.waitForResult(perm.awaitDecisionApplied()))
    }

    private fun revoke(perm: ContentPermission) {
        val current = sessionRule.waitForResult(storage.allPermissions).single {
            it.principalOrigin == perm.principalOrigin && it.permission == perm.permission
        }
        sessionRule.waitForResult(storage.setPermissionWithLifetime(current, ContentPermission.VALUE_PROMPT, false))
    }

    private fun worker(expression: String, transfer: Boolean = false): String = """
        new Promise((resolve, reject) => {
          const source = 'onmessage = event => { try { Promise.resolve(' + ${org.json.JSONObject.quote(expression)} + ').then(value => postMessage(value), e => postMessage({error:String(e)})); } catch (e) { postMessage({error:String(e)}); } };';
          const url = URL.createObjectURL(new Blob([source], {type: 'text/javascript'}));
          const worker = new Worker(url);
          worker.onmessage = event => {
            worker.terminate(); URL.revokeObjectURL(url);
            event.data && event.data.error ? reject(event.data.error) : resolve(event.data);
          };
          worker.onerror = reject;
          if ($transfer) {
            const canvas = document.createElement('canvas').transferControlToOffscreen();
            worker.postMessage({canvas}, [canvas]);
          } else {
            worker.postMessage(null);
          }
        })
    """.trimIndent()

    @Test
    fun webglOneAndTwoDomOffscreenAndWorkerRequireMatchingGrant() {
        for (kind in listOf("webgl", "webgl2")) {
            for (mode in listOf("dom", "offscreen", "worker", "nested-worker", "transferred-worker")) {
                nextRequest()
                val expression = if (mode == "dom") {
                    "!!document.createElement('canvas').getContext('$kind')"
                } else if (mode == "transferred-worker") {
                    "!!event.data.canvas.getContext('$kind')"
                } else {
                    "!!new OffscreenCanvas(64,64).getContext('$kind')"
                }
                val script = when (mode) {
                    "worker" -> worker(expression)
                    "nested-worker" -> worker(worker(expression))
                    "transferred-worker" -> worker(expression, transfer = true)
                    else -> expression
                }
                assertEquals("Unknown $kind/$mode must be blocked", false, mainSession.waitForJS(script))
                val perm = sessionRule.waitForResult(requested)
                assertEquals(PermissionDelegate.PERMISSION_WEBGL, perm.permission)
                assertTrue(perm.isQuiet)
                assertEquals(mainSession.evaluateJS("location.origin"), perm.uri)
                allow(perm)
                assertEquals("Matching grant must restore $kind/$mode", true, mainSession.waitForJS(script))
                revoke(perm)
                assertEquals("Revoke must affect new contexts", false, mainSession.waitForJS(script))
                mainSession.reload()
                mainSession.waitForPageStop()
            }
        }
    }

    @Test
    fun realCanvasPixelsRequireGrantIncludingOffscreenWorkers() {
        for (mode in listOf("dom", "offscreen", "worker", "nested-worker", "transferred-worker")) {
            nextRequest()
            val canvas = when (mode) {
                "dom" -> "document.createElement('canvas')"
                "transferred-worker" -> "event.data.canvas"
                else -> "new OffscreenCanvas(64,64)"
            }
            val expression = """
                (() => {
                  const canvas = $canvas; canvas.width = canvas.height = 64;
                  const ctx = canvas.getContext('2d');
                  ctx.fillStyle = 'rgb(17,91,203)'; ctx.fillRect(0,0,64,64);
                  return Array.from(ctx.getImageData(0,0,64,64).data).join(',');
                })()
            """.trimIndent()
            val script = when (mode) {
                "worker" -> worker(expression)
                "nested-worker" -> worker(worker(expression))
                "transferred-worker" -> worker(expression, transfer = true)
                else -> expression
            }
            val expected = List(64 * 64) { "17,91,203,255" }.joinToString(",")
            assertNotEquals("Readback must be protected for $mode", expected, mainSession.waitForJS(script))
            val perm = sessionRule.waitForResult(requested)
            assertEquals(PermissionDelegate.PERMISSION_CANVAS, perm.permission)
            assertTrue("Pre-gesture request stays quiet", perm.isQuiet)
            allow(perm)
            assertEquals("Grant returns actual $mode pixels", expected, mainSession.waitForJS(script))
            revoke(perm)
            assertNotEquals("Revoke restores protection", expected, mainSession.waitForJS(script))
            mainSession.reload()
            mainSession.waitForPageStop()
        }
    }

    @Test
    fun webglRenderingReadbackRequiresBothPermissions() {
        for (kind in listOf("webgl", "webgl2")) {
            nextRequest()
            mainSession.evaluateJS("document.createElement('canvas').getContext('$kind')")
            val webgl = sessionRule.waitForResult(requested)
            allow(webgl)
            nextRequest()
            val script = """
                (() => {
                  const canvas = document.createElement('canvas'); canvas.width = canvas.height = 64;
                  const gl = canvas.getContext('$kind', {preserveDrawingBuffer:true});
                  if (!gl) throw new Error('Granted WebGL context is unavailable');
                  gl.clearColor(1,0,0,1); gl.clear(gl.COLOR_BUFFER_BIT);
                  const pixels = new Uint8Array(64*64*4);
                  gl.readPixels(0,0,64,64,gl.RGBA,gl.UNSIGNED_BYTE,pixels);
                  return Array.from(pixels).join(',');
                })()
            """.trimIndent()
            val expected = List(64 * 64) { "255,0,0,255" }.joinToString(",")
            assertNotEquals("WebGL grant alone cannot expose canvas pixels", expected, mainSession.evaluateJS(script))
            val canvas = sessionRule.waitForResult(requested)
            assertEquals(PermissionDelegate.PERMISSION_CANVAS, canvas.permission)
            allow(canvas)
            assertEquals("Both grants restore actual rendered pixels", expected, mainSession.evaluateJS(script))
            revoke(canvas)
            assertNotEquals("Canvas revoke protects WebGL readPixels", expected, mainSession.evaluateJS(script))
            revoke(webgl)
            mainSession.reload()
            mainSession.waitForPageStop()
        }
    }

    @Test
    fun storedSnapshotsCannotReloadOrRecreateRevokedException() {
        mainSession.evaluateJS("document.createElement('canvas').getContext('webgl')")
        val request = sessionRule.waitForResult(requested)
        allow(request)
        val stored = sessionRule.waitForResult(storage.allPermissions).single {
            it.permission == PermissionDelegate.PERMISSION_WEBGL
        }
        val restored = requireNotNull(ContentPermission.fromJson(stored.toJson()))
        assertEquals(stored.principalOrigin, restored.principalOrigin)
        assertEquals(stored.expireType, restored.expireType)
        assertFalse(sessionRule.waitForResult(restored.awaitDecisionApplied()))
        assertFalse(sessionRule.waitForResult(restored.reloadIfCurrent()))
        revoke(stored)
        val failed = storage.setPermissionWithLifetime(stored, ContentPermission.VALUE_ALLOW, true).then<Boolean>(
            { GeckoResult.fromValue(false) },
            { GeckoResult.fromValue(true) },
        )
        assertTrue("Revoked snapshot must be rejected", sessionRule.waitForResult(failed))
        assertTrue(sessionRule.waitForResult(storage.allPermissions).none { it.permission == PermissionDelegate.PERMISSION_WEBGL })
    }

    @Test
    fun navigationRejectsOldDecisionEvenAtSameOrigin() {
        mainSession.evaluateJS("document.createElement('canvas').getContext('webgl')")
        val perm = sessionRule.waitForResult(requested)
        mainSession.reload()
        mainSession.waitForPageStop()
        answer.complete(PermissionDecision(ContentPermission.VALUE_ALLOW, true))
        assertFalse(sessionRule.waitForResult(perm.awaitDecisionApplied()))
        assertFalse(sessionRule.waitForResult(perm.reloadIfCurrent()))
        assertTrue(sessionRule.waitForResult(storage.allPermissions).none { it.permission == PermissionDelegate.PERMISSION_WEBGL })
    }

    @Test
    fun privateGrantStaysSessionOnlyAndDoesNotChangeNormalException() {
        mainSession.evaluateJS("document.createElement('canvas').getContext('webgl')")
        val normal = sessionRule.waitForResult(requested)
        allow(normal, permanent = true)
        val privateSession = sessionRule.createOpenSession(
            GeckoSessionSettings.Builder(mainSession.settings).usePrivateMode(true).build(),
        )
        privateSession.loadTestPath(HELLO_HTML_PATH)
        privateSession.waitForPageStop()
        nextRequest()
        assertEquals(false, privateSession.evaluateJS("!!document.createElement('canvas').getContext('webgl')"))
        val privatePerm = sessionRule.waitForResult(requested)
        assertTrue(privatePerm.privateMode)
        assertNotEquals(normal.principalOrigin, privatePerm.principalOrigin)
        allow(privatePerm, permanent = true)
        val records = sessionRule.waitForResult(storage.allPermissions).filter { it.permission == PermissionDelegate.PERMISSION_WEBGL }
        assertEquals(0, records.single { !it.privateMode }.expireType)
        assertEquals(2, records.single { it.privateMode }.expireType)
        revoke(privatePerm)
        assertEquals(true, mainSession.evaluateJS("!!document.createElement('canvas').getContext('webgl')"))
        assertEquals(false, privateSession.evaluateJS("!!document.createElement('canvas').getContext('webgl')"))
        privateSession.close()
    }

    @Test
    fun crossOriginFrameGrantDoesNotGrantParentOrAnotherPort() {
        sessionRule.setPrefsUntilTestEnd(mapOf("network.dns.localDomains" to "localhost,child.localhost"))
        val alternate = TestServer(
            InstrumentationRegistry.getInstrumentation().targetContext,
            responseModifiers = mapOf(
                HELLO_HTML_PATH to TestServer.ResponseModifier { html ->
                    html + "<script>document.createElement('canvas').getContext('webgl');</script>"
                },
            ),
        )
        alternate.start(4246)
        try {
            val frameOrigin = "http://child.localhost:4246"
            mainSession.evaluateJS(
                "window.topDocumentMarker='still-current'; const f=document.createElement('iframe'); " +
                    "f.src='$frameOrigin$HELLO_HTML_PATH'; document.body.appendChild(f);",
            )
            val frame = sessionRule.waitForResult(requested)
            assertEquals(frameOrigin, frame.uri)
            assertEquals(mainSession.evaluateJS("location.origin"), frame.topLevelOrigin)
            allow(frame)
            assertTrue(sessionRule.waitForResult(frame.reloadIfCurrent()))
            assertEquals("still-current", mainSession.evaluateJS("window.topDocumentMarker"))
            nextRequest()
            assertEquals(false, mainSession.evaluateJS("!!document.createElement('canvas').getContext('webgl')"))
            val parent = sessionRule.waitForResult(requested)
            assertNotEquals(frame.principalOrigin, parent.principalOrigin)
            answer.complete(PermissionDecision(ContentPermission.VALUE_DENY, false))
            assertTrue(sessionRule.waitForResult(parent.awaitDecisionApplied()))

            val anotherPort = sessionRule.createOpenSession()
            anotherPort.loadUri(createTestUrl(HELLO_HTML_PATH).replace("localhost", "child.localhost"))
            anotherPort.waitForPageStop()
            nextRequest()
            assertEquals(false, anotherPort.evaluateJS("!!document.createElement('canvas').getContext('webgl')"))
            val other = sessionRule.waitForResult(requested)
            assertEquals("http://child.localhost:4245", other.uri)
            answer.complete(PermissionDecision(ContentPermission.VALUE_DENY, false))
            assertTrue(sessionRule.waitForResult(other.awaitDecisionApplied()))
            anotherPort.close()
        } finally {
            alternate.stop()
        }
    }

    @Test
    fun acknowledgedFrameReloadDoesNotReloadTopDocument() {
        mainSession.evaluateJS(
            """
                window.topDocumentMarker = 'still-current';
                const frame = document.createElement('iframe');
                frame.srcdoc = '<script>document.createElement("canvas").getContext("webgl");<\/script>';
                document.body.appendChild(frame);
            """.trimIndent(),
        )
        val perm = sessionRule.waitForResult(requested)
        allow(perm)
        assertTrue(sessionRule.waitForResult(perm.reloadIfCurrent()))
        assertEquals("still-current", mainSession.evaluateJS("window.topDocumentMarker"))
        assertFalse("A request cannot trigger duplicate reload", sessionRule.waitForResult(perm.reloadIfCurrent()))
    }
}
