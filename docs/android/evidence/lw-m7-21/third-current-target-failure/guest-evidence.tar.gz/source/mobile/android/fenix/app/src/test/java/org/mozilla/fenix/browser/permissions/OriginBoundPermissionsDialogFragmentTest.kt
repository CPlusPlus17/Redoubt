/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.fenix.browser.permissions

import android.view.View
import mozilla.components.browser.state.state.BrowserState
import mozilla.components.browser.state.state.ContentState
import mozilla.components.browser.state.state.TabSessionState
import mozilla.components.support.test.robolectric.testContext
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class OriginBoundPermissionsDialogFragmentTest {
    @Test
    fun `frame explanation names the exact requesting scheme and port plus the top site`() {
        val request = OriginRequest()
        val message = originBoundRequestMessage(testContext, request.permission, request.topLevelOrigin)
        assertTrue(message.contains("https://frame.test:8443"))
        assertTrue(message.contains("https://top.test"))
        assertFalse(message.contains("http://frame.test"))
    }

    @Test
    fun `private permission never shows a checked persistent choice even for malformed persistent input`() {
        val permission = OriginRequest(privateMode = true).permission.copy(permanent = true)
        val checkbox = originBoundRememberChoice(testContext, permission)
        assertEquals(View.GONE, checkbox.visibility)
        assertFalse(checkbox.isChecked)
    }

    @Test
    fun `session and remembered permissions expose their actual lifetime`() {
        val session = OriginRequest().permission
        assertFalse(originBoundRememberChoice(testContext, session).isChecked)
        assertTrue(originBoundRememberChoice(testContext, session.copy(permanent = true)).isChecked)
    }

    @Test
    fun `normal settings exclude private and other container requests`() {
        val normal = OriginRequest(id = "normal")
        val privateRequest = OriginRequest(privateMode = true, id = "private")
        val container = OriginRequest(contextId = "other", id = "container")
        val requests = listOf(normal, privateRequest, container)
        val state = BrowserState(tabs = requests.map { request ->
            TabSessionState(
                request.id,
                ContentState("https://top.test", private = request.permission.privateMode, permissionRequestsList = listOf(request)),
                contextId = request.permission.contextId,
            )
        })
        assertEquals(listOf("normal"), originBoundRequests(state, null, false, null).map { it.second.id })
        assertEquals(listOf("private"), originBoundRequests(state, null, true, null).map { it.second.id })
        assertEquals(listOf("container"), originBoundRequests(state, null, false, "other").map { it.second.id })
        assertTrue(originBoundRequests(state, "normal", true, null).isEmpty())
    }
}
