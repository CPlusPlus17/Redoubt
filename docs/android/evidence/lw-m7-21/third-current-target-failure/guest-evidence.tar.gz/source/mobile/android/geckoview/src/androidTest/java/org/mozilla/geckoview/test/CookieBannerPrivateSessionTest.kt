/* Any copyright is dedicated to the Public Domain.
   http://creativecommons.org/publicdomain/zero/1.0/ */

package org.mozilla.geckoview.test

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.MediumTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.test.util.UiThreadUtils

/** Test-only native/transport lifetime checks, separate from release UI acceptance. */
@RunWith(AndroidJUnit4::class)
@MediumTest
class CookieBannerPrivateSessionTest : BaseSessionTest() {
    private val storage get() = sessionRule.runtime.storageController

    @Before
    fun configure() {
        sessionRule.setPrefsUntilTestEnd(
            mapOf("cookiebanners.service.mode" to 1, "cookiebanners.service.mode.privateBrowsing" to 1),
        )
    }

    private fun openPrivate(): GeckoSession = sessionRule.createOpenSession(
        GeckoSessionSettings.Builder(mainSession.settings).usePrivateMode(true).build(),
    ).also {
        it.loadTestPath(HELLO_HTML_PATH)
        it.waitForPageStop()
    }

    private fun closeLastPrivate(session: GeckoSession) {
        session.close()
        // Wait on actual native inactivity, not a sleep or a forged teardown event.
        UiThreadUtils.waitForCondition({
            try {
                sessionRule.waitForResult(storage.getCookieBannerPrivateSessionToken())
                false
            } catch (error: RuntimeException) {
                assertTrue("Only native inactivity proves teardown", "$error ${error.cause}".contains("NS_ERROR_NOT_AVAILABLE"))
                true
            }
        }, 10_000)
    }

    private fun fails(result: GeckoResult<Void>) {
        var failed = false
        try {
            sessionRule.waitForResult(result)
        } catch (error: RuntimeException) {
            assertTrue("Only native stale/inactive rejection is accepted", "$error ${error.cause}".contains("NS_ERROR_NOT_AVAILABLE"))
            failed = true
        }
        assertTrue("The stale private write must fail", failed)
    }

    @Test
    fun delayedWriteAfterLastPrivateContextCannotRepopulateTemporaryException() {
        val session = openPrivate()
        val token = sessionRule.waitForResult(storage.getCookieBannerPrivateSessionToken())
        sessionRule.waitForResult(storage.setCookieBannerModeForPrivateSession(URL, 0, token))
        closeLastPrivate(session)
        fails(storage.setCookieBannerModeForPrivateSession(URL, 0, token))
        val replacement = openPrivate()
        try {
            val fresh = sessionRule.waitForResult(storage.getCookieBannerPrivateSessionToken())
            assertNotEquals(token, fresh)
            assertEquals(1, sessionRule.waitForResult(storage.getCookieBannerModeForPrivateSession(URL, fresh)))
        } finally {
            closeLastPrivate(replacement)
        }
    }

    @Test
    fun oldTokenCannotRemoveOrReplaceANewPrivateSessionChoice() {
        val old = openPrivate()
        val token = sessionRule.waitForResult(storage.getCookieBannerPrivateSessionToken())
        closeLastPrivate(old)
        val freshSession = openPrivate()
        try {
            val fresh = sessionRule.waitForResult(storage.getCookieBannerPrivateSessionToken())
            sessionRule.waitForResult(storage.setCookieBannerModeForPrivateSession(URL, 0, fresh))
            fails(storage.setCookieBannerModeForPrivateSession(URL, 1, token))
            fails(storage.removeCookieBannerModeForPrivateSession(URL, token))
            assertEquals(0, sessionRule.waitForResult(storage.getCookieBannerModeForPrivateSession(URL, fresh)))
            sessionRule.waitForResult(storage.removeCookieBannerModeForPrivateSession(URL, fresh))
            assertEquals(1, sessionRule.waitForResult(storage.getCookieBannerModeForPrivateSession(URL, fresh)))
        } finally {
            closeLastPrivate(freshSession)
        }
    }

    @Test
    fun scopedPrivateChoiceLeavesNormalExceptionUnchanged() {
        sessionRule.waitForResult(storage.setCookieBannerModeForDomain(URL, 0, false))
        val session = openPrivate()
        try {
            val token = sessionRule.waitForResult(storage.getCookieBannerPrivateSessionToken())
            sessionRule.waitForResult(storage.setCookieBannerModeForPrivateSession(URL, 1, token))
            assertEquals(0, sessionRule.waitForResult(storage.getCookieBannerModeForDomain(URL, false)))
            sessionRule.waitForResult(storage.removeCookieBannerModeForPrivateSession(URL, token))
        } finally {
            closeLastPrivate(session)
            sessionRule.waitForResult(storage.removeCookieBannerModeForDomain(URL, false))
        }
    }

    private companion object {
        const val URL = "https://sub.example.org/path"
    }
}
