/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.fenix.settings.cookiebannerhandling

import io.mockk.coEvery
import io.mockk.coVerify
import io.mockk.mockk
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.async
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import mozilla.components.concept.engine.EngineSession.CookieBannerHandlingMode
import mozilla.components.concept.engine.EngineSession.CookieBannerHandlingMode.DISABLED
import mozilla.components.concept.engine.EngineSession.CookieBannerHandlingMode.REJECT_ALL
import mozilla.components.concept.engine.EngineSession.CookieBannerHandlingMode.REJECT_OR_ACCEPT_ALL
import mozilla.components.concept.engine.cookiehandling.CookieBannersStorage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class CookieBannerSiteControllerTest {
    private val storage = mockk<CookieBannersStorage>()
    private var current = true
    private var global = true
    private var reloads = 0
    private var mode: CookieBannerHandlingMode? = REJECT_ALL

    private fun controller(privateMode: Boolean = false): CookieBannerSiteController {
        coEvery { storage.findExceptionFor(URL, privateMode) } answers { mode }
        coEvery { storage.addException(URL, privateMode) } answers { mode = DISABLED }
        coEvery { storage.removeException(URL, privateMode) } answers { mode = REJECT_ALL }
        return CookieBannerSiteController(URL, privateMode, storage, { current }, { global }, { reloads++ })
    }

    @Test
    fun `normal off and reset change only the normal domain exception`() = runTest {
        val controller = controller()
        assertTrue(controller.read()!!)
        assertFalse(controller.setEnabled(false)!!)
        assertTrue(controller.reset()!!)
        assertEquals(2, reloads)
        coVerify(exactly = 1) { storage.addException(URL, false) }
        coVerify(exactly = 1) { storage.removeException(URL, false) }
        coVerify(exactly = 0) { storage.addException(any(), true) }
        coVerify(exactly = 0) { storage.addPersistentExceptionInPrivateMode(any()) }
    }

    @Test
    fun `private choices never use normal or permanent private storage`() = runTest {
        val controller = controller(true)
        assertFalse(controller.setEnabled(false)!!)
        assertTrue(controller.setEnabled(true)!!)
        coVerify(exactly = 1) { storage.addException(URL, true) }
        coVerify(exactly = 1) { storage.removeException(URL, true) }
        coVerify(exactly = 0) { storage.addException(any(), false) }
        coVerify(exactly = 0) { storage.addPersistentExceptionInPrivateMode(any()) }
    }

    @Test
    fun `global off preserves stored domain exceptions`() = runTest {
        val controller = controller()
        global = false
        mode = DISABLED
        assertNull(controller.read())
        assertFailure { controller.reset() }
        assertFailure { controller.setEnabled(false) }
        coVerify(exactly = 0) { storage.findExceptionFor(any(), any()) }
        coVerify(exactly = 0) { storage.removeException(any(), any()) }
        coVerify(exactly = 0) { storage.addException(any(), any()) }
        global = true
        assertFalse(controller.read()!!)
    }

    @Test
    fun `write failure propagates without reload or success`() = runTest {
        val controller = controller()
        coEvery { storage.addException(URL, false) } throws IllegalStateException("disk unavailable")
        assertFailure { controller.setEnabled(false) }
        assertEquals(0, reloads)
        assertTrue(controller.read()!!)
    }

    @Test
    fun `unacknowledged write does not report success or reload`() = runTest {
        val controller = controller()
        val write = CompletableDeferred<Unit>()
        coEvery { storage.addException(URL, false) } coAnswers { write.await(); mode = DISABLED }
        val result = async { controller.setEnabled(false) }
        runCurrent()
        assertFalse(result.isCompleted)
        assertEquals(0, reloads)
        write.complete(Unit)
        assertFalse(result.await()!!)
        assertEquals(1, reloads)
    }

    @Test
    fun `cancelled wait cannot cause a late reload`() = runTest {
        val controller = controller()
        val write = CompletableDeferred<Unit>()
        coEvery { storage.addException(URL, false) } coAnswers { write.await(); mode = DISABLED }
        val result = async { controller.setEnabled(false) }
        runCurrent()
        result.cancel()
        runCurrent()
        write.complete(Unit)
        runCurrent()
        assertTrue(result.isCancelled)
        assertEquals(0, reloads)
        assertTrue(controller.read()!!)
    }

    @Test
    fun `closed or changed tab rejects writes before storage`() = runTest {
        val controller = controller()
        current = false
        assertFailure { controller.setEnabled(false) }
        coVerify(exactly = 0) { storage.addException(any(), any()) }
        assertEquals(0, reloads)
    }

    @Test
    fun `navigation while waiting does not reload the new page`() = runTest {
        val controller = controller()
        coEvery { storage.addException(URL, false) } answers { mode = DISABLED; current = false }
        assertFailure { controller.setEnabled(false) }
        assertEquals(0, reloads)
    }

    @Test
    fun `lost read acknowledgment cannot report a successful write`() = runTest {
        val controller = controller()
        coEvery { storage.findExceptionFor(URL, false) } throws IllegalStateException("read failure")
        assertFailure { controller.setEnabled(false) }
        assertEquals(0, reloads)
    }

    @Test
    fun `unexpected accept mode and unavailable domain fail closed`() = runTest {
        val controller = controller()
        mode = REJECT_OR_ACCEPT_ALL
        assertFailure { controller.read() }
        mode = null
        assertFailure { controller.read() }
    }

    @Test
    fun `write that does not change effective state fails`() = runTest {
        val controller = controller()
        coEvery { storage.addException(URL, false) } returns Unit
        assertFailure { controller.setEnabled(false) }
        assertEquals(0, reloads)
    }

    @Test
    fun `concurrent off and reset serialize acknowledged writes`() = runTest {
        val controller = controller()
        val write = CompletableDeferred<Unit>()
        coEvery { storage.addException(URL, false) } coAnswers { write.await(); mode = DISABLED }
        val off = async { controller.setEnabled(false) }
        runCurrent()
        val reset = async { controller.reset() }
        runCurrent()
        coVerify(exactly = 0) { storage.removeException(any(), any()) }
        write.complete(Unit)
        assertFalse(off.await()!!)
        assertTrue(reset.await()!!)
        assertEquals(2, reloads)
    }

    @Test
    fun `late token for a new session cannot revive the original closed UI`() = runTest {
        val result = CompletableDeferred<CookieBannersStorage>()
        coEvery { storage.forCurrentPrivateSession() } coAnswers { result.await() }
        val captured = async { runCatching { cookieBannerStorageForPage(storage, true) { current } } }
        runCurrent()
        current = false
        result.complete(mockk())
        assertTrue(captured.await().isFailure)
    }

    @Test
    fun `closed UI cannot start native token capture`() = runTest {
        current = false
        assertFailure { cookieBannerStorageForPage(storage, true) { current } }
        coVerify(exactly = 0) { storage.forCurrentPrivateSession() }
    }

    @Test
    fun `normal controls never acquire a private session capability`() = runTest {
        assertEquals(storage, cookieBannerStorageForPage(storage, false) { current })
        coVerify(exactly = 0) { storage.forCurrentPrivateSession() }
    }

    @Test
    fun `inactive private session capture failure is not replaced with unscoped storage`() = runTest {
        coEvery { storage.forCurrentPrivateSession() } throws IllegalStateException("No private session")
        assertFailure { cookieBannerStorageForPage(storage, true) { current } }
    }

    private suspend fun assertFailure(action: suspend () -> Any?) {
        var failed = false
        try { action() } catch (_: IllegalStateException) { failed = true }
        assertTrue("The operation must fail", failed)
    }

    private companion object {
        const val URL = "https://sub.example.org/path"
    }
}
