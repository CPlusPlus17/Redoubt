/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.fenix.settings.deletebrowsingdata

import androidx.appcompat.app.AppCompatActivity
import androidx.preference.CheckBoxPreference
import androidx.preference.SwitchPreferenceCompat
import io.mockk.every
import mozilla.components.support.test.robolectric.testContext
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mozilla.fenix.R
import org.mozilla.fenix.ext.components
import org.mozilla.fenix.settings.requirePreference
import org.mozilla.fenix.utils.Settings
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class DeleteBrowsingDataOnQuitFragmentTest {
    private lateinit var settings: Settings

    @Before
    fun setUp() {
        settings = Settings(testContext)
        every { testContext.components.settings } returns settings
    }

    @Test
    fun `inflated defaults enable only cookies and cache and keep the quit control on`() {
        val fragment = createFragment()
        assertTrue(master(fragment).isChecked)
        assertEquals(setOf(DeleteBrowsingDataOnQuitType.COOKIES, DeleteBrowsingDataOnQuitType.CACHE), checked(fragment))
    }

    @Test
    fun `master off and on preserves the user's existing category selection`() {
        DeleteBrowsingDataOnQuitType.entries.forEach { settings.setDeleteDataOnQuit(it, false) }
        settings.setDeleteDataOnQuit(DeleteBrowsingDataOnQuitType.HISTORY, true)
        val fragment = createFragment()
        changeMaster(fragment, false)
        assertFalse(settings.shouldDeleteBrowsingDataOnQuit)
        assertEquals(setOf(DeleteBrowsingDataOnQuitType.HISTORY), checked(fragment))
        changeMaster(fragment, true)
        assertTrue(settings.shouldDeleteBrowsingDataOnQuit)
        assertEquals(setOf(DeleteBrowsingDataOnQuitType.HISTORY), checked(fragment))
        assertEquals(
            setOf(DeleteBrowsingDataOnQuitType.HISTORY),
            DeleteBrowsingDataOnQuitType.entries.filter { settings.getDeleteDataOnQuit(it) }.toSet(),
        )
    }

    @Test
    fun `master on with no categories restores cookies and cache without selecting destructive categories`() {
        settings.shouldDeleteBrowsingDataOnQuit = false
        DeleteBrowsingDataOnQuitType.entries.forEach { settings.setDeleteDataOnQuit(it, false) }
        val fragment = createFragment()
        changeMaster(fragment, true)
        assertTrue(settings.shouldDeleteBrowsingDataOnQuit)
        assertEquals(setOf(DeleteBrowsingDataOnQuitType.COOKIES, DeleteBrowsingDataOnQuitType.CACHE), checked(fragment))
    }

    @Test
    fun `opening the screen twice preserves explicit disabled defaults`() {
        settings.shouldDeleteBrowsingDataOnQuit = false
        settings.setDeleteDataOnQuit(DeleteBrowsingDataOnQuitType.COOKIES, false)
        repeat(2) {
            val fragment = createFragment()
            assertFalse(master(fragment).isChecked)
            assertEquals(setOf(DeleteBrowsingDataOnQuitType.CACHE), checked(fragment))
            val restarted = Settings(testContext)
            assertFalse(restarted.shouldDeleteBrowsingDataOnQuit)
            assertFalse(restarted.getDeleteDataOnQuit(DeleteBrowsingDataOnQuitType.COOKIES))
            assertTrue(restarted.getDeleteDataOnQuit(DeleteBrowsingDataOnQuitType.CACHE))
        }
    }

    @Test
    fun `deselecting the last category turns off cleanup and the master restores only safe defaults`() {
        DeleteBrowsingDataOnQuitType.entries.forEach { settings.setDeleteDataOnQuit(it, false) }
        settings.setDeleteDataOnQuit(DeleteBrowsingDataOnQuitType.CACHE, true)
        val fragment = createFragment()
        val cache = fragment.findPreference<CheckBoxPreference>(DeleteBrowsingDataOnQuitType.CACHE.getPreferenceKey(testContext))!!
        assertTrue(cache.callChangeListener(false))
        cache.isChecked = false
        assertFalse(master(fragment).isChecked)
        assertFalse(settings.shouldDeleteBrowsingDataOnQuit)
        changeMaster(fragment, true)
        assertEquals(setOf(DeleteBrowsingDataOnQuitType.COOKIES, DeleteBrowsingDataOnQuitType.CACHE), checked(fragment))
    }

    private fun createFragment(): DeleteBrowsingDataOnQuitFragment {
        val controller = Robolectric.buildActivity(AppCompatActivity::class.java)
        controller.get().setTheme(R.style.NormalTheme)
        val activity = controller.create().get()
        val fragment = DeleteBrowsingDataOnQuitFragment()
        activity.supportFragmentManager.beginTransaction().add(fragment, "cleanup").commitNow()
        // Exercise the same binding and listeners as entering this screen without
        // unrelated Activity resume work (the application components are test doubles).
        fragment.onResume()
        return fragment
    }

    private fun master(fragment: DeleteBrowsingDataOnQuitFragment) =
        fragment.requirePreference<SwitchPreferenceCompat>(R.string.pref_key_delete_browsing_data_on_quit)

    private fun changeMaster(fragment: DeleteBrowsingDataOnQuitFragment, enabled: Boolean) {
        val preference = master(fragment)
        assertTrue(preference.callChangeListener(enabled))
        preference.isChecked = enabled
    }

    private fun checked(fragment: DeleteBrowsingDataOnQuitFragment) =
        DeleteBrowsingDataOnQuitType.entries.filter { type ->
            fragment.findPreference<CheckBoxPreference>(type.getPreferenceKey(testContext))!!.isChecked
        }.toSet()
}
