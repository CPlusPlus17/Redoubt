/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package mozilla.components.feature.fxsuggest.datasource

import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.async
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import mozilla.components.feature.fxsuggest.FxSuggestAdmission
import mozilla.components.feature.fxsuggest.FxSuggestChoices
import mozilla.components.feature.fxsuggest.client.MerinoClient
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(AndroidJUnit4::class)
class OnlineSuggestionAdmissionTest {
    private var choices = FxSuggestChoices()

    @Before
    fun setUp() {
        FxSuggestAdmission.configure { choices }
    }

    @After
    fun tearDown() {
        FxSuggestAdmission.configure { FxSuggestChoices() }
    }

    @Test
    fun `disabled default data source construction and query do not initialize native client`() = runTest {
        choices = choices.copy(online = false)
        val source = CombinedOnlineSuggestionDataSource(backgroundScope)
        assertTrue(source.fetchStocks("test stock").isEmpty())
    }

    @Test
    fun `choice closed during debounce prevents the queued transport call`() = runTest {
        var requests = 0
        val client = object : MerinoClient {
            override fun makeRequest(query: String): String? { requests += 1; return STOCKS }
        }
        val source = CombinedOnlineSuggestionDataSource(backgroundScope, client, debounceMs = 100)
        val result = async { source.fetchStocks("test stock") }
        runCurrent()
        choices = choices.copy(online = false)
        FxSuggestAdmission.choicesChanged()
        advanceTimeBy(101)
        assertTrue(result.await().isEmpty())
        assertEquals(0, requests)
    }

    @Test
    fun `explicit online consent reaches the real data-source client and parses its result`() = runTest {
        var requested: String? = null
        val source = CombinedOnlineSuggestionDataSource(backgroundScope, object : MerinoClient {
            override fun makeRequest(query: String): String { requested = query; return STOCKS }
        }, debounceMs = 0)
        assertFalse(source.fetchStocks("test stock").isEmpty())
        assertEquals("test stock", requested)
    }

    @Test
    fun `response already in flight after disable cannot publish online cards`() = runTest {
        val entered = CompletableDeferred<Unit>()
        val release = CountDownLatch(1)
        val source = CombinedOnlineSuggestionDataSource(backgroundScope, object : MerinoClient {
            override fun makeRequest(query: String): String {
                entered.complete(Unit)
                check(release.await(5, TimeUnit.SECONDS)) { "Test did not release the simulated response" }
                return STOCKS
            }
        }, debounceMs = 0)
        val result = async { source.fetchStocks("test stock") }
        try {
            entered.await()
            choices = choices.copy(online = false)
            FxSuggestAdmission.choicesChanged()
        } finally {
            release.countDown()
        }
        assertTrue(result.await().isEmpty())
    }

    @Test
    fun `private context blocks transport even with a saved online opt-in`() = runTest {
        val source = CombinedOnlineSuggestionDataSource(
            backgroundScope,
            object : MerinoClient { override fun makeRequest(query: String): String = error("Private query sent") },
            debounceMs = 0,
            isRequestAllowed = { false },
        )
        assertTrue(source.fetchStocks("test stock").isEmpty())
    }

    @Test
    fun `context becoming private during debounce rejects the queued query`() = runTest {
        var allowed = true
        val source = CombinedOnlineSuggestionDataSource(
            backgroundScope,
            object : MerinoClient { override fun makeRequest(query: String): String = error("Stale normal query sent") },
            debounceMs = 100,
            isRequestAllowed = { allowed },
        )
        val result = async { source.fetchStocks("test stock") }
        runCurrent()
        allowed = false
        advanceTimeBy(101)
        assertTrue(result.await().isEmpty())
    }

    companion object {
        private const val STOCKS = """{"suggestions":[{"provider":"polygon","score":0.9,"custom_details":{"polygon":{"values":[{"ticker":"TEST","name":"Test","last_price":"1.00 USD","todays_change_perc":"+0.1","query":"test stock","exchange":"EXAMPLE","image_url":"https://example.invalid/icon.png"}]}}}]}"""
    }
}
