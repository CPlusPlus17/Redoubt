/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.fenix.settings.logins.fragment

import android.view.LayoutInflater
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.PreferenceViewHolder
import io.mockk.every
import mozilla.components.support.test.robolectric.testContext
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.mozilla.fenix.R
import org.mozilla.fenix.ext.components
import org.mozilla.fenix.settings.RadioButtonPreference
import org.mozilla.fenix.settings.requirePreference
import org.mozilla.fenix.utils.Settings
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class SavedLoginsSettingFragmentTest {
    @Test
    fun `fresh profile selects only never save`() {
        assertRadioChoices(Settings(testContext), save = false)
    }

    @Test
    fun `stored save choice with an absent companion key remains the only selection`() {
        val settings = Settings(testContext)
        settings.shouldPromptToSaveLogins = true
        repeat(2) { assertRadioChoices(settings, save = true) }
    }

    private fun assertRadioChoices(settings: Settings, save: Boolean) {
        every { testContext.components.settings } returns settings
        val controller = Robolectric.buildActivity(AppCompatActivity::class.java)
        controller.get().setTheme(R.style.NormalTheme)
        val activity = controller.create().get()
        val fragment = SavedLoginsSettingFragment()
        activity.supportFragmentManager.beginTransaction().add(fragment, "logins").commitNow()
        fragment.onResume()
        for ((key, expected) in listOf(R.string.pref_key_save_logins to save, R.string.pref_key_never_save_logins to !save)) {
            val radio = fragment.requirePreference<RadioButtonPreference>(key)
            val view = LayoutInflater.from(activity).inflate(radio.layoutResource, FrameLayout(activity), false)
            radio.onBindViewHolder(PreferenceViewHolder.createInstanceForTests(view))
            assertEquals(expected, radio.isChecked)
        }
        assertEquals(save, Settings(testContext).shouldPromptToSaveLogins)
    }
}
