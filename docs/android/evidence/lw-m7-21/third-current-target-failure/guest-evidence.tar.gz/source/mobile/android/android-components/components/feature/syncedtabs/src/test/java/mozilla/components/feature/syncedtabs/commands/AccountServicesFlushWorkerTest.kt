/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package mozilla.components.feature.syncedtabs.commands

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.work.ListenableWorker
import androidx.work.testing.TestListenableWorkerBuilder
import kotlinx.coroutines.test.runTest
import mozilla.components.service.fxa.AccountServices
import mozilla.components.support.test.robolectric.testContext
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class AccountServicesFlushWorkerTest {
    @After
    fun tearDown() {
        AccountServices.initialize(testContext, defaultEnabled = true)
    }

    @Test
    fun `disabled persisted flush work must not resolve the account command provider`() = runTest {
        AccountServices.initialize(testContext, defaultEnabled = false)
        GlobalSyncedTabsCommandsProvider.initialize(lazy { error("Disabled worker resolved account commands") })
        val worker = TestListenableWorkerBuilder<SyncedTabsCommandsFlushWorker>(testContext).build()
        assertEquals(ListenableWorker.Result.success(), worker.doWork())
    }
}
