/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package mozilla.components.browser.engine.gecko.permission

import mozilla.components.concept.engine.permission.OriginBoundPermission
import mozilla.components.concept.engine.permission.Permission
import mozilla.components.concept.engine.permission.SitePermissions.Status
import mozilla.components.support.test.argumentCaptor
import mozilla.components.support.test.mock
import mozilla.components.test.ReflectionUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.mockito.Mockito.times
import org.mockito.Mockito.verify
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoSession.PermissionDelegate
import org.mozilla.geckoview.GeckoSession.PermissionDelegate.ContentPermission

class OriginBoundPermissionRequestTest {
    @Test
    fun `maps both protected operations and keeps their exact origin attributes`() {
        listOf(
            PermissionDelegate.PERMISSION_WEBGL to Permission.ContentWebGL(),
            PermissionDelegate.PERMISSION_CANVAS to Permission.ContentCanvas(),
        ).forEach { (type, permission) ->
            val gecko = originPermission(type = type, privateMode = true)
            val request = GeckoPermissionRequest.OriginBoundContent(gecko, mock())
            assertEquals(listOf(permission), request.permissions)
            assertEquals("https://frame.test:8443^privateBrowsingId=1", request.permission.principalOrigin)
            assertEquals("https://top.test", request.topLevelOrigin)
            assertTrue(request.isQuiet)
            assertFalse(request.permission.permanent)
        }
    }

    @Test
    fun `explicit remembered allow completes once with requested lifetime`() {
        val result = mock<GeckoResult<PermissionDelegate.PermissionDecision>>()
        val request = GeckoPermissionRequest.OriginBoundContent(originPermission(), result)
        request.decide(Status.ALLOWED, true)
        request.decide(Status.BLOCKED, false)
        val decision = argumentCaptor<PermissionDelegate.PermissionDecision>()
        verify(result, times(1)).complete(decision.capture())
        assertEquals(ContentPermission.VALUE_ALLOW, decision.value.value)
        assertTrue(decision.value.permanent)
    }

    @Test
    fun `default grant is a browser session choice and private can never be remembered`() {
        listOf(false, true).forEach { privateMode ->
            val result = mock<GeckoResult<PermissionDelegate.PermissionDecision>>()
            val request = GeckoPermissionRequest.OriginBoundContent(originPermission(privateMode = privateMode), result)
            if (privateMode) request.decide(Status.ALLOWED, true) else request.grant()
            val decision = argumentCaptor<PermissionDelegate.PermissionDecision>()
            verify(result).complete(decision.capture())
            assertEquals(ContentPermission.VALUE_ALLOW, decision.value.value)
            assertFalse(decision.value.permanent)
        }
    }

    @Test
    fun `dismissing a request uses prompt rather than creating a stored denial`() {
        val result = mock<GeckoResult<PermissionDelegate.PermissionDecision>>()
        GeckoPermissionRequest.OriginBoundContent(originPermission(), result).reject()
        val decision = argumentCaptor<PermissionDelegate.PermissionDecision>()
        verify(result).complete(decision.capture())
        assertEquals(ContentPermission.VALUE_PROMPT, decision.value.value)
        assertFalse(decision.value.permanent)
    }

    @Test
    fun `session and private engine records never become remembered records`() {
        assertFalse(originPermission(expireType = 2).toOriginBoundPermission()!!.permanent)
        assertFalse(originPermission(privateMode = true, expireType = 0).toOriginBoundPermission()!!.permanent)
        assertTrue(originPermission(expireType = 0).toOriginBoundPermission()!!.permanent)
        assertEquals(OriginBoundPermission.Kind.WEBGL, originPermission().toOriginBoundPermission()!!.kind)
    }
}

internal fun originPermission(
    type: Int = PermissionDelegate.PERMISSION_WEBGL,
    privateMode: Boolean = false,
    expireType: Int = 2,
    uri: String = "https://frame.test:8443",
    contextId: String? = null,
    value: Int = ContentPermission.VALUE_ALLOW,
): ContentPermission = mock<ContentPermission>().also {
    ReflectionUtils.setField(it, "permission", type)
    ReflectionUtils.setField(it, "privateMode", privateMode)
    ReflectionUtils.setField(it, "expireType", expireType)
    ReflectionUtils.setField(it, "uri", uri)
    ReflectionUtils.setField(it, "principalOrigin", uri + if (privateMode) "^privateBrowsingId=1" else "")
    ReflectionUtils.setField(it, "contextId", contextId)
    ReflectionUtils.setField(it, "value", value)
    ReflectionUtils.setField(it, "isQuiet", true)
    ReflectionUtils.setField(it, "topLevelOrigin", "https://top.test")
}
