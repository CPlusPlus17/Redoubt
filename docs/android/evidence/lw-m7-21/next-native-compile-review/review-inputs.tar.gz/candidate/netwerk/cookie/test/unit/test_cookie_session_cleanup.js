/* Any copyright is dedicated to the Public Domain.
 * http://creativecommons.org/publicdomain/zero/1.0/ */

const { Sqlite } = ChromeUtils.importESModule("resource://gre/modules/Sqlite.sys.mjs");
const { NetUtil } = ChromeUtils.importESModule("resource://gre/modules/NetUtil.sys.mjs");
do_get_profile();
const manager = Services.cookies;

function add(host, name, attrs = {}, session = false) {
  manager.add(host, "/", name, "fixture", false, false, session,
    Date.now() + 3600000, attrs, Ci.nsICookie.SAMESITE_LAX,
    Ci.nsICookie.SCHEME_HTTPS, false);
}

function memoryNames() {
  return manager.cookies.map(cookie => cookie.name).sort();
}

async function withLease(operation) {
  const token = manager.beginSessionCleanup();
  try {
    return await operation(token);
  } finally {
    manager.endSessionCleanup(token);
  }
}

async function database() {
  // The native ordered read completes initialization and prior cookie writes.
  await withLease(token => manager.getSessionCleanupScopes(token));
  return Sqlite.openConnection({ path: PathUtils.join(PathUtils.profileDir, "cookies.sqlite") });
}

async function clearFixture() {
  manager.removeAll();
  manager.removeCookiesWithOriginAttributes(JSON.stringify({ privateBrowsingId: 1 }));
  await withLease(token => manager.getSessionCleanupScopes(token));
}

add_task(async function exact_scopes_preserve_attributes_and_stable_ids() {
  await clearFixture();
  add("keep.example", "keep");
  add("remove.example", "normal");
  add("remove.example", "container", { userContextId: 7 });
  add("remove.example", "partition", { partitionKey: "(https,top.example)" });
  add(".remove.example", "domain");
  add("remove.example", "private", { privateBrowsingId: 1 }, true);
  add("[::1]", "ipv6");
  await withLease(async token => {
    const before = await manager.getSessionCleanupScopes(token);
    for (const scope of before) {
      Assert.deepEqual(scope.originAttributes,
        ChromeUtils.fillNonDefaultOriginAttributes(scope.originAttributes),
        "all origin attribute defaults are explicit");
    }
    const removed = before.find(scope => scope.host === "remove.example" &&
      !scope.originAttributes.userContextId && !scope.originAttributes.privateBrowsingId &&
      !scope.originAttributes.partitionKey);
    const ipv6 = before.find(scope => scope.host.includes("::1"));
    Assert.ok(removed && ipv6, "normal and IPv6 native scopes exist");
    await manager.removeSessionCleanupScopes(token, [removed.id, ipv6.id]);
    Assert.deepEqual(memoryNames(), ["container", "domain", "keep", "partition"]);
    Assert.equal(manager.getCookiesWithOriginAttributes(
      JSON.stringify({ privateBrowsingId: 1 }), "remove.example").length, 1);
    const after = await manager.getSessionCleanupScopes(token);
    Assert.ok(!after.some(scope => scope.id === removed.id || scope.id === ipv6.id),
      "stable registry does not invent current membership after removal");
    for (const scope of after) {
      Assert.deepEqual(scope, before.find(old => old.id === scope.id),
        "surviving IDs retain exact predicates");
    }
    // A removed ID still names its old scope; retry is an acknowledged no-op.
    await manager.removeSessionCleanupScopes(token, [removed.id]);
  });
});

add_task(async function invalid_ids_and_busy_or_stale_tokens_never_mutate() {
  await clearFixture();
  add("first.example", "first");
  add("second.example", "second");
  let previous;
  await withLease(async token => {
    previous = token;
    const pending = manager.getSessionCleanupScopes(token);
    Assert.throws(() => manager.endSessionCleanup(token), /NS_ERROR_NOT_AVAILABLE/);
    Assert.throws(() => manager.beginSessionCleanup(), /NS_ERROR_NOT_AVAILABLE/);
    await Assert.rejects(manager.getSessionCleanupScopes(token), /NS_ERROR_NOT_AVAILABLE/);
    const scopes = await pending;
    await Assert.rejects(manager.removeSessionCleanupScopes(token, [scopes[0].id, 0xffffffff]),
      /NS_ERROR_INVALID_ARG/);
    await Assert.rejects(manager.removeSessionCleanupScopes("unknown", []), /NS_ERROR_NOT_AVAILABLE/);
    Assert.deepEqual(memoryNames(), ["first", "second"], "whole selection prevalidated");
  });
  await withLease(async token => {
    Assert.notEqual(previous, token);
    await Assert.rejects(manager.getSessionCleanupScopes(previous), /NS_ERROR_NOT_AVAILABLE/);
  });
});

add_task(async function manager_http_and_reentrant_observer_writes_are_refused() {
  await clearFixture();
  add("remove.example", "remove");
  const uri = Services.io.newURI("https://late.example/");
  const channel = NetUtil.newChannel({ uri, loadUsingSystemPrincipal: true,
    contentPolicyType: Ci.nsIContentPolicy.TYPE_DOCUMENT });
  manager.setCookieStringFromHttp(uri, "positive=fixture; Secure; Path=/", channel);
  Assert.ok(memoryNames().includes("positive"), "same HTTP channel admits a real positive control before lease");
  manager.remove("late.example", "positive", "/", {});
  let observed = 0;
  let lease;
  const observer = notification => {
    notification.QueryInterface(Ci.nsICookieNotification);
    if (notification.action !== Ci.nsICookieNotification.COOKIE_DELETED) {
      return;
    }
    ++observed;
    Assert.throws(() => manager.endSessionCleanup(lease), /NS_ERROR_NOT_AVAILABLE/);
    Assert.throws(() => add("late.example", "observer"), /NS_ERROR_NOT_AVAILABLE/);
    manager.setCookieStringFromHttp(uri, "late=fixture; Secure; Path=/", channel);
  };
  await withLease(async token => {
    lease = token;
    const scopes = await manager.getSessionCleanupScopes(token);
    Assert.throws(() => add("late.example", "manager"), /NS_ERROR_NOT_AVAILABLE/);
    manager.setCookieStringFromHttp(uri, "late=fixture; Secure; Path=/", channel);
    Services.obs.addObserver(observer, "cookie-changed");
    try {
      await manager.removeSessionCleanupScopes(token, scopes.map(scope => scope.id));
    } finally {
      Services.obs.removeObserver(observer, "cookie-changed");
    }
    Assert.equal(observed, 1);
    Assert.deepEqual(memoryNames(), [], "no late HTTP/manager/observer repopulation");
  });
  add("late.example", "after-release");
  Assert.deepEqual(memoryNames(), ["after-release"], "ordinary admission resumes only on release");
});

add_task(async function ambient_transactions_cannot_claim_cleanup_completion() {
  await clearFixture();
  add("transaction.example", "transaction");
  await withLease(token => manager.getSessionCleanupScopes(token));
  let called = 0;
  manager.runInTransaction({
    QueryInterface: ChromeUtils.generateQI(["nsICookieTransactionCallback"]),
    callback() {
      ++called;
      Assert.throws(() => manager.beginSessionCleanup(), /NS_ERROR_NOT_AVAILABLE/,
        "cleanup cannot begin inside a parent-owned transaction");
    },
  });
  Assert.equal(called, 1);
  await withLease(async token => {
    Assert.throws(() => manager.runInTransaction({
      QueryInterface: ChromeUtils.generateQI(["nsICookieTransactionCallback"]),
      callback() { ++called; },
    }), /NS_ERROR_NOT_AVAILABLE/);
    Assert.equal(called, 1, "blocked transaction did not run its callback");
    const scopes = await manager.getSessionCleanupScopes(token);
    await manager.removeSessionCleanupScopes(token, scopes.map(scope => scope.id));
  });
});

add_task(async function failed_delete_batch_rolls_back_and_retry_keeps_retained_data() {
  await clearFixture();
  add("first.example", "first");
  add("second.example", "second");
  add("keep.example", "keep");
  const db = await database();
  try {
    // A real second-row SQL failure, not a callback or success-result mock.
    await db.execute(`CREATE TRIGGER cleanup_test_failure BEFORE DELETE ON moz_cookies
      WHEN OLD.host = 'second.example' BEGIN SELECT RAISE(ABORT, 'cleanup fixture failure'); END`);
    await withLease(async token => {
      const scopes = await manager.getSessionCleanupScopes(token);
      const ids = ["first.example", "second.example"].map(host =>
        scopes.find(scope => scope.host === host).id);
      await Assert.rejects(manager.removeSessionCleanupScopes(token, ids), /NS_ERROR_FAILURE/);
      Assert.deepEqual(memoryNames(), ["first", "keep", "second"], "failure precedes memory removal");
      const rows = await db.execute("SELECT name FROM moz_cookies ORDER BY name");
      Assert.deepEqual(rows.map(row => row.getResultByName("name")), ["first", "keep", "second"],
        "batch failure did not commit the first selected scope");
      Assert.throws(() => add("late.example", "late"), /NS_ERROR_NOT_AVAILABLE/);
      await db.execute("DROP TRIGGER cleanup_test_failure");
      await manager.removeSessionCleanupScopes(token, ids);
      Assert.deepEqual(memoryNames(), ["keep"]);
      Assert.deepEqual((await db.execute("SELECT name FROM moz_cookies")).map(
        row => row.getResultByName("name")), ["keep"]);
    });
  } finally {
    await db.execute("DROP TRIGGER IF EXISTS cleanup_test_failure");
    await db.close();
  }
});

add_task(async function disk_only_scope_is_enumerated_and_removed() {
  await clearFixture();
  add("memory.example", "orphan");
  const db = await database();
  try {
    // Model a legacy memory/disk mismatch using a real row. No native cache is
    // overwritten, and all schema fields remain the current valid native data.
    await db.execute("UPDATE moz_cookies SET host = 'orphan.example' WHERE name = 'orphan'");
    await withLease(async token => {
      const scopes = await manager.getSessionCleanupScopes(token);
      Assert.ok(scopes.some(scope => scope.host === "memory.example"));
      const orphan = scopes.find(scope => scope.host === "orphan.example");
      Assert.ok(orphan, "database-only row included independently of memory");
      await manager.removeSessionCleanupScopes(token, [orphan.id]);
      Assert.deepEqual(memoryNames(), ["orphan"], "unselected memory scope retained");
      Assert.equal((await db.execute("SELECT name FROM moz_cookies")).length, 0);
      Assert.ok(!(await manager.getSessionCleanupScopes(token)).some(
        scope => scope.host === "orphan.example"));
    });
  } finally {
    await db.close();
  }
});

add_task(async function invalid_database_attributes_reject_instead_of_default_jar_selection() {
  await clearFixture();
  add("attributes.example", "attributes");
  const db = await database();
  try {
    await db.execute("UPDATE moz_cookies SET originAttributes = '^unexpected=1'");
    await withLease(async token => {
      await Assert.rejects(manager.getSessionCleanupScopes(token), /NS_ERROR_FILE_CORRUPTED/);
      Assert.deepEqual(memoryNames(), ["attributes"]);
      await db.execute("UPDATE moz_cookies SET originAttributes = ''");
      Assert.equal((await manager.getSessionCleanupScopes(token)).length, 1);
    });
  } finally {
    await db.close();
  }
});

add_task(async function closing_storage_invalidates_an_already_queued_completion() {
  await clearFixture();
  add("close.example", "close");
  const token = manager.beginSessionCleanup();
  const pending = manager.getSessionCleanupScopes(token);
  manager.testCloseCookieDB();
  await Assert.rejects(pending, /NS_ERROR_NOT_AVAILABLE|NS_ERROR_ABORT|NS_ERROR_FAILURE/);
  manager.testOpenCookieDB();
  await Assert.rejects(manager.getSessionCleanupScopes(token), /NS_ERROR_NOT_AVAILABLE/);
  // End releases only the lease; it deliberately does not mean the read passed.
  manager.endSessionCleanup(token);
  await withLease(async next => {
    Assert.notEqual(next, token);
    Assert.ok(Array.isArray(await manager.getSessionCleanupScopes(next)));
  });
});

add_task(async function private_teardown_invalidates_inflight_selection() {
  await clearFixture();
  add("private.example", "private", { privateBrowsingId: 1 }, true);
  await withLease(async token => {
    const pending = manager.getSessionCleanupScopes(token);
    // This is the actual cookie-service observer, not a fake global shutdown.
    manager.QueryInterface(Ci.nsIObserver).observe(null, "last-pb-context-exited", null);
    await Assert.rejects(pending, /NS_ERROR_NOT_AVAILABLE/);
    await Assert.rejects(manager.removeSessionCleanupScopes(token, []), /NS_ERROR_NOT_AVAILABLE/);
  });
});
