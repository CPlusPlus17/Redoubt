/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

"use strict";

/* globals Services */

const { E10SUtils } = ChromeUtils.importESModule(
  "resource://gre/modules/E10SUtils.sys.mjs"
);
const { Preferences } = ChromeUtils.importESModule(
  "resource://gre/modules/Preferences.sys.mjs"
);

// This helper is packaged only in the privileged instrumentation extension.
// It exercises native I/O on the normal XRE_main-initialized test profile; it
// does not initialize/mimic mCurrentFile or accept an arbitrary filesystem path.
let prefSaveIOTestRunning = false;

async function runPrefSaveFileAsyncIOTest(scenario, allowProfileShutdown) {
  const PREF = "test.librewolf.savePrefFileAsync.value";
  function requireCondition(condition, message) {
    if (!condition) {
      throw new Error(`Pref save I/O fixture: ${message}`);
    }
  }
  requireCondition(!prefSaveIOTestRunning, "concurrent fixture refused");
  requireCondition(
    ["snapshots", "clean", "failure", "shutdown"].includes(scenario),
    "unknown scenario"
  );
  requireCondition(
    scenario !== "shutdown" || allowProfileShutdown === true,
    "shutdown requires an explicitly isolated instrumentation invocation"
  );
  requireCondition(!Services.prefs.prefHasUserValue(PREF), "test pref already set");
  requireCondition(
    Services.prefs.getBoolPref("preferences.allow.omt-write"),
    "queued native writer must be enabled by the test runtime at startup"
  );
  const profile = Services.dirsvc.get("ProfD", Ci.nsIFile);
  const current = Services.dirsvc.get("PrefF", Ci.nsIFile);
  requireCondition(
    current.parent.equals(profile) && current.leafName === "prefs.js",
    "unexpected current profile path"
  );
  // Unlike directory registration, this successful native call establishes
  // that InitializeUserPrefs actually selected a current preferences file.
  prefSaveIOTestRunning = true;
  let initialized = false;
  let fixture;
  let profileClosed = false;
  const receipt = { scenario, profile: profile.path, currentFile: current.path };
  const observer = Services.prefs.QueryInterface(Ci.nsIObserver);
  function suspend() {
    // notifyObservers() discards individual nsresult failures.
    observer.observe(null, "suspend_process_notification", null);
  }
  function errorReceipt(error) {
    return { name: error.name, result: error.result, message: String(error) };
  }
  async function outcome(operation) {
    try {
      await operation();
      return { resolved: true };
    } catch (error) {
      return { resolved: false, error: errorReceipt(error) };
    }
  }
  function syncOutcome(operation) {
    try {
      operation();
      return { resolved: true };
    } catch (error) {
      return { resolved: false, error: errorReceipt(error) };
    }
  }
  function child(name) {
    const file = fixture.clone();
    file.append(name);
    return file;
  }
  async function valueOnDisk(file) {
    let value = null;
    const errors = [];
    const record = (_kind, name, saved) => {
      if (name === PREF) {
        value = saved;
      }
    };
    Services.prefs.parsePrefsFromBuffer(await IOUtils.read(file.path), {
      onStringPref: record,
      onIntPref: record,
      onBoolPref: record,
      onError(message) {
        errors.push(message);
      },
    });
    requireCondition(!errors.length, `invalid saved prefs: ${errors.join("; ")}`);
    return value;
  }
  async function withBlockedCurrentFile(operation) {
    await Services.prefs.savePrefFileAsync();
    suspend();
    const saved = child("original-prefs.js");
    requireCondition(!saved.exists(), "recovery file already exists");
    current.clone().moveTo(fixture, saved.leafName);
    try {
      // A directory is a real rename/write failure even when tests run as root.
      current.create(Ci.nsIFile.DIRECTORY_TYPE, 0o700);
      await operation();
      requireCondition(current.isDirectory(), "failure target was replaced");
    } finally {
      // Drain before synchronous restore; an autosave cannot run on the main
      // thread between removing the directory and moving the original back.
      syncOutcome(suspend);
      if (current.exists()) {
        requireCondition(
          current.isDirectory(),
          `unexpected recovery target; original retained at ${saved.path}`
        );
        current.remove(false);
      }
      saved.moveTo(profile, current.leafName);
    }
  }
  try {
    await Services.prefs.savePrefFileAsync();
    requireCondition(current.isFile(), "current profile save created no file");
    initialized = true;
    fixture = profile.clone();
    fixture.append("lw-m7-35-io");
    fixture.createUnique(Ci.nsIFile.DIRECTORY_TYPE, 0o700);
    if (scenario === "snapshots") {
      const firstBackup = child("a.js");
      const secondBackup = child("b.js");
      const failedBackup = child("directory");
      failedBackup.create(Ci.nsIFile.DIRECTORY_TYPE, 0o700);
      // Capture requests without yielding, then inspect each distinct file.
      Services.prefs.setStringPref(PREF, "first-current");
      const first = outcome(() => Services.prefs.savePrefFileAsync());
      Services.prefs.setStringPref(PREF, "backup-a");
      const a = outcome(() => Services.prefs.backupPrefFile(firstBackup));
      Services.prefs.setStringPref(PREF, "failed-backup");
      const failed = outcome(() => Services.prefs.backupPrefFile(failedBackup));
      Services.prefs.setStringPref(PREF, "backup-b");
      const b = outcome(() => Services.prefs.backupPrefFile(secondBackup));
      Services.prefs.setStringPref(PREF, "final-current");
      const final = outcome(() => Services.prefs.savePrefFileAsync());
      [
        receipt.first,
        receipt.backupA,
        receipt.failed,
        receipt.backupB,
        receipt.final,
      ] = await Promise.all([first, a, failed, b, final]);
      receipt.backupAValue = await valueOnDisk(firstBackup);
      receipt.backupBValue = await valueOnDisk(secondBackup);
      receipt.currentValue = await valueOnDisk(current);
      receipt.failedTargetIsDirectory = failedBackup.isDirectory();
    } else if (scenario === "clean") {
      Services.prefs.setStringPref(PREF, "clean-state");
      suspend();
      receipt.dirtyBeforeRemoval = Services.prefs.dirty;
      requireCondition(!receipt.dirtyBeforeRemoval, "blocking save was not clean");
      current.remove(false);
      receipt.dirtyAfterRemoval = Services.prefs.dirty;
      receipt.fileAbsentBeforeBarrier = !current.exists();
      await Services.prefs.savePrefFileAsync();
      receipt.recreatedValue = await valueOnDisk(current);
      Services.prefs.clearUserPref(PREF);
      await Services.prefs.savePrefFileAsync();
      receipt.resetValue = await valueOnDisk(current);
    } else {
      await withBlockedCurrentFile(async () => {
        Services.prefs.setStringPref(PREF, "after-disk-error");
        receipt.failedSave = await outcome(() =>
          Services.prefs.savePrefFileAsync()
        );
        receipt.failedSuspend = syncOutcome(suspend);
        receipt.memoryValueAfterFailure = Services.prefs.getStringPref(PREF);
        if (scenario === "shutdown") {
          receipt.failedShutdown = syncOutcome(() =>
            observer.observe(null, "profile-before-change-telemetry", null)
          );
          // If broken code acknowledged this failure, stop further mutation.
          // The outer finally still restores the original physical file.
          profileClosed = receipt.failedShutdown.resolved;
        }
        receipt.failureTargetIsDirectory = current.isDirectory();
      });
      requireCondition(!profileClosed, "failed I/O was acknowledged as shutdown");
      receipt.retry = await outcome(() => Services.prefs.savePrefFileAsync());
      receipt.retryValue = await valueOnDisk(current);
      suspend();
      receipt.dirtyAfterRetry = Services.prefs.dirty;
      if (scenario === "shutdown") {
        Services.prefs.setStringPref(PREF, "shutdown-final");
        observer.observe(null, "profile-before-change-telemetry", null);
        profileClosed = true;
        receipt.finalValue = await valueOnDisk(current);
        receipt.afterShutdown = await outcome(() =>
          Services.prefs.savePrefFileAsync()
        );
        receipt.expectedShutdownError = Cr.NS_ERROR_ILLEGAL_DURING_SHUTDOWN;
      }
    }
    return receipt;
  } finally {
    // A successful final profile shutdown is intentionally irreversible. Its
    // dedicated instrumentation process owns disposal of that test profile.
    if (initialized && !profileClosed) {
      Services.prefs.clearUserPref(PREF);
      await Services.prefs.savePrefFileAsync();
      suspend();
    }
    // Never discard the only recovery copy if restoration failed.
    if (fixture?.exists() && !child("original-prefs.js").exists()) {
      fixture.remove(true);
    }
    prefSaveIOTestRunning = false;
  }
}

this.test = class extends ExtensionAPI {
  onStartup() {
    ChromeUtils.registerWindowActor("TestSupport", {
      child: {
        esModuleURI:
          "resource://android/assets/web_extensions/test-support/TestSupportChild.sys.mjs",
      },
      allFrames: true,
    });
    ChromeUtils.registerProcessActor("TestSupportProcess", {
      child: {
        esModuleURI:
          "resource://android/assets/web_extensions/test-support/TestSupportProcessChild.sys.mjs",
      },
    });
  }

  onShutdown(isAppShutdown) {
    if (isAppShutdown) {
      return;
    }
    ChromeUtils.unregisterWindowActor("TestSupport");
    ChromeUtils.unregisterProcessActor("TestSupportProcess");
  }

  getAPI(context) {
    /**
     * Helper function for getting window or process actors.
     *
     * @param tabId - id of the tab; required
     * @param actorName - a string; the name of the actor
     *   Default: "TestSupport" which is our test framework actor
     *   (you can still pass the second parameter when getting the TestSupport actor, for readability)
     *
     * @returns actor
     */
    function getActorForTab(tabId, actorName = "TestSupport") {
      const tab = context.extension.tabManager.get(tabId);
      const { browsingContext } = tab.browser;
      return browsingContext.currentWindowGlobal.getActor(actorName);
    }

    const frameDestructionProbes = new Map();
    let nextFrameDestructionProbe = 1;

    async function prepareFrameDestructionProbe(tabId) {
      const tab = context.extension.tabManager.get(tabId);
      const loader = tab.browser.frameLoader;
      if (!loader || !loader.isRemoteFrame || loader.isDead) {
        throw new Error("Frame destruction fixture requires a live remote loader");
      }
      const first = loader.whenDestroyed();
      const second = loader.whenDestroyed();
      const probe = { loader, first, second, completed: 0 };
      first.then(() => ++probe.completed);
      second.then(() => ++probe.completed);
      await Promise.resolve();
      if (probe.completed || first !== second) {
        throw new Error("Live loader resolved early or did not share completion");
      }
      const id = nextFrameDestructionProbe++;
      frameDestructionProbes.set(id, probe);
      return { id, completedBeforeClose: probe.completed, remote: loader.isRemoteFrame };
    }

    async function finishFrameDestructionProbe(id) {
      const probe = frameDestructionProbes.get(id);
      if (!probe) {
        throw new Error("Unknown frame destruction fixture");
      }
      try {
        await Promise.all([probe.first, probe.second]);
        const repeated = probe.loader.whenDestroyed();
        await repeated;
        return {
          completed: probe.completed,
          repeatedSharesPromise: repeated === probe.first,
          messageManagerDisconnected: probe.loader.messageManager === null,
        };
      } finally {
        frameDestructionProbes.delete(id);
      }
    }

    async function runInProcessFrameDestructionProbe(tabId, firstReadAfterRemoval) {
      const doc = context.extension.tabManager.get(tabId).browser.ownerDocument;
      const cookieHost = "task37-frame-unload.example";
      const cookieName = "task37-frame-unload";
      if (Services.cookies.getCookiesFromHost(cookieHost, {}).length) {
        throw new Error("Frame unload cookie fixture already exists");
      }
      const frame = doc.createElementNS("http://www.w3.org/1999/xhtml", "iframe");
      frame.style.display = "none";
      frame.src = "about:blank";
      const loaded = new Promise(resolve => frame.addEventListener("load", resolve, { once: true }));
      doc.documentElement.appendChild(frame);
      let loader;
      try {
        await loaded;
        loader = frame.frameLoader;
        if (!loader || loader.isRemoteFrame) {
          throw new Error("Expected an actual in-process native frame loader");
        }
        let unloaded = false;
        frame.contentWindow.addEventListener("unload", () => {
          Services.cookies.add(cookieHost, "/", cookieName, "written-from-unload",
            false, false, true, Date.now() + 60000, {},
            Ci.nsICookie.SAMESITE_LAX, Ci.nsICookie.SCHEME_HTTPS, false);
          unloaded = true;
        }, { once: true });
        let completedBeforeRemoval = false;
        const before = firstReadAfterRemoval ? null : loader.whenDestroyed();
        before?.then(() => { completedBeforeRemoval = true; });
        await Promise.resolve();
        if (completedBeforeRemoval) {
          throw new Error("Live in-process loader resolved before removal");
        }
        const observedBeforeRemoval = completedBeforeRemoval;
        frame.remove();
        const after = loader.whenDestroyed();
        await after;
        if (before) {
          await before;
        }
        return {
          unloaded,
          unloadCookieValue: Services.cookies.getCookiesFromHost(cookieHost, {})
            .find(cookie => cookie.name === cookieName)?.value ?? null,
          remote: loader.isRemoteFrame,
          firstReadAfterRemoval,
          completedBeforeRemoval: observedBeforeRemoval,
          repeatedSharesPromise: loader.whenDestroyed() === after,
          messageManagerDisconnected: loader.messageManager === null,
        };
      } finally {
        frame.remove();
        if (loader) {
          await loader.whenDestroyed();
        }
        Services.cookies.remove(cookieHost, cookieName, "/", {});
      }
    }

    return {
      test: {
        prepareFrameDestructionProbe,
        finishFrameDestructionProbe,
        runInProcessFrameDestructionProbe,
        async runPrefSaveFileAsyncIOTest(scenario, allowProfileShutdown) {
          return runPrefSaveFileAsyncIOTest(scenario, allowProfileShutdown);
        },

        /* Set prefs and returns set of saved prefs */
        async setPrefs(oldPrefs, newPrefs) {
          // Save old prefs
          Object.assign(
            oldPrefs,
            ...Object.keys(newPrefs)
              .filter(key => !(key in oldPrefs))
              .map(key => ({ [key]: Preferences.get(key, null) }))
          );

          // Set new prefs
          Preferences.set(newPrefs);
          return oldPrefs;
        },

        /* Restore prefs to old value. */
        async restorePrefs(oldPrefs) {
          for (const [name, value] of Object.entries(oldPrefs)) {
            if (value === null) {
              Preferences.reset(name);
            } else {
              Preferences.set(name, value);
            }
          }
        },

        /* Get pref values. */
        async getPrefs(prefs) {
          return Preferences.get(prefs);
        },

        /* Clears a given user preference. */
        async clearUserPref(pref) {
          Services.prefs.clearUserPref(pref);
        },
        /* Gets link color for a given selector. */
        async getLinkColor(tabId, selector) {
          return getActorForTab(tabId, "TestSupport").sendQuery(
            "GetLinkColor",
            { selector }
          );
        },

        async getRequestedLocales() {
          return Services.locale.requestedLocales;
        },

        async getPidForTab(tabId) {
          const tab = context.extension.tabManager.get(tabId);
          const pids = E10SUtils.getBrowserPids(tab.browser);
          return pids[0];
        },

        async waitForContentTransformsReceived(tabId) {
          return getActorForTab(tabId).sendQuery(
            "WaitForContentTransformsReceived"
          );
        },

        async getAllBrowserPids() {
          const pids = [];
          const processes = ChromeUtils.getAllDOMProcesses();
          for (const process of processes) {
            if (process.remoteType && process.remoteType.startsWith("web")) {
              pids.push(process.osPid);
            }
          }
          return pids;
        },

        async killContentProcess(pid) {
          const procs = ChromeUtils.getAllDOMProcesses();
          for (const proc of procs) {
            if (pid === proc.osPid) {
              proc
                .getActor("TestSupportProcess")
                .sendAsyncMessage("KillContentProcess");
            }
          }
        },

        async addHistogram(id, value) {
          return Services.telemetry.getHistogramById(id).add(value);
        },

        removeAllCertOverrides() {
          const overrideService = Cc[
            "@mozilla.org/security/certoverride;1"
          ].getService(Ci.nsICertOverrideService);
          overrideService.clearAllOverrides();
        },

        async setResolutionAndScaleTo(tabId, resolution) {
          return getActorForTab(tabId, "TestSupport").sendQuery(
            "SetResolutionAndScaleTo",
            {
              resolution,
            }
          );
        },

        async getActive(tabId) {
          const tab = context.extension.tabManager.get(tabId);
          return tab.browser.docShellIsActive;
        },

        async getProfilePath() {
          return PathUtils.profileDir;
        },

        async flushApzRepaints(tabId) {
          // TODO: Note that `waitUntilApzStable` in apz_test_utils.js does
          // flush APZ repaints in the parent process (i.e. calling
          // nsIDOMWindowUtils.flushApzRepaints for the parent process) before
          // flushApzRepaints is called for the target content document, if we
          // still meet intermittent failures, we might want to do it here as
          // well.
          await getActorForTab(tabId, "TestSupport").sendQuery(
            "FlushApzRepaints"
          );
        },

        async zoomToFocusedInput(tabId) {
          await getActorForTab(tabId, "TestSupport").sendQuery(
            "ZoomToFocusedInput"
          );
        },

        async promiseAllPaintsDone(tabId) {
          await getActorForTab(tabId, "TestSupport").sendQuery(
            "PromiseAllPaintsDone"
          );
        },

        async usingGpuProcess() {
          const gfxInfo = Cc["@mozilla.org/gfx/info;1"].getService(
            Ci.nsIGfxInfo
          );
          return gfxInfo.usingGPUProcess;
        },

        async killGpuProcess() {
          const gfxInfo = Cc["@mozilla.org/gfx/info;1"].getService(
            Ci.nsIGfxInfo
          );
          return gfxInfo.killGPUProcessForTests();
        },

        async crashGpuProcess() {
          const gfxInfo = Cc["@mozilla.org/gfx/info;1"].getService(
            Ci.nsIGfxInfo
          );
          return gfxInfo.crashGPUProcessForTests();
        },

        async clearHSTSState() {
          const sss = Cc["@mozilla.org/ssservice;1"].getService(
            Ci.nsISiteSecurityService
          );
          return sss.clearAll();
        },

        async isFissionRunning() {
          return Services.appinfo.fissionAutostart;
        },

        async triggerCookieBannerDetected(tabId) {
          const actor = getActorForTab(tabId, "CookieBanner");
          return actor.receiveMessage({
            name: "CookieBanner::DetectedBanner",
          });
        },

        async triggerCookieBannerHandled(tabId) {
          const actor = getActorForTab(tabId, "CookieBanner");
          return actor.receiveMessage({
            name: "CookieBanner::HandledBanner",
          });
        },

        async triggerTranslationsOffer(tabId) {
          const browser = context.extension.tabManager.get(tabId).browser;
          const { CustomEvent } = browser.documentGlobal;
          return browser.dispatchEvent(
            new CustomEvent("TranslationsParent:OfferTranslation", {
              bubbles: true,
            })
          );
        },

        async triggerLanguageStateChange(tabId, languageState) {
          const browser = context.extension.tabManager.get(tabId).browser;
          const { CustomEvent } = browser.documentGlobal;
          return browser.dispatchEvent(
            new CustomEvent("TranslationsParent:LanguageState", {
              bubbles: true,
              detail: languageState,
            })
          );
        },

        async setHandlingUserInput(tabId, handlingUserInput) {
          return getActorForTab(tabId, "TestSupport").sendQuery(
            "SetHandlingUserInput",
            { handlingUserInput }
          );
        },

        async getWebExtensionsSchemaPermissionNames(typeNames) {
          const { Schemas } = ChromeUtils.importESModule(
            "resource://gre/modules/Schemas.sys.mjs"
          );
          return Schemas.getPermissionNames(typeNames);
        },

        async teardownAlertsService() {
          const alertsService = Cc["@mozilla.org/alerts-service;1"].getService(
            Ci.nsIAlertsService
          );
          alertsService.teardown();
        },

        async notifyUserGestureActivation(tabId) {
          return getActorForTab(tabId, "TestSupport").sendQuery(
            "NotifyUserGestureActivation"
          );
        },

        /* Seeds the tracking protection database with the given content blocking log. */
        async saveTrackingDBEvents(logJson) {
          const trackingDBService = Cc[
            "@mozilla.org/tracking-db-service;1"
          ].getService(Ci.nsITrackingDBService);
          await trackingDBService.saveEvents(logJson);
        },

        /* Removes all entries from the tracking protection database. */
        async clearTrackingDB() {
          const trackingDBService = Cc[
            "@mozilla.org/tracking-db-service;1"
          ].getService(Ci.nsITrackingDBService);
          await trackingDBService.clearAll();
        },

        async addVirtualAuthenticator() {
          const webauthnService = Cc[
            "@mozilla.org/webauthn/service;1"
          ].getService(Ci.nsIWebAuthnService);
          return webauthnService.addVirtualAuthenticator(
            "ctap2_1",
            "internal",
            true,
            true,
            true,
            true
          );
        },

        async removeVirtualAuthenticator(authenticatorId) {
          const webauthnService = Cc[
            "@mozilla.org/webauthn/service;1"
          ].getService(Ci.nsIWebAuthnService);
          webauthnService.removeVirtualAuthenticator(authenticatorId);
        },
      },
    };
  }
};
