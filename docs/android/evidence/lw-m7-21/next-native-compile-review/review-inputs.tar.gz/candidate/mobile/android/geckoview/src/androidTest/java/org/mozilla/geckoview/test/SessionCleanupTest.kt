/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

package org.mozilla.geckoview.test

import android.util.Log
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.MediumTest
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeFalse
import org.junit.Test
import org.junit.runner.RunWith
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.test.rule.GeckoSessionTestRule.AssertCalled
import org.mozilla.geckoview.test.rule.GeckoSessionTestRule.IgnoreCrash

// Tests the native frame boundary only. These results cannot establish worker,
// network/cache or session-journal cleanup completion for a release APK.
@RunWith(AndroidJUnit4::class)
@MediumTest
class SessionCleanupTest : BaseSessionTest() {
    private fun json(expression: String): JSONObject {
        val value = sessionRule.evaluateExtensionJS("return JSON.stringify($expression);") as String
        Log.i("SessionCleanupTest", value)
        return JSONObject(value)
    }

    private fun tabId(marker: String): Int =
        (sessionRule.evaluateExtensionJS(
            "return (await browser.tabs.query({})).find(tab => tab.url.includes('$marker')).id;",
        ) as Number).toInt()

    private fun openTarget(marker: String): GeckoSession = sessionRule.createOpenSession().also {
        it.loadUri(createTestUrl(HELLO_HTML_PATH) + "?" + marker)
        it.waitForPageStop()
    }

    private fun prepare(tab: Int): Int {
        val result = json("await browser.test.prepareFrameDestructionProbe($tab)")
        assertEquals(0, result.getInt("completedBeforeClose"))
        assertTrue(result.getBoolean("remote"))
        return result.getInt("id")
    }

    private fun finish(id: Int) {
        val result = json("await browser.test.finishFrameDestructionProbe($id)")
        assertEquals(2, result.getInt("completed"))
        assertTrue(result.getBoolean("repeatedSharesPromise"))
        assertTrue(result.getBoolean("messageManagerDisconnected"))
    }

    @Test
    fun remoteCloseWaitsForNativeDestructionAndSharesRepeatedCompletion() {
        val target = openTarget("task37-remote")
        val id = prepare(tabId("task37-remote"))
        target.close()
        finish(id)
    }

    @Test
    fun closingOneFrameDoesNotReportReplacementFrameDestroyed() {
        val original = openTarget("task37-original")
        val first = prepare(tabId("task37-original"))
        val replacement = openTarget("task37-replacement")
        original.close()
        finish(first)
        // The replacement remains live; prepare itself fails if its native
        // completion is already resolved. Each frame needs its own boundary.
        val second = prepare(tabId("task37-replacement"))
        replacement.close()
        finish(second)
    }

    @Test
    @IgnoreCrash
    fun crashedChildCompletesItsOwnFrameBoundary() {
        // Match the existing crash test's supported process modes. A skip is
        // pending coverage, never evidence that the crash boundary passed.
        assumeFalse(sessionRule.env.isIsolatedProcess)
        assumeFalse(sessionRule.env.isAppZygoteProcess)
        val target = openTarget("task37-crash")
        val id = prepare(tabId("task37-crash"))
        target.loadUri(CONTENT_CRASH_URL)
        target.waitUntilCalled(object : GeckoSession.ContentDelegate {
            @AssertCalled(count = 1)
            override fun onCrash(session: GeckoSession) {
                assertFalse(session.isOpen)
            }
        })
        finish(id)
    }

    private fun inProcess(firstReadAfterRemoval: Boolean) {
        mainSession.loadUri(createTestUrl(HELLO_HTML_PATH) + "?task37-parent")
        mainSession.waitForPageStop()
        val tab = tabId("task37-parent")
        val result = json(
            "await browser.test.runInProcessFrameDestructionProbe($tab, $firstReadAfterRemoval)",
        )
        assertFalse(result.getBoolean("remote"))
        assertFalse(result.getBoolean("completedBeforeRemoval"))
        assertTrue(result.getBoolean("unloaded"))
        assertEquals("written-from-unload", result.getString("unloadCookieValue"))
        assertTrue(result.getBoolean("repeatedSharesPromise"))
        assertTrue(result.getBoolean("messageManagerDisconnected"))
        assertEquals(firstReadAfterRemoval, result.getBoolean("firstReadAfterRemoval"))
    }

    @Test
    fun inProcessUnloadPrecedesCompletion() = inProcess(false)

    @Test
    fun firstPromiseCanBeCreatedAfterOwnerDetachment() = inProcess(true)
}
