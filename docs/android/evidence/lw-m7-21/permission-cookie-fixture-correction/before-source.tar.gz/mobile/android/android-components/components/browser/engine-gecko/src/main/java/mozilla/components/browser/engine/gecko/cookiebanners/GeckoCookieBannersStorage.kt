/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package mozilla.components.browser.engine.gecko.cookiebanners

import androidx.annotation.VisibleForTesting
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import mozilla.components.concept.engine.EngineSession.CookieBannerHandlingMode
import mozilla.components.concept.engine.EngineSession.CookieBannerHandlingMode.DISABLED
import mozilla.components.concept.engine.cookiehandling.CookieBannersStorage
import mozilla.components.support.base.log.logger.Logger
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.StorageController

/**
 * A storage to store [CookieBannerHandlingMode] using GeckoView APIs.
 */
class GeckoCookieBannersStorage(
    runtime: GeckoRuntime,
    private val reportSiteDomainsRepository: ReportSiteDomainsRepository,
) : CookieBannersStorage {

    private val geckoStorage: StorageController = runtime.storageController

    override suspend fun forCurrentPrivateSession(): CookieBannersStorage {
        val token = withContext(Dispatchers.Main) {
            requireNotNull(geckoStorage.getCookieBannerPrivateSessionToken().awaitCookieBannerResult())
        }
        // Keep the captured token immutable; a later session must never refresh it.
        return object : CookieBannersStorage by this {
            override suspend fun addException(uri: String, privateBrowsing: Boolean) {
                require(privateBrowsing)
                withContext(Dispatchers.Main) {
                    geckoStorage.setCookieBannerModeForPrivateSession(uri, DISABLED.mode, token).awaitCookieBannerResult()
                }
            }

            override suspend fun removeException(uri: String, privateBrowsing: Boolean) {
                require(privateBrowsing)
                withContext(Dispatchers.Main) {
                    geckoStorage.removeCookieBannerModeForPrivateSession(uri, token).awaitCookieBannerResult()
                }
            }

            override suspend fun findExceptionFor(uri: String, privateBrowsing: Boolean): CookieBannerHandlingMode? {
                require(privateBrowsing)
                return withContext(Dispatchers.Main) {
                    requireNotNull(geckoStorage.getCookieBannerModeForPrivateSession(uri, token).awaitCookieBannerResult())
                        .toCookieBannerHandlingMode()
                }
            }

            override suspend fun hasException(uri: String, privateBrowsing: Boolean): Boolean? =
                findExceptionFor(uri, privateBrowsing) == DISABLED

            override suspend fun addPersistentExceptionInPrivateMode(uri: String) {
                error("A scoped temporary private choice cannot become persistent")
            }

            override suspend fun forCurrentPrivateSession(): CookieBannersStorage = this
        }
    }

    override suspend fun addException(
        uri: String,
        privateBrowsing: Boolean,
    ) {
        setGeckoException(uri, DISABLED, privateBrowsing)
    }

    override suspend fun isSiteDomainReported(siteDomain: String): Boolean {
        return reportSiteDomainsRepository.isSiteDomainReported(siteDomain)
    }

    override suspend fun saveSiteDomain(siteDomain: String) {
        reportSiteDomainsRepository.saveSiteDomain(siteDomain)
    }

    override suspend fun addPersistentExceptionInPrivateMode(uri: String) {
        setPersistentPrivateGeckoException(uri, DISABLED)
    }

    override suspend fun findExceptionFor(
        uri: String,
        privateBrowsing: Boolean,
    ): CookieBannerHandlingMode? {
        return queryExceptionInGecko(uri, privateBrowsing)
    }

    override suspend fun hasException(uri: String, privateBrowsing: Boolean): Boolean? {
        val result = findExceptionFor(uri, privateBrowsing)
        return if (result != null) {
            result == DISABLED
        } else {
            null
        }
    }

    override suspend fun removeException(uri: String, privateBrowsing: Boolean) {
        removeGeckoException(uri, privateBrowsing)
    }

    @VisibleForTesting
    internal suspend fun removeGeckoException(uri: String, privateBrowsing: Boolean) {
        withContext(Dispatchers.Main) {
            geckoStorage.removeCookieBannerModeForDomain(uri, privateBrowsing).awaitCookieBannerResult()
        }
    }

    @VisibleForTesting
    internal suspend fun setGeckoException(
        uri: String,
        mode: CookieBannerHandlingMode,
        privateBrowsing: Boolean,
    ) {
        withContext(Dispatchers.Main) {
            geckoStorage.setCookieBannerModeForDomain(uri, mode.mode, privateBrowsing).awaitCookieBannerResult()
        }
    }

    @VisibleForTesting
    internal fun setPersistentPrivateGeckoException(
        uri: String,
        mode: CookieBannerHandlingMode,
    ) {
        geckoStorage.setCookieBannerModeAndPersistInPrivateBrowsingForDomain(
            uri,
            mode.mode,
        )
    }

    @VisibleForTesting
    @Suppress("TooGenericExceptionCaught")
    internal suspend fun queryExceptionInGecko(
        uri: String,
        privateBrowsing: Boolean,
    ): CookieBannerHandlingMode? {
        return try {
            withContext(Dispatchers.Main) {
                geckoStorage.getCookieBannerModeForDomain(uri, privateBrowsing).awaitCookieBannerResult()
                    ?.toCookieBannerHandlingMode() ?: throw IllegalArgumentException(
                    "An error happened trying to find cookie banners mode for the " +
                        "uri $uri and private browsing mode $privateBrowsing",
                )
            }
        } catch (e: Exception) {
            // This normally happen on internal sites like about:config or ip sites.
            val disabledErrors = listOf("NS_ERROR_INSUFFICIENT_DOMAIN_LEVELS", "NS_ERROR_HOST_IS_IP_ADDRESS")
            if (disabledErrors.any { (e.message ?: "").contains(it) }) {
                Logger("GeckoCookieBannersStorage").error("Unable to query cookie banners exception", e)
                null
            } else {
                throw e
            }
        }
    }
}

@VisibleForTesting
internal fun Int.toCookieBannerHandlingMode(): CookieBannerHandlingMode {
    return CookieBannerHandlingMode.entries.first { it.mode == this }
}

/** Cancellation stops waiting, without claiming it can undo an already dispatched native write. */
private suspend fun <T> GeckoResult<T>.awaitCookieBannerResult(): T? {
    val completion = CompletableDeferred<T?>()
    then(
        {
            completion.complete(it)
            GeckoResult<Void>()
        },
        {
            completion.completeExceptionally(it)
            GeckoResult<Void>()
        },
    )
    return try {
        completion.await()
    } finally {
        completion.cancel()
    }
}
