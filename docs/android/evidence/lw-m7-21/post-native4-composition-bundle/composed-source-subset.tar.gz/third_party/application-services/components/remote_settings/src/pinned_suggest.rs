/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

//! Offline import of one explicitly selected, release-pinned Suggest dataset.
//! This module never performs HTTP requests or accepts caller-supplied records.

use crate::{Error, RemoteSettingsRecord, Result};
use serde::Deserialize;
use sha2::{Digest, Sha256};
use std::{
    collections::{HashMap, HashSet},
    sync::atomic::{AtomicU8, Ordering},
};

const CATALOG: &str = include_str!(concat!(
    env!("CARGO_MANIFEST_DIR"),
    "/dumps/main/redoubt-suggest-catalog.json"
));
const PENDING: u8 = 0;
const VALIDATING: u8 = 1;
const CANCELLED: u8 = 2;
const COMMITTING: u8 = 3;
const FINISHED: u8 = 4;

#[derive(uniffi::Object, Default)]
pub struct SuggestDataInstallToken {
    state: AtomicU8,
}

#[uniffi::export]
impl SuggestDataInstallToken {
    #[uniffi::constructor]
    pub fn new() -> Self {
        Self::default()
    }

    /// True means cancellation won before publication. False means publication
    /// already began or this operation ended; callers must not claim rollback.
    pub fn cancel(&self) -> bool {
        loop {
            let state = self.state.load(Ordering::Acquire);
            if state != PENDING && state != VALIDATING {
                return false;
            }
            if self
                .state
                .compare_exchange(state, CANCELLED, Ordering::AcqRel, Ordering::Acquire)
                .is_ok()
            {
                return true;
            }
        }
    }
}

impl SuggestDataInstallToken {
    pub(crate) fn start(&self) -> Result<()> {
        self.state
            .compare_exchange(PENDING, VALIDATING, Ordering::AcqRel, Ordering::Acquire)
            .map(|_| ())
            .map_err(|_| invalid("Install token was cancelled or already used"))
    }
    pub(crate) fn check(&self) -> Result<()> {
        if self.state.load(Ordering::Acquire) == VALIDATING {
            Ok(())
        } else {
            Err(invalid("Install cancelled"))
        }
    }
    pub(crate) fn begin_commit(&self) -> Result<()> {
        self.state
            .compare_exchange(VALIDATING, COMMITTING, Ordering::AcqRel, Ordering::Acquire)
            .map(|_| ())
            .map_err(|_| invalid("Install cancelled before publication"))
    }
    pub(crate) fn finish(&self) {
        let _ =
            self.state
                .compare_exchange(VALIDATING, FINISHED, Ordering::AcqRel, Ordering::Acquire);
        let _ =
            self.state
                .compare_exchange(COMMITTING, FINISHED, Ordering::AcqRel, Ordering::Acquire);
    }
}

#[derive(uniffi::Record)]
pub struct PinnedSuggestAttachment {
    pub record_id: String,
    pub data: Vec<u8>,
}

#[derive(Deserialize)]
struct Catalog {
    format: u32,
    datasets: Vec<Dataset>,
    icons: Vec<RemoteSettingsRecord>,
    configuration: RemoteSettingsRecord,
    timestamps: HashMap<String, u64>,
}

#[derive(Deserialize)]
struct Dataset {
    id: String,
    collection: String,
    record: RemoteSettingsRecord,
    icon_ids: Vec<String>,
}

pub(crate) struct ValidatedDataset {
    pub records: Vec<RemoteSettingsRecord>,
    pub attachments: Vec<(String, Vec<u8>)>,
    pub timestamp: u64,
}

pub(crate) fn invalid(message: &str) -> Error {
    Error::ConfigError(format!("Pinned Suggest data: {message}"))
}

pub(crate) fn expected_collection_url(collection: &str) -> Result<String> {
    if collection != "quicksuggest-amp" && collection != "quicksuggest-other" {
        return Err(invalid("Only Suggest collections can import pinned data"));
    }
    Ok(format!(
        "https://firefox.settings.services.mozilla.com/v1/buckets/main/collections/{collection}"
    ))
}

pub(crate) fn records_for_dataset(
    collection: &str,
    dataset_id: &str,
) -> Result<(Vec<RemoteSettingsRecord>, u64)> {
    expected_collection_url(collection)?;
    let catalog: Catalog = serde_json::from_str(CATALOG)?;
    if catalog.format != 1 {
        return Err(invalid("Unsupported catalog"));
    }
    let dataset = catalog
        .datasets
        .iter()
        .find(|d| d.id == dataset_id && d.collection == collection)
        .ok_or_else(|| invalid("Unknown dataset for this collection"))?;
    let mut records = vec![dataset.record.clone()];
    for icon_id in &dataset.icon_ids {
        records.push(
            catalog
                .icons
                .iter()
                .find(|r| r.id == *icon_id)
                .ok_or_else(|| invalid("Missing pinned icon record"))?
                .clone(),
        );
    }
    // This is the narrowly scoped explicit-selection context: a user selected
    // these exact pinned language/region records. Device/app targeting must not
    // silently discard that choice. No global RS context or other record changes.
    for record in &mut records {
        record.fields.remove("filter_expression");
        record
            .fields
            .insert("redoubt_explicit_suggest_dataset".into(), dataset_id.into());
    }
    if collection == "quicksuggest-other" {
        records.push(catalog.configuration);
    }
    let timestamp = *catalog
        .timestamps
        .get(collection)
        .ok_or_else(|| invalid("Missing catalog timestamp"))?;
    Ok((records, timestamp))
}

pub(crate) fn validate_dataset(
    collection: &str,
    dataset_id: &str,
    supplied: Vec<PinnedSuggestAttachment>,
    token: &SuggestDataInstallToken,
) -> Result<ValidatedDataset> {
    token.check()?;
    let (records, timestamp) = records_for_dataset(collection, dataset_id)?;
    let expected: HashMap<_, _> = records
        .iter()
        .filter_map(|r| r.attachment.as_ref().map(|a| (r.id.as_str(), a)))
        .collect();
    if supplied.len() != expected.len() {
        return Err(invalid("Incomplete or extra attachments"));
    }
    let mut seen = HashSet::new();
    let mut attachments = Vec::with_capacity(supplied.len());
    for supplied in supplied {
        token.check()?;
        if !seen.insert(supplied.record_id.clone()) {
            return Err(invalid("Duplicate attachment"));
        }
        let metadata = expected
            .get(supplied.record_id.as_str())
            .ok_or_else(|| invalid("Unknown attachment"))?;
        if supplied.data.len() as u64 != metadata.size
            || format!("{:x}", Sha256::digest(&supplied.data)) != metadata.hash
        {
            return Err(invalid("Attachment size or SHA256 mismatch"));
        }
        attachments.push((metadata.location.clone(), supplied.data));
    }
    token.check()?;
    Ok(ValidatedDataset {
        records,
        attachments,
        timestamp,
    })
}

#[cfg(test)]
pub(crate) fn fixture_attachments(dataset_id: &str) -> Vec<PinnedSuggestAttachment> {
    let collection = if dataset_id.starts_with("data-wikipedia-") {
        "quicksuggest-other"
    } else {
        "quicksuggest-amp"
    };
    records_for_dataset(collection, dataset_id).unwrap().0.into_iter()
        .filter(|record| record.attachment.is_some()).map(|record| {
            let data: &[u8] = match record.id.as_str() {
                "sponsored-suggestions-de-phone" => include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/test-data/redoubt-suggest/sponsored-suggestions-de-phone")),
                "data-wikipedia-en" => include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/test-data/redoubt-suggest/data-wikipedia-en")),
                "icon-111a1ffa7f487e807bec4a71460454933db0fe2e7c77bade620375b41530e9a0" => include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/test-data/redoubt-suggest/icon-111a1ffa7f487e807bec4a71460454933db0fe2e7c77bade620375b41530e9a0")),
                "icon-161351842074695" => include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/test-data/redoubt-suggest/icon-161351842074695")),
                "icon-c5684e5a98855b2ad5af82e1a2d4ee2328e6a8518e12c94dc113240fed29e8fe" => include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/test-data/redoubt-suggest/icon-c5684e5a98855b2ad5af82e1a2d4ee2328e6a8518e12c94dc113240fed29e8fe")),
                "icon-e1612973a8b621ef95218b9b0b99674cb3e03c410fde57bcf5277ecc61ba1651" => include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/test-data/redoubt-suggest/icon-e1612973a8b621ef95218b9b0b99674cb3e03c410fde57bcf5277ecc61ba1651")),
                "icon-f46c92ccdc88eb3d4f0fdedc24374aa01fc4ffaf395169b818af92b0020d87b2" => include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/test-data/redoubt-suggest/icon-f46c92ccdc88eb3d4f0fdedc24374aa01fc4ffaf395169b818af92b0020d87b2")),
                other => panic!("Missing explicit fixture {other}"),
            };
            PinnedSuggestAttachment { record_id: record.id, data: data.to_vec() }
        }).collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{
        RemoteSettingsConfig, RemoteSettingsContext, RemoteSettingsServer, RemoteSettingsService,
    };
    use std::sync::Arc;

    fn service(path: &std::path::Path) -> RemoteSettingsService {
        RemoteSettingsService::new(
            path.to_str().unwrap().into(),
            RemoteSettingsConfig {
                app_context: Some(RemoteSettingsContext {
                    locale: Some("de-CH".into()),
                    country: Some("CH".into()),
                    form_factor: Some("phone".into()),
                    ..RemoteSettingsContext::default()
                }),
                ..RemoteSettingsConfig::default()
            },
        )
    }

    #[test]
    fn actual_pinned_wikipedia_install_survives_mismatched_locale_and_reopen() {
        let root = tempfile::tempdir().unwrap();
        let service = service(root.path());
        let client = service.make_client("quicksuggest-other".into());
        client
            .install_pinned_suggest_data(
                "data-wikipedia-en".into(),
                fixture_attachments("data-wikipedia-en"),
                Arc::new(SuggestDataInstallToken::new()),
            )
            .unwrap();
        assert_eq!(
            client.installed_pinned_suggest_data().unwrap().as_deref(),
            Some("data-wikipedia-en")
        );
        let records = client.get_records(false).unwrap();
        assert!(records.iter().any(|r| r.id == "data-wikipedia-en"));
        assert!(records
            .iter()
            .all(|r| !r.fields.contains_key("filter_expression")));
        assert!(records
            .iter()
            .any(|r| r.id == "firefox-suggest-configuration"));
        assert!(client.get_last_modified_timestamp().unwrap() > 0);
        let reopened = service.make_client("quicksuggest-other".into());
        assert_eq!(
            reopened.installed_pinned_suggest_data().unwrap().as_deref(),
            Some("data-wikipedia-en")
        );
        assert_eq!(reopened.get_records(false).unwrap(), records);
    }

    #[test]
    fn actual_pinned_amp_install_is_complete_and_does_not_change_search() {
        let root = tempfile::tempdir().unwrap();
        let service = service(root.path());
        let search = service.make_client("search-config-v2".into());
        let original_search = search.get_records(false);
        let client = service.make_client("quicksuggest-amp".into());
        client
            .install_pinned_suggest_data(
                "sponsored-suggestions-de-phone".into(),
                fixture_attachments("sponsored-suggestions-de-phone"),
                Arc::new(SuggestDataInstallToken::new()),
            )
            .unwrap();
        assert_eq!(
            client.installed_pinned_suggest_data().unwrap().as_deref(),
            Some("sponsored-suggestions-de-phone")
        );
        for record in client.get_records(false).unwrap() {
            assert_eq!(
                client.get_attachment(&record).unwrap().len() as u64,
                record.attachment.unwrap().size
            );
        }
        assert_eq!(search.get_records(false), original_search);
        let config = service
            .make_client("quicksuggest-other".into())
            .get_records(false)
            .unwrap();
        assert_eq!(config.len(), 1);
        assert_eq!(config[0].id, "firefox-suggest-configuration");
    }

    #[test]
    fn corrupt_truncated_duplicate_missing_and_extra_attachments_preserve_old_cache() {
        let root = tempfile::tempdir().unwrap();
        let service = service(root.path());
        let client = service.make_client("quicksuggest-amp".into());
        let id = "sponsored-suggestions-de-phone";
        client
            .install_pinned_suggest_data(
                id.into(),
                fixture_attachments(id),
                Arc::new(SuggestDataInstallToken::new()),
            )
            .unwrap();
        let previous = client.get_records(false).unwrap();
        for variant in 0..5 {
            let mut supplied = fixture_attachments(id);
            match variant {
                0 => supplied[0].data[0] ^= 1,
                1 => {
                    supplied[0].data.pop();
                }
                2 => supplied[1].record_id = supplied[0].record_id.clone(),
                3 => {
                    supplied.pop();
                }
                _ => supplied.push(PinnedSuggestAttachment {
                    record_id: "extra".into(),
                    data: vec![],
                }),
            }
            assert!(client
                .install_pinned_suggest_data(
                    id.into(),
                    supplied,
                    Arc::new(SuggestDataInstallToken::new())
                )
                .is_err());
            assert_eq!(client.get_records(false).unwrap(), previous);
            assert_eq!(
                client.installed_pinned_suggest_data().unwrap().as_deref(),
                Some(id)
            );
        }
    }

    #[test]
    fn cancelled_or_reused_token_cannot_publish() {
        let root = tempfile::tempdir().unwrap();
        let service = service(root.path());
        let client = service.make_client("quicksuggest-amp".into());
        let token = Arc::new(SuggestDataInstallToken::new());
        assert!(token.cancel());
        assert!(client
            .install_pinned_suggest_data(
                "sponsored-suggestions-de-phone".into(),
                fixture_attachments("sponsored-suggestions-de-phone"),
                token
            )
            .is_err());
        assert!(!root.path().join("quicksuggest-amp.sql").exists());
        let token = Arc::new(SuggestDataInstallToken::new());
        client
            .install_pinned_suggest_data(
                "sponsored-suggestions-de-phone".into(),
                fixture_attachments("sponsored-suggestions-de-phone"),
                token.clone(),
            )
            .unwrap();
        assert!(!token.cancel());
        assert!(client
            .install_pinned_suggest_data(
                "sponsored-suggestions-de-phone".into(),
                fixture_attachments("sponsored-suggestions-de-phone"),
                token
            )
            .is_err());
    }

    #[test]
    fn cancellation_and_publication_have_an_explicit_winner() {
        let cancelled = SuggestDataInstallToken::new();
        cancelled.start().unwrap();
        assert!(cancelled.cancel());
        assert!(cancelled.begin_commit().is_err());
        let committed = SuggestDataInstallToken::new();
        committed.start().unwrap();
        committed.begin_commit().unwrap();
        assert!(!committed.cancel());
        committed.finish();
        assert!(committed.start().is_err());
    }

    #[test]
    fn unknown_dataset_collection_and_nonproduction_server_are_rejected() {
        let root = tempfile::tempdir().unwrap();
        let service = service(root.path());
        for (collection, id) in [
            ("search-config-v2", "sponsored-suggestions-de-phone"),
            ("quicksuggest-amp", "unknown"),
            ("quicksuggest-amp", "data-wikipedia-en"),
        ] {
            assert!(service
                .make_client(collection.into())
                .install_pinned_suggest_data(
                    id.into(),
                    vec![],
                    Arc::new(SuggestDataInstallToken::new())
                )
                .is_err());
        }
        let stage = RemoteSettingsService::new(
            root.path().join("stage").to_str().unwrap().into(),
            RemoteSettingsConfig {
                server: Some(RemoteSettingsServer::Stage),
                ..RemoteSettingsConfig::default()
            },
        );
        assert!(stage
            .make_client("quicksuggest-amp".into())
            .install_pinned_suggest_data(
                "sponsored-suggestions-de-phone".into(),
                fixture_attachments("sponsored-suggestions-de-phone"),
                Arc::new(SuggestDataInstallToken::new())
            )
            .is_err());
    }

    #[test]
    fn missing_payload_fallback_remains_blocked() {
        let root = tempfile::tempdir().unwrap();
        let service = service(root.path());
        let client = service.make_client("quicksuggest-amp".into());
        let record = records_for_dataset("quicksuggest-amp", "sponsored-suggestions-de-phone")
            .unwrap()
            .0
            .remove(0);
        let error = client.get_attachment(&record).unwrap_err();
        assert!(error
            .to_string()
            .contains("Remote Settings network requests are disabled"));
        assert_eq!(client.get_records(false).unwrap().len(), 0);
    }
}
