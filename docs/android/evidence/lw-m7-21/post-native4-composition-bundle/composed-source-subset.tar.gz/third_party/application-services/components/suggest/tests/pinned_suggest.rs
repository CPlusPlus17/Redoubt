/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
use remote_settings::{
    PinnedSuggestAttachment, RemoteSettingsConfig, RemoteSettingsContext, RemoteSettingsService,
    SuggestDataInstallToken,
};
use std::{
    path::PathBuf,
    sync::Arc,
    time::{SystemTime, UNIX_EPOCH},
};
use suggest::{
    SuggestIngestionConstraints, SuggestStore, Suggestion, SuggestionProvider, SuggestionQuery,
};

struct Scratch(PathBuf);
impl Scratch {
    fn new() -> Self {
        let path = std::env::temp_dir().join(format!(
            "redoubt-suggest-test-{}-{}",
            std::process::id(),
            SystemTime::now()
                .duration_since(UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        std::fs::create_dir(&path).unwrap();
        Self(path)
    }
}
impl Drop for Scratch {
    fn drop(&mut self) {
        let _ = std::fs::remove_dir_all(&self.0);
    }
}

fn fixture(id: &str) -> Vec<PinnedSuggestAttachment> {
    let catalog: serde_json::Value = serde_json::from_str(include_str!(concat!(
        env!("CARGO_MANIFEST_DIR"),
        "/../remote_settings/dumps/main/redoubt-suggest-catalog.json"
    )))
    .unwrap();
    let dataset = catalog["datasets"]
        .as_array()
        .unwrap()
        .iter()
        .find(|d| d["id"] == id)
        .unwrap();
    std::iter::once(id).chain(dataset["icon_ids"].as_array().unwrap().iter().map(|v| v.as_str().unwrap())).map(|id| {
        let bytes: &[u8] = match id {
            "sponsored-suggestions-de-phone" => include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/../remote_settings/test-data/redoubt-suggest/sponsored-suggestions-de-phone")),
            "data-wikipedia-en" => include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/../remote_settings/test-data/redoubt-suggest/data-wikipedia-en")),
            "icon-111a1ffa7f487e807bec4a71460454933db0fe2e7c77bade620375b41530e9a0" => include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/../remote_settings/test-data/redoubt-suggest/icon-111a1ffa7f487e807bec4a71460454933db0fe2e7c77bade620375b41530e9a0")),
            "icon-161351842074695" => include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/../remote_settings/test-data/redoubt-suggest/icon-161351842074695")),
            "icon-c5684e5a98855b2ad5af82e1a2d4ee2328e6a8518e12c94dc113240fed29e8fe" => include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/../remote_settings/test-data/redoubt-suggest/icon-c5684e5a98855b2ad5af82e1a2d4ee2328e6a8518e12c94dc113240fed29e8fe")),
            "icon-e1612973a8b621ef95218b9b0b99674cb3e03c410fde57bcf5277ecc61ba1651" => include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/../remote_settings/test-data/redoubt-suggest/icon-e1612973a8b621ef95218b9b0b99674cb3e03c410fde57bcf5277ecc61ba1651")),
            "icon-f46c92ccdc88eb3d4f0fdedc24374aa01fc4ffaf395169b818af92b0020d87b2" => include_bytes!(concat!(env!("CARGO_MANIFEST_DIR"), "/../remote_settings/test-data/redoubt-suggest/icon-f46c92ccdc88eb3d4f0fdedc24374aa01fc4ffaf395169b818af92b0020d87b2")),
            other => panic!("No retained fixture {other}"),
        };
        PinnedSuggestAttachment { record_id: id.into(), data: bytes.to_vec() }
    }).collect()
}

fn services(root: &Scratch) -> (Arc<RemoteSettingsService>, SuggestStore) {
    let remote = Arc::new(RemoteSettingsService::new(
        root.0.join("rs").to_str().unwrap().into(),
        RemoteSettingsConfig {
            app_context: Some(RemoteSettingsContext {
                locale: Some("de-CH".into()),
                country: Some("CH".into()),
                form_factor: Some("phone".into()),
                ..RemoteSettingsContext::default()
            }),
            ..RemoteSettingsConfig::default()
        },
    ));
    let store = SuggestStore::new(
        root.0.join("suggest.sqlite").to_str().unwrap(),
        remote.clone(),
    );
    (remote, store)
}

#[test]
fn explicit_wikipedia_install_uses_real_offline_ingestion_despite_locale_mismatch() {
    let root = Scratch::new();
    let (remote, store) = services(&root);
    let client = remote.make_client("quicksuggest-other".into());
    client
        .install_pinned_suggest_data(
            "data-wikipedia-en".into(),
            fixture("data-wikipedia-en"),
            Arc::new(SuggestDataInstallToken::new()),
        )
        .unwrap();
    store
        .ingest(SuggestIngestionConstraints {
            providers: Some(vec![SuggestionProvider::Amp, SuggestionProvider::Wikipedia]),
            ..SuggestIngestionConstraints::default()
        })
        .unwrap();
    let found = store.query(SuggestionQuery::wikipedia("2026 fi")).unwrap();
    assert!(found.iter().any(|result| matches!(result, Suggestion::Wikipedia { icon: Some(icon), .. } if !icon.is_empty())));
    assert_eq!(
        store
            .fetch_global_config()
            .unwrap()
            .show_less_frequently_cap,
        3
    );
    assert!(store.query(SuggestionQuery::amp("gro")).unwrap().is_empty());
}

#[test]
fn explicit_amp_only_install_uses_seed_configuration_and_all_verified_icons() {
    let root = Scratch::new();
    let (remote, store) = services(&root);
    let client = remote.make_client("quicksuggest-amp".into());
    client
        .install_pinned_suggest_data(
            "sponsored-suggestions-de-phone".into(),
            fixture("sponsored-suggestions-de-phone"),
            Arc::new(SuggestDataInstallToken::new()),
        )
        .unwrap();
    store
        .ingest(SuggestIngestionConstraints {
            providers: Some(vec![SuggestionProvider::Amp, SuggestionProvider::Wikipedia]),
            ..SuggestIngestionConstraints::default()
        })
        .unwrap();
    let found = store.query(SuggestionQuery::amp("gro")).unwrap();
    assert!(found.iter().any(
        |result| matches!(result, Suggestion::Amp { icon: Some(icon), .. } if !icon.is_empty())
    ));
    assert_eq!(
        store
            .fetch_global_config()
            .unwrap()
            .show_less_frequently_cap,
        3
    );
    assert!(store
        .query(SuggestionQuery::wikipedia("2026 fi"))
        .unwrap()
        .is_empty());
    client.sync().unwrap(); // Actual patched sync remains an offline no-op.
    assert_eq!(
        client.installed_pinned_suggest_data().unwrap().as_deref(),
        Some("sponsored-suggestions-de-phone")
    );
}
