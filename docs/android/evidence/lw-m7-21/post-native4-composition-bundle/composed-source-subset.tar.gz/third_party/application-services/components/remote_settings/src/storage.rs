/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

use crate::{
    client::CollectionMetadata, client::CollectionSignature,
    schema::RemoteSettingsConnectionInitializer, Attachment, Error, RemoteSettingsRecord, Result,
};
use camino::Utf8PathBuf;
use rusqlite::{params, Connection, OpenFlags, OptionalExtension, Transaction};
use serde_json;
use sha2::{Digest, Sha256};
use std::io;

use sql_support::{open_database::open_database_with_flags, run_maintenance, ConnExt};

/// Internal storage type
///
/// This will store downloaded records/attachments in a SQLite database.  Nothing is implemented
/// yet other than the initial API.
///
/// Most methods input a `collection_url` parameter, is a URL that includes the remote settings
/// server, bucket, and collection. If the `collection_url` for a get method does not match the one
/// for a set method, then this means the application has switched their remote settings config and
/// [Storage] should pretend like nothing is stored in the database.
///
/// The reason for this is the [crate::RemoteSettingsService::update_config] method.  If a consumer
/// passes a new server or bucket to `update_config`, we don't want to be using cached data from
/// the previous config.
pub struct Storage {
    path: Utf8PathBuf,
    conn: ConnectionCell,
}

impl Storage {
    pub fn new(path: Utf8PathBuf) -> Self {
        Self {
            path,
            conn: ConnectionCell::Uninitialized,
        }
    }

    fn transaction(&mut self) -> Result<Transaction<'_>> {
        match &self.conn {
            ConnectionCell::Uninitialized => {
                self.ensure_dir()?;
                self.conn = ConnectionCell::Initialized(open_database_with_flags(
                    &self.path,
                    OpenFlags::default(),
                    &RemoteSettingsConnectionInitializer,
                )?);
            }
            ConnectionCell::Initialized(_) => (),
            ConnectionCell::Closed => return Err(Error::DatabaseClosed),
        }
        match &mut self.conn {
            ConnectionCell::Initialized(conn) => Ok(conn.transaction()?),
            _ => unreachable!(),
        }
    }

    pub fn ensure_dir(&self) -> Result<()> {
        if self.path == ":memory:" {
            return Ok(());
        }
        let Some(dir) = self.path.parent() else {
            return Ok(());
        };
        if !std::fs::exists(dir).map_err(Error::CreateDirError)? {
            match std::fs::create_dir(dir) {
                Ok(()) => (),
                // Another thread created the directory, just ignore the error.
                Err(e) if e.kind() == io::ErrorKind::AlreadyExists => (),
                Err(e) => return Err(Error::CreateDirError(e)),
            }
        }
        Ok(())
    }

    pub fn close(&mut self) {
        self.conn = ConnectionCell::Closed;
    }

    /// Get the last modified timestamp for the stored records
    ///
    /// Returns None if no records are stored or if `collection_url` does not match the
    /// last `collection_url` passed to `insert_collection_content`
    pub fn get_last_modified_timestamp(&mut self, collection_url: &str) -> Result<Option<u64>> {
        let tx = self.transaction()?;
        let mut stmt =
            tx.prepare("SELECT last_modified FROM collection_metadata WHERE collection_url = ?")?;
        let result: Option<u64> = stmt
            .query_row((collection_url,), |row| row.get(0))
            .optional()?;
        Ok(result)
    }

    /// Get cached records for this collection
    ///
    /// Returns None if no records are stored or if `collection_url` does not match the `collection_url` passed
    /// to `insert_collection_content`.
    pub fn get_records(
        &mut self,
        collection_url: &str,
    ) -> Result<Option<Vec<RemoteSettingsRecord>>> {
        let tx = self.transaction()?;

        let fetched = tx.exists(
            "SELECT 1 FROM collection_metadata WHERE collection_url = ?",
            (collection_url,),
        )?;
        let result = if fetched {
            // If fetched before, get the records from the records table
            let records: Vec<RemoteSettingsRecord> = tx
                .prepare("SELECT data FROM records WHERE collection_url = ?")?
                .query_map(params![collection_url], |row| row.get::<_, Vec<u8>>(0))?
                .map(|data| serde_json::from_slice(&data.unwrap()).unwrap())
                .collect();

            Ok(Some(records))
        } else {
            Ok(None)
        };

        tx.commit()?;
        result
    }

    /// Get cached metadata for this collection
    ///
    /// Returns None if no data is stored or if `collection_url` does not match the `collection_url` passed
    /// to `insert_collection_content`.
    pub fn get_collection_metadata(
        &mut self,
        collection_url: &str,
    ) -> Result<Option<CollectionMetadata>> {
        let tx = self.transaction()?;
        // signatures is a JSON array of objects with "signature" and "x5u" fields,
        // so we need to iterate through the rows and construct the list of signatures.
        // we use LEFT JOIN to return a row even if list of signatures is empty.
        let mut stmt_metadata = tx.prepare(
            "
            SELECT
                cm.bucket,
                json_extract(sig.value, '$.x5u') AS x5u,
                json_extract(sig.value, '$.signature') AS signature
            FROM collection_metadata AS cm
            LEFT JOIN json_each(cm.signatures) AS sig ON true
            WHERE cm.collection_url = ?
            ",
        )?;

        let mut rows = stmt_metadata.query(params![collection_url])?;
        let mut bucket: Option<String> = None;
        let mut signatures = Vec::new();

        while let Some(row) = rows.next()? {
            // bucket should be the same for every row, so just set it once
            if bucket.is_none() {
                bucket = Some(row.get(0)?);
            }
            let x5u: Option<String> = row.get(1)?;
            let signature: Option<String> = row.get(2)?;
            if let (Some(x5u), Some(signature)) = (x5u, signature) {
                signatures.push(CollectionSignature { signature, x5u });
            }
        }
        match bucket {
            Some(bucket) => Ok(Some(CollectionMetadata { bucket, signatures })),
            None => Ok(None),
        }
    }

    /// Get cached attachment data
    ///
    /// This returns the last attachment data sent to [Self::set_attachment].
    ///
    /// Returns None if no attachment data is stored or if `collection_url` does not match the `collection_url`
    /// passed to `set_attachment`.
    pub fn get_attachment(
        &mut self,
        collection_url: &str,
        metadata: Attachment,
    ) -> Result<Option<Vec<u8>>> {
        let tx = self.transaction()?;
        let mut stmt =
            tx.prepare("SELECT data FROM attachments WHERE id = ? AND collection_url = ?")?;

        if let Some(data) = stmt
            .query_row((metadata.location, collection_url), |row| {
                row.get::<_, Vec<u8>>(0)
            })
            .optional()?
        {
            // Return None if data doesn't match expected metadata
            if data.len() as u64 != metadata.size {
                return Ok(None);
            }
            let hash = format!("{:x}", Sha256::digest(&data));
            if hash != metadata.hash {
                return Ok(None);
            }
            Ok(Some(data))
        } else {
            Ok(None)
        }
    }

    /// Set cached content for this collection.
    pub fn insert_collection_content(
        &mut self,
        collection_url: &str,
        records: &[RemoteSettingsRecord],
        last_modified: u64,
        metadata: CollectionMetadata,
    ) -> Result<()> {
        let tx = self.transaction()?;

        // Delete ALL existing records and metadata for with different collection_urls.
        //
        // This way, if a user (probably QA) switches the remote settings server in the middle of a
        // browser sessions, we'll delete the stale data from the previous server.
        tx.execute(
            "DELETE FROM records where collection_url <> ?",
            [collection_url],
        )?;
        tx.execute(
            "DELETE FROM collection_metadata where collection_url <> ?",
            [collection_url],
        )?;

        Self::update_record_rows(&tx, collection_url, records)?;
        Self::update_collection_metadata(&tx, collection_url, last_modified, metadata)?;
        Self::cleanup_orphaned_attachments(&tx, collection_url)?;
        tx.commit()?;
        Ok(())
    }

    /// Insert/remove/update rows in the records table based on a records list
    ///
    /// Returns the max last modified record from the list
    fn update_record_rows(
        tx: &Transaction<'_>,
        collection_url: &str,
        records: &[RemoteSettingsRecord],
    ) -> Result<u64> {
        // Find the max last_modified time while inserting records
        let mut max_last_modified = 0;
        {
            let mut insert_stmt = tx.prepare(
                "INSERT OR REPLACE INTO records (id, collection_url, data) VALUES (?, ?, ?)",
            )?;
            let mut delete_stmt = tx.prepare("DELETE FROM records WHERE id=?")?;
            for record in records {
                if record.deleted {
                    delete_stmt.execute(params![&record.id])?;
                } else {
                    max_last_modified = max_last_modified.max(record.last_modified);
                    let data = serde_json::to_vec(&record)?;
                    insert_stmt.execute(params![record.id, collection_url, data])?;
                }
            }
        }
        Ok(max_last_modified)
    }

    /// Update the collection metadata after setting/merging records
    fn update_collection_metadata(
        tx: &Transaction<'_>,
        collection_url: &str,
        last_modified: u64,
        metadata: CollectionMetadata,
    ) -> Result<()> {
        let signatures_json = serde_json::to_string(&metadata.signatures)
            .map_err(|e| rusqlite::Error::ToSqlConversionFailure(Box::new(e)))?;

        let mut stmt = tx.prepare(
            "INSERT OR REPLACE INTO collection_metadata
            (collection_url, last_modified, bucket, signatures)
            VALUES (?, ?, ?, ?)",
        )?;

        stmt.execute((
            collection_url,
            last_modified,
            &metadata.bucket,
            &signatures_json,
        ))?;
        Ok(())
    }

    /// Set the attachment data stored in the database, clearing out any previously stored data
    pub fn set_attachment(
        &mut self,
        collection_url: &str,
        location: &str,
        attachment: &[u8],
    ) -> Result<()> {
        let tx = self.transaction()?;

        // Delete ALL existing attachments for every collection_url
        tx.execute(
            "DELETE FROM attachments WHERE collection_url != ?",
            params![collection_url],
        )?;

        tx.execute(
            "INSERT OR REPLACE INTO ATTACHMENTS \
            (id, collection_url, data) \
            VALUES (?, ?, ?)",
            params![location, collection_url, attachment,],
        )?;

        tx.commit()?;

        Ok(())
    }

    /// Replace only this Suggest collection in one transaction. Validation was
    /// completed before opening the transaction; any write/cancellation failure
    /// rolls back the old records and attachments together.
    pub(crate) fn replace_pinned_suggest_data(
        &mut self,
        collection_url: &str,
        dataset: crate::pinned_suggest::ValidatedDataset,
        token: &crate::SuggestDataInstallToken,
    ) -> Result<()> {
        token.check()?;
        let tx = self.transaction()?;
        tx.execute(
            "DELETE FROM records WHERE collection_url = ?",
            [collection_url],
        )?;
        tx.execute(
            "DELETE FROM attachments WHERE collection_url = ?",
            [collection_url],
        )?;
        Self::update_record_rows(&tx, collection_url, &dataset.records)?;
        Self::update_collection_metadata(
            &tx,
            collection_url,
            dataset.timestamp,
            CollectionMetadata {
                bucket: "main".to_owned(),
                signatures: Vec::new(),
            },
        )?;
        for (location, data) in &dataset.attachments {
            token.check()?;
            tx.execute(
                "INSERT OR REPLACE INTO attachments (id, collection_url, data) VALUES (?, ?, ?)",
                params![location, collection_url, data],
            )?;
        }
        // cancel() returning true is serialized before this publication point.
        // Once this CAS wins, cancellation reports false and cannot promise rollback.
        token.begin_commit()?;
        tx.commit()?;
        Ok(())
    }

    /// Empty out all cached values and start from scratch.  This is called when
    /// RemoteSettingsService::update_config() is called, since that could change the remote
    /// settings server which would invalidate all cached data.
    pub fn empty(&mut self) -> Result<()> {
        let tx = self.transaction()?;
        tx.execute("DELETE FROM records", [])?;
        tx.execute("DELETE FROM attachments", [])?;
        tx.execute("DELETE FROM collection_metadata", [])?;
        tx.commit()?;
        Ok(())
    }

    /// Remove attachments that are no longer referenced by any current record.
    /// When the server updates an attachment, the record gets a new UUID/hash in its location
    /// field. Without this cleanup, the old attachment blob persists forever, causing unbounded
    /// database growth (1+ GB observed in production for `quicksuggest-amp.sql`).
    fn cleanup_orphaned_attachments(tx: &Transaction<'_>, collection_url: &str) -> Result<()> {
        tx.execute(
            "DELETE FROM attachments
             WHERE collection_url = ?1
             AND NOT EXISTS (
                 SELECT 1 FROM records WHERE collection_url = ?1
                 AND json_extract(data, '$.attachment.location') = attachments.id
             )",
            params![collection_url],
        )?;
        Ok(())
    }

    pub fn run_maintenance(&mut self) -> Result<()> {
        if let ConnectionCell::Initialized(conn) = &self.conn {
            run_maintenance(conn)?;
        }

        Ok(())
    }
}

/// Stores the SQLite connection, which is lazily constructed and can be closed/shutdown.
enum ConnectionCell {
    Uninitialized,
    Initialized(Connection),
    Closed,
}

#[cfg(test)]
mod tests {
    use super::Storage;
    use crate::{
        client::CollectionMetadata, client::CollectionSignature, Attachment, RemoteSettingsRecord,
        Result, RsJsonObject,
    };
    use sha2::{Digest, Sha256};

    #[test]
    fn test_storage_set_and_get_records() -> Result<()> {
        let mut storage = Storage::new(":memory:".into());

        let collection_url = "https://example.com/api";
        let records = vec![
            RemoteSettingsRecord {
                id: "1".to_string(),
                last_modified: 100,
                deleted: false,
                attachment: None,
                fields: serde_json::json!({"key": "value1"})
                    .as_object()
                    .unwrap()
                    .clone(),
            },
            RemoteSettingsRecord {
                id: "2".to_string(),
                last_modified: 200,
                deleted: false,
                attachment: None,
                fields: serde_json::json!({"key": "value2"})
                    .as_object()
                    .unwrap()
                    .clone(),
            },
        ];

        // Set records
        storage.insert_collection_content(
            collection_url,
            &records,
            300,
            CollectionMetadata::default(),
        )?;

        // Get records
        let fetched_records = storage.get_records(collection_url)?;
        assert!(fetched_records.is_some());
        let fetched_records = fetched_records.unwrap();
        assert_eq!(fetched_records.len(), 2);
        assert_eq!(fetched_records, records);

        assert_eq!(fetched_records[0].fields["key"], "value1");

        // Get last modified timestamp
        let last_modified = storage.get_last_modified_timestamp(collection_url)?;
        assert_eq!(last_modified, Some(300));

        Ok(())
    }

    #[test]
    fn test_storage_get_records_none() -> Result<()> {
        let mut storage = Storage::new(":memory:".into());

        let collection_url = "https://example.com/api";

        // Get records when none are set
        let fetched_records = storage.get_records(collection_url)?;
        assert!(fetched_records.is_none());

        // Get last modified timestamp when no records
        let last_modified = storage.get_last_modified_timestamp(collection_url)?;
        assert!(last_modified.is_none());

        Ok(())
    }

    #[test]
    fn test_storage_get_records_empty() -> Result<()> {
        let mut storage = Storage::new(":memory:".into());

        let collection_url = "https://example.com/api";

        // Set empty records
        storage.insert_collection_content(
            collection_url,
            &Vec::<RemoteSettingsRecord>::default(),
            42,
            CollectionMetadata::default(),
        )?;

        // Get records
        let fetched_records = storage.get_records(collection_url)?;
        assert_eq!(fetched_records, Some(Vec::new()));

        // Get last modified timestamp when no records
        let last_modified = storage.get_last_modified_timestamp(collection_url)?;
        assert_eq!(last_modified, Some(42));

        Ok(())
    }

    #[test]
    fn test_storage_set_and_get_attachment() -> Result<()> {
        let mut storage = Storage::new(":memory:".into());

        let attachment = &[0x18, 0x64];
        let collection_url = "https://example.com/api";
        let attachment_metadata = Attachment {
            filename: "abc".to_string(),
            mimetype: "application/json".to_string(),
            location: "tmp".to_string(),
            hash: format!("{:x}", Sha256::digest(attachment)),
            size: attachment.len() as u64,
        };

        // Store attachment
        storage.set_attachment(collection_url, &attachment_metadata.location, attachment)?;

        // Get attachment
        let fetched_attachment = storage.get_attachment(collection_url, attachment_metadata)?;
        assert!(fetched_attachment.is_some());
        let fetched_attachment = fetched_attachment.unwrap();
        assert_eq!(fetched_attachment, attachment);

        Ok(())
    }

    #[test]
    fn test_storage_set_and_replace_attachment() -> Result<()> {
        let mut storage = Storage::new(":memory:".into());

        let collection_url = "https://example.com/api";

        let attachment_1 = &[0x18, 0x64];
        let attachment_2 = &[0x12, 0x48];

        let attachment_metadata_1 = Attachment {
            filename: "abc".to_string(),
            mimetype: "application/json".to_string(),
            location: "tmp".to_string(),
            hash: format!("{:x}", Sha256::digest(attachment_1)),
            size: attachment_1.len() as u64,
        };

        let attachment_metadata_2 = Attachment {
            filename: "def".to_string(),
            mimetype: "application/json".to_string(),
            location: "tmp".to_string(),
            hash: format!("{:x}", Sha256::digest(attachment_2)),
            size: attachment_2.len() as u64,
        };

        // Store first attachment
        storage.set_attachment(
            collection_url,
            &attachment_metadata_1.location,
            attachment_1,
        )?;

        // Replace attachment with new data
        storage.set_attachment(
            collection_url,
            &attachment_metadata_2.location,
            attachment_2,
        )?;

        // Get attachment
        let fetched_attachment = storage.get_attachment(collection_url, attachment_metadata_2)?;
        assert!(fetched_attachment.is_some());
        let fetched_attachment = fetched_attachment.unwrap();
        assert_eq!(fetched_attachment, attachment_2);

        Ok(())
    }

    #[test]
    fn test_storage_set_attachment_delete_others() -> Result<()> {
        let mut storage = Storage::new(":memory:".into());

        let collection_url_1 = "https://example.com/api1";
        let collection_url_2 = "https://example.com/api2";

        let attachment_1 = &[0x18, 0x64];
        let attachment_2 = &[0x12, 0x48];

        let attachment_metadata_1 = Attachment {
            filename: "abc".to_string(),
            mimetype: "application/json".to_string(),
            location: "first_tmp".to_string(),
            hash: format!("{:x}", Sha256::digest(attachment_1)),
            size: attachment_1.len() as u64,
        };

        let attachment_metadata_2 = Attachment {
            filename: "def".to_string(),
            mimetype: "application/json".to_string(),
            location: "second_tmp".to_string(),
            hash: format!("{:x}", Sha256::digest(attachment_2)),
            size: attachment_2.len() as u64,
        };

        // Set attachments for two different collections
        storage.set_attachment(
            collection_url_1,
            &attachment_metadata_1.location,
            attachment_1,
        )?;
        storage.set_attachment(
            collection_url_2,
            &attachment_metadata_2.location,
            attachment_2,
        )?;

        // Verify that only the attachment for the second collection remains
        let fetched_attachment_1 =
            storage.get_attachment(collection_url_1, attachment_metadata_1)?;
        assert!(fetched_attachment_1.is_none());

        let fetched_attachment_2 =
            storage.get_attachment(collection_url_2, attachment_metadata_2)?;
        assert!(fetched_attachment_2.is_some());
        let fetched_attachment_2 = fetched_attachment_2.unwrap();
        assert_eq!(fetched_attachment_2, attachment_2);

        Ok(())
    }

    /// Test that orphaned attachments are cleaned up when a record's attachment location changes.
    /// This reproduces the 1.1GB bloat observed in production. The `quicksuggest-amp` collection
    /// has records like:
    /// {
    ///   "type": "amp",
    ///   "country": "US",
    ///   "form_factor": "phone",
    ///   "filter_expression": "env.country == 'US' && env.formFactor == 'phone'",
    ///   "id": "sponsored-suggestions-us-phone",
    ///   "attachment": { "hash": "992ed42aa...", "size": 9795975, "filename": "sponsored-suggestions-us-phone.json", ... }
    /// }
    /// When the data refreshes (schema timestamp changes), the record keeps its ID but gets
    /// a new attachment with a different hash/location. The old cached blob was never cleaned up.
    #[test]
    fn test_storage_orphaned_attachments_cleaned_up_on_update() -> Result<()> {
        let mut storage = Storage::new(":memory:".into());
        let collection_url = "https://example.com/api";

        let attachment_v1 = b"version 1 data";
        let attachment_v2 = b"version 2 data";

        let attachment_meta_v1 = Attachment {
            filename: "sponsored-suggestions-us-phone.json".to_string(),
            mimetype: "application/json".to_string(),
            location: "main-workspace/quicksuggest-amp/attachment-v1.json".to_string(),
            hash: format!("{:x}", Sha256::digest(attachment_v1)),
            size: attachment_v1.len() as u64,
        };

        let attachment_meta_v2 = Attachment {
            filename: "sponsored-suggestions-us-phone.json".to_string(),
            mimetype: "application/json".to_string(),
            location: "main-workspace/quicksuggest-amp/attachment-v2.json".to_string(),
            hash: format!("{:x}", Sha256::digest(attachment_v2)),
            size: attachment_v2.len() as u64,
        };

        // Initially record points to attachment_v1
        let records_v1 = vec![RemoteSettingsRecord {
            id: "sponsored-suggestions-us-phone".to_string(),
            last_modified: 100,
            deleted: false,
            attachment: Some(attachment_meta_v1.clone()),
            fields: serde_json::json!({"type": "amp"})
                .as_object()
                .unwrap()
                .clone(),
        }];

        storage.insert_collection_content(
            collection_url,
            &records_v1,
            100,
            CollectionMetadata::default(),
        )?;
        storage.set_attachment(collection_url, &attachment_meta_v1.location, attachment_v1)?;

        let fetched = storage.get_attachment(collection_url, attachment_meta_v1.clone())?;
        assert!(fetched.is_some(), "v1 attachment should be stored");

        // Simulate a server data refresh while keeping the same record ID
        // but a new attachment location
        let records_v2 = vec![RemoteSettingsRecord {
            id: "sponsored-suggestions-us-phone".to_string(),
            last_modified: 200,
            deleted: false,
            attachment: Some(attachment_meta_v2.clone()),
            fields: serde_json::json!({"type": "amp"})
                .as_object()
                .unwrap()
                .clone(),
        }];

        storage.insert_collection_content(
            collection_url,
            &records_v2,
            200,
            CollectionMetadata::default(),
        )?;
        storage.set_attachment(collection_url, &attachment_meta_v2.location, attachment_v2)?;

        let fetched_v2 = storage.get_attachment(collection_url, attachment_meta_v2)?;
        assert!(fetched_v2.is_some(), "v2 attachment should be stored");

        let fetched_v1 = storage.get_attachment(collection_url, attachment_meta_v1)?;
        assert!(
            fetched_v1.is_none(),
            "v1 attachment should be cleaned up after record points to v2"
        );

        Ok(())
    }

    /// Test that orphaned attachments are cleaned up when a record is deleted via tombstone.
    /// The `quicksuggest-amp` changeset uses filter_expression to target specific countries
    /// and form factors. If the server removes a record (e.g. drops a country), a tombstone
    /// is sent:
    /// {
    ///   "id": "sponsored-suggestions-gb-phone",
    ///   "last_modified": 1774549156905,
    ///   "deleted": true
    /// }
    /// The record row gets deleted, but the cached attachment blob was never cleaned up.
    #[test]
    fn test_storage_orphaned_attachments_cleaned_up_on_delete() -> Result<()> {
        let mut storage = Storage::new(":memory:".into());
        let collection_url = "https://example.com/api";

        let attachment_data = b"sponsored suggestions for GB phone";

        let attachment_meta = Attachment {
            filename: "sponsored-suggestions-gb-phone.json".to_string(),
            mimetype: "application/json".to_string(),
            location: "main-workspace/quicksuggest-amp/attachment-gb.json".to_string(),
            hash: format!("{:x}", Sha256::digest(attachment_data)),
            size: attachment_data.len() as u64,
        };

        // Initially we have two records, one with an attachment
        let initial_records = vec![
            RemoteSettingsRecord {
                id: "sponsored-suggestions-gb-phone".to_string(),
                last_modified: 100,
                deleted: false,
                attachment: Some(attachment_meta.clone()),
                fields: serde_json::json!({"type": "amp"})
                    .as_object()
                    .unwrap()
                    .clone(),
            },
            RemoteSettingsRecord {
                id: "sponsored-suggestions-us-phone".to_string(),
                last_modified: 100,
                deleted: false,
                attachment: None,
                fields: serde_json::json!({"type": "amp"})
                    .as_object()
                    .unwrap()
                    .clone(),
            },
        ];

        storage.insert_collection_content(
            collection_url,
            &initial_records,
            100,
            CollectionMetadata::default(),
        )?;
        storage.set_attachment(collection_url, &attachment_meta.location, attachment_data)?;

        let fetched = storage.get_attachment(collection_url, attachment_meta.clone())?;
        assert!(fetched.is_some(), "GB attachment should be stored");

        // Simulate server sending a tombstone, GB record is deleted
        let updated_records = vec![RemoteSettingsRecord {
            id: "sponsored-suggestions-gb-phone".to_string(),
            last_modified: 200,
            deleted: true,
            attachment: None,
            fields: RsJsonObject::new(),
        }];

        storage.insert_collection_content(
            collection_url,
            &updated_records,
            200,
            CollectionMetadata::default(),
        )?;

        let fetched = storage.get_attachment(collection_url, attachment_meta)?;
        assert!(
            fetched.is_none(),
            "GB attachment should be cleaned up after record is deleted via tombstone"
        );

        Ok(())
    }

    #[test]
    fn test_storage_get_attachment_not_found() -> Result<()> {
        let mut storage = Storage::new(":memory:".into());

        let collection_url = "https://example.com/api";
        let metadata = Attachment::default();

        // Get attachment that doesn't exist
        let fetched_attachment = storage.get_attachment(collection_url, metadata)?;
        assert!(fetched_attachment.is_none());

        Ok(())
    }

    #[test]
    fn test_storage_empty() -> Result<()> {
        let mut storage = Storage::new(":memory:".into());

        let collection_url = "https://example.com/api";
        let attachment = &[0x18, 0x64];

        let records = vec![
            RemoteSettingsRecord {
                id: "1".to_string(),
                last_modified: 100,
                deleted: false,
                attachment: None,
                fields: serde_json::json!({"key": "value1"})
                    .as_object()
                    .unwrap()
                    .clone(),
            },
            RemoteSettingsRecord {
                id: "2".to_string(),
                last_modified: 200,
                deleted: false,
                attachment: Some(Attachment {
                    filename: "abc".to_string(),
                    mimetype: "application/json".to_string(),
                    location: "tmp".to_string(),
                    hash: format!("{:x}", Sha256::digest(attachment)),
                    size: attachment.len() as u64,
                }),
                fields: serde_json::json!({"key": "value2"})
                    .as_object()
                    .unwrap()
                    .clone(),
            },
        ];

        let metadata = records[1]
            .clone()
            .attachment
            .expect("No attachment metadata for record");

        // Set records and attachment
        storage.insert_collection_content(
            collection_url,
            &records,
            42,
            CollectionMetadata::default(),
        )?;
        storage.set_attachment(collection_url, &metadata.location, attachment)?;

        // Verify they are stored
        let fetched_records = storage.get_records(collection_url)?;
        assert!(fetched_records.is_some());
        let fetched_attachment = storage.get_attachment(collection_url, metadata.clone())?;
        assert!(fetched_attachment.is_some());

        // Empty the storage
        storage.empty()?;

        // Verify they are deleted
        let fetched_records = storage.get_records(collection_url)?;
        assert!(fetched_records.is_none());
        let fetched_attachment = storage.get_attachment(collection_url, metadata)?;
        assert!(fetched_attachment.is_none());

        Ok(())
    }

    #[test]
    fn test_storage_collection_url_isolation() -> Result<()> {
        let mut storage = Storage::new(":memory:".into());

        let collection_url1 = "https://example.com/api1";
        let collection_url2 = "https://example.com/api2";
        let records_collection_url1 = vec![RemoteSettingsRecord {
            id: "1".to_string(),
            last_modified: 100,
            deleted: false,
            attachment: None,
            fields: serde_json::json!({"key": "value1"})
                .as_object()
                .unwrap()
                .clone(),
        }];
        let records_collection_url2 = vec![RemoteSettingsRecord {
            id: "2".to_string(),
            last_modified: 200,
            deleted: false,
            attachment: None,
            fields: serde_json::json!({"key": "value2"})
                .as_object()
                .unwrap()
                .clone(),
        }];

        // Set records for collection_url1
        storage.insert_collection_content(
            collection_url1,
            &records_collection_url1,
            42,
            CollectionMetadata::default(),
        )?;
        // Verify records for collection_url1
        let fetched_records = storage.get_records(collection_url1)?;
        assert!(fetched_records.is_some());
        let fetched_records = fetched_records.unwrap();
        assert_eq!(fetched_records.len(), 1);
        assert_eq!(fetched_records, records_collection_url1);

        // Set records for collection_url2, which will clear records for all collections
        storage.insert_collection_content(
            collection_url2,
            &records_collection_url2,
            300,
            CollectionMetadata::default(),
        )?;

        // Verify that records for collection_url1 have been cleared
        let fetched_records = storage.get_records(collection_url1)?;
        assert!(fetched_records.is_none());

        // Verify records for collection_url2 are correctly stored
        let fetched_records = storage.get_records(collection_url2)?;
        assert!(fetched_records.is_some());
        let fetched_records = fetched_records.unwrap();
        assert_eq!(fetched_records.len(), 1);
        assert_eq!(fetched_records, records_collection_url2);

        // Verify last modified timestamps only for collection_url2
        let last_modified1 = storage.get_last_modified_timestamp(collection_url1)?;
        assert_eq!(last_modified1, None);
        let last_modified2 = storage.get_last_modified_timestamp(collection_url2)?;
        assert_eq!(last_modified2, Some(300));

        Ok(())
    }

    #[test]
    fn test_storage_insert_collection_content() -> Result<()> {
        let mut storage = Storage::new(":memory:".into());

        let collection_url = "https://example.com/api";
        let initial_records = vec![RemoteSettingsRecord {
            id: "2".to_string(),
            last_modified: 200,
            deleted: false,
            attachment: None,
            fields: serde_json::json!({"key": "value2"})
                .as_object()
                .unwrap()
                .clone(),
        }];

        // Set initial records
        storage.insert_collection_content(
            collection_url,
            &initial_records,
            42,
            CollectionMetadata::default(),
        )?;

        // Verify initial records
        let fetched_records = storage.get_records(collection_url)?;
        assert!(fetched_records.is_some());
        assert_eq!(fetched_records.unwrap(), initial_records);

        // Update records
        let updated_records = vec![RemoteSettingsRecord {
            id: "2".to_string(),
            last_modified: 200,
            deleted: false,
            attachment: None,
            fields: serde_json::json!({"key": "value2_updated"})
                .as_object()
                .unwrap()
                .clone(),
        }];
        storage.insert_collection_content(
            collection_url,
            &updated_records,
            300,
            CollectionMetadata::default(),
        )?;

        // Verify updated records
        let fetched_records = storage.get_records(collection_url)?;
        assert!(fetched_records.is_some());
        assert_eq!(fetched_records.unwrap(), updated_records);

        // Verify last modified timestamp
        let last_modified = storage.get_last_modified_timestamp(collection_url)?;
        assert_eq!(last_modified, Some(300));

        Ok(())
    }

    // Quick way to generate the fields data for our mock records
    fn test_fields(data: &str) -> RsJsonObject {
        let mut map = serde_json::Map::new();
        map.insert("data".into(), data.into());
        map
    }

    #[test]
    fn test_storage_merge_records() -> Result<()> {
        let mut storage = Storage::new(":memory:".into());

        let collection_url = "https://example.com/api";

        let initial_records = vec![
            RemoteSettingsRecord {
                id: "a".into(),
                last_modified: 100,
                deleted: false,
                attachment: None,
                fields: test_fields("a"),
            },
            RemoteSettingsRecord {
                id: "b".into(),
                last_modified: 200,
                deleted: false,
                attachment: None,
                fields: test_fields("b"),
            },
            RemoteSettingsRecord {
                id: "c".into(),
                last_modified: 300,
                deleted: false,
                attachment: None,
                fields: test_fields("c"),
            },
        ];
        let updated_records = vec![
            // d is new
            RemoteSettingsRecord {
                id: "d".into(),
                last_modified: 1300,
                deleted: false,
                attachment: None,
                fields: test_fields("d"),
            },
            // b was deleted
            RemoteSettingsRecord {
                id: "b".into(),
                last_modified: 1200,
                deleted: true,
                attachment: None,
                fields: RsJsonObject::new(),
            },
            // a was updated
            RemoteSettingsRecord {
                id: "a".into(),
                last_modified: 1100,
                deleted: false,
                attachment: None,
                fields: test_fields("a-with-new-data"),
            },
            // c was not modified, so it's not present in the new response
        ];
        let expected_records = vec![
            // a was updated
            RemoteSettingsRecord {
                id: "a".into(),
                last_modified: 1100,
                deleted: false,
                attachment: None,
                fields: test_fields("a-with-new-data"),
            },
            RemoteSettingsRecord {
                id: "c".into(),
                last_modified: 300,
                deleted: false,
                attachment: None,
                fields: test_fields("c"),
            },
            RemoteSettingsRecord {
                id: "d".into(),
                last_modified: 1300,
                deleted: false,
                attachment: None,
                fields: test_fields("d"),
            },
        ];

        // Set initial records
        storage.insert_collection_content(
            collection_url,
            &initial_records,
            1000,
            CollectionMetadata::default(),
        )?;

        // Verify initial records
        let fetched_records = storage.get_records(collection_url)?.unwrap();
        assert_eq!(fetched_records, initial_records);

        // Update records
        storage.insert_collection_content(
            collection_url,
            &updated_records,
            1300,
            CollectionMetadata::default(),
        )?;

        // Verify updated records
        let mut fetched_records = storage.get_records(collection_url)?.unwrap();
        fetched_records.sort_by_cached_key(|r| r.id.clone());
        assert_eq!(fetched_records, expected_records);

        // Verify last modified timestamp
        let last_modified = storage.get_last_modified_timestamp(collection_url)?;
        assert_eq!(last_modified, Some(1300));
        Ok(())
    }
    #[test]
    fn test_storage_get_collection_metadata() -> Result<()> {
        let mut storage = Storage::new(":memory:".into());

        let collection_url = "https://example.com/api";
        let initial_records = vec![RemoteSettingsRecord {
            id: "2".to_string(),
            last_modified: 200,
            deleted: false,
            attachment: None,
            fields: serde_json::json!({"key": "value2"})
                .as_object()
                .unwrap()
                .clone(),
        }];

        // Set initial records
        storage.insert_collection_content(
            collection_url,
            &initial_records,
            1337,
            CollectionMetadata {
                bucket: "main".into(),
                signatures: vec![
                    CollectionSignature {
                        signature: "b64encodedsig".into(),
                        x5u: "http://15u/".into(),
                    },
                    CollectionSignature {
                        signature: "b64encodedsig2".into(),
                        x5u: "http://15u2/".into(),
                    },
                ],
            },
        )?;

        let metadata = storage.get_collection_metadata(collection_url)?.unwrap();

        assert_eq!(metadata.signatures[0].signature, "b64encodedsig");
        assert_eq!(metadata.signatures[0].x5u, "http://15u/");
        assert_eq!(metadata.signatures[1].signature, "b64encodedsig2");
        assert_eq!(metadata.signatures[1].x5u, "http://15u2/");

        Ok(())
    }
}

#[cfg(test)]
mod pinned_import_tests {
    use super::*;
    use crate::pinned_suggest::{fixture_attachments, validate_dataset, SuggestDataInstallToken};

    #[test]
    fn attachment_write_failure_rolls_back_deleted_records_and_prior_attachments() {
        let mut storage = Storage::new(":memory:".into());
        let url = "https://firefox.settings.services.mozilla.com/v1/buckets/main/collections/quicksuggest-amp";
        let id = "sponsored-suggestions-de-phone";
        let first = SuggestDataInstallToken::new();
        first.start().unwrap();
        let original =
            validate_dataset("quicksuggest-amp", id, fixture_attachments(id), &first).unwrap();
        storage
            .replace_pinned_suggest_data(url, original, &first)
            .unwrap();
        let old_records = storage.get_records(url).unwrap().unwrap();
        let old_timestamp = storage.get_last_modified_timestamp(url).unwrap();
        let tx = storage.transaction().unwrap();
        tx.execute_batch("CREATE TEMP TRIGGER reject_install BEFORE INSERT ON attachments BEGIN SELECT RAISE(FAIL, 'injected attachment write failure'); END;").unwrap();
        tx.commit().unwrap();
        let failed = SuggestDataInstallToken::new();
        failed.start().unwrap();
        let replacement =
            validate_dataset("quicksuggest-amp", id, fixture_attachments(id), &failed).unwrap();
        assert!(storage
            .replace_pinned_suggest_data(url, replacement, &failed)
            .is_err());
        assert_eq!(storage.get_records(url).unwrap().unwrap(), old_records);
        assert_eq!(
            storage.get_last_modified_timestamp(url).unwrap(),
            old_timestamp
        );
        for record in old_records {
            assert!(storage
                .get_attachment(url, record.attachment.unwrap())
                .unwrap()
                .is_some());
        }
    }

    #[test]
    fn cancellation_after_validation_preserves_prior_cache() {
        let mut storage = Storage::new(":memory:".into());
        let url = "https://firefox.settings.services.mozilla.com/v1/buckets/main/collections/quicksuggest-amp";
        let id = "sponsored-suggestions-de-phone";
        let first = SuggestDataInstallToken::new();
        first.start().unwrap();
        storage
            .replace_pinned_suggest_data(
                url,
                validate_dataset("quicksuggest-amp", id, fixture_attachments(id), &first).unwrap(),
                &first,
            )
            .unwrap();
        let old = storage.get_records(url).unwrap();
        let cancelled = SuggestDataInstallToken::new();
        cancelled.start().unwrap();
        let data =
            validate_dataset("quicksuggest-amp", id, fixture_attachments(id), &cancelled).unwrap();
        assert!(cancelled.cancel());
        assert!(storage
            .replace_pinned_suggest_data(url, data, &cancelled)
            .is_err());
        assert_eq!(storage.get_records(url).unwrap(), old);
    }
}

#[cfg(test)]
mod pinned_transaction_boundary_tests {
    use super::*;
    use crate::pinned_suggest::{fixture_attachments, validate_dataset, SuggestDataInstallToken};
    use std::sync::{
        atomic::{AtomicUsize, Ordering},
        Arc,
    };

    fn installed() -> (Storage, String) {
        let mut storage = Storage::new(":memory:".into());
        let url = "https://firefox.settings.services.mozilla.com/v1/buckets/main/collections/quicksuggest-amp".to_owned();
        let token = SuggestDataInstallToken::new();
        token.start().unwrap();
        let data = validate_dataset(
            "quicksuggest-amp",
            "sponsored-suggestions-de-phone",
            fixture_attachments("sponsored-suggestions-de-phone"),
            &token,
        )
        .unwrap();
        storage
            .replace_pinned_suggest_data(&url, data, &token)
            .unwrap();
        (storage, url)
    }

    #[test]
    fn cancellation_from_inside_the_open_write_transaction_rolls_back_everything() {
        let (mut storage, url) = installed();
        let old = storage.get_records(&url).unwrap().unwrap();
        let token = Arc::new(SuggestDataInstallToken::new());
        token.start().unwrap();
        let replacement = validate_dataset(
            "quicksuggest-amp",
            "sponsored-suggestions-de-phone",
            fixture_attachments("sponsored-suggestions-de-phone"),
            &token,
        )
        .unwrap();
        let fired = Arc::new(AtomicUsize::new(0));
        let ConnectionCell::Initialized(conn) = &mut storage.conn else {
            panic!("fixture did not initialize storage");
        };
        let callback_token = token.clone();
        let callback_fired = fired.clone();
        conn.create_scalar_function(
            "cancel_pinned_install",
            0,
            rusqlite::functions::FunctionFlags::SQLITE_UTF8
                | rusqlite::functions::FunctionFlags::SQLITE_INNOCUOUS,
            move |_| {
                callback_fired.fetch_add(1, Ordering::SeqCst);
                Ok(i32::from(callback_token.cancel()))
            },
        )
        .unwrap();
        conn.execute_batch("CREATE TEMP TRIGGER cancel_install AFTER INSERT ON attachments BEGIN SELECT cancel_pinned_install(); END;").unwrap();
        assert!(storage
            .replace_pinned_suggest_data(&url, replacement, &token)
            .is_err());
        assert_eq!(fired.load(Ordering::SeqCst), 1);
        assert_eq!(storage.get_records(&url).unwrap().unwrap(), old);
        for record in old {
            assert!(storage
                .get_attachment(&url, record.attachment.unwrap())
                .unwrap()
                .is_some());
        }
    }

    #[test]
    fn a_failure_at_commit_preserves_old_records_metadata_and_attachments() {
        let (mut storage, url) = installed();
        let old = storage.get_records(&url).unwrap().unwrap();
        let timestamp = storage.get_last_modified_timestamp(&url).unwrap();
        let token = SuggestDataInstallToken::new();
        token.start().unwrap();
        let replacement = validate_dataset(
            "quicksuggest-amp",
            "sponsored-suggestions-de-phone",
            fixture_attachments("sponsored-suggestions-de-phone"),
            &token,
        )
        .unwrap();
        let ConnectionCell::Initialized(conn) = &mut storage.conn else {
            panic!("fixture did not initialize storage");
        };
        // This fails at COMMIT, after every attachment INSERT succeeded.
        conn.execute_batch("PRAGMA foreign_keys=ON;
            CREATE TABLE pinned_parent(id INTEGER PRIMARY KEY);
            CREATE TABLE pinned_child(parent_id INTEGER REFERENCES pinned_parent(id) DEFERRABLE INITIALLY DEFERRED);
            CREATE TEMP TRIGGER fail_install_commit AFTER INSERT ON attachments BEGIN INSERT INTO pinned_child(parent_id) VALUES (999); END;").unwrap();
        assert!(storage
            .replace_pinned_suggest_data(&url, replacement, &token)
            .is_err());
        assert!(!token.cancel()); // Publication began; failed COMMIT rolled it back.
        assert_eq!(storage.get_records(&url).unwrap().unwrap(), old);
        assert_eq!(
            storage.get_last_modified_timestamp(&url).unwrap(),
            timestamp
        );
        for record in old {
            assert!(storage
                .get_attachment(&url, record.attachment.unwrap())
                .unwrap()
                .is_some());
        }
    }
}
