/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
"use strict";

AddonTestUtils.init(this);
AddonTestUtils.createAppInfo(
  "xpcshell@tests.mozilla.org",
  "XPCShell",
  "1",
  "42"
);

const { ExtensionPermissions } = ChromeUtils.importESModule(
  "resource://gre/modules/ExtensionPermissions.sys.mjs"
);
const { GeckoViewWebExtension } = ChromeUtils.importESModule(
  "resource://gre/modules/GeckoViewWebExtension.sys.mjs"
);
const { sinon } = ChromeUtils.importESModule(
  "resource://testing-common/Sinon.sys.mjs"
);
const ID = "permission-durability@tests.mozilla.org";
const OTHER = "permission-durability-other@tests.mozilla.org";
const permission = () => ({
  permissions: ["internal:privateBrowsingAllowed"],
  origins: [],
  data_collection: [],
});
const PERMISSIONS_PATH = PathUtils.join(do_get_profile().path, "extension-preferences.json");

add_setup(async function setup() {
  ExtensionPermissions._useLegacyStorageBackend = true;
  await ExtensionPermissions._uninit();
  registerCleanupFunction(async () => {
    await ExtensionPermissions.removeAll(ID);
    await ExtensionPermissions.removeAll(OTHER);
    await ExtensionPermissions._uninit({ recreateStore: false });
  });
});

add_task(async function completion_is_already_on_disk() {
  await Promise.all([
    ExtensionPermissions.add(ID, permission()),
    ExtensionPermissions.add(OTHER, permission()),
  ]);
  let disk = await IOUtils.readJSON(PERMISSIONS_PATH);
  Assert.deepEqual(disk[ID], permission(), "add completion persisted the choice");
  Assert.deepEqual(disk[OTHER], permission(), "other ID survived a shared-file write");
  await ExtensionPermissions.remove(ID, permission());
  disk = await IOUtils.readJSON(PERMISSIONS_PATH);
  Assert.deepEqual(disk[ID].permissions, [], "remove completion persisted revocation");
  await ExtensionPermissions.removeAll(OTHER);
  disk = await IOUtils.readJSON(PERMISSIONS_PATH);
  Assert.ok(!(OTHER in disk), "removeAll completion already removed the disk record");
});

add_task(async function failed_writes_preserve_retry_and_cache() {
  const sandbox = sinon.createSandbox();
  try {
    sandbox.stub(IOUtils, "writeJSON").rejects(new Error("controlled write failure"));
    await Assert.rejects(ExtensionPermissions.add(ID, permission()), /controlled write failure/);
    Assert.deepEqual((await ExtensionPermissions.get(ID)).permissions, [], "failed grant not published");
  } finally {
    sandbox.restore();
  }
  await ExtensionPermissions.add(ID, permission());
  Assert.deepEqual((await IOUtils.readJSON(PERMISSIONS_PATH))[ID], permission(), "same grant retries persistence");
  try {
    sandbox.stub(IOUtils, "writeJSON").rejects(new Error("controlled write failure"));
    await Assert.rejects(ExtensionPermissions.remove(ID, permission()), /controlled write failure/);
    await Assert.rejects(ExtensionPermissions.removeAll(ID), /controlled write failure/);
    Assert.deepEqual(await ExtensionPermissions.get(ID), permission(), "failed removals leave the committed grant");
  } finally {
    sandbox.restore();
  }
  await ExtensionPermissions.removeAll(ID);
  Assert.ok(!(ID in (await IOUtils.readJSON(PERMISSIONS_PATH))), "removeAll retries the failed write");
});

add_task(async function stale_derived_cache_is_never_authority() {
  // Exercise the real JSON and modern KV backends; only unit setup switches it.
  for (const legacy of [true, false]) {
    ExtensionPermissions._useLegacyStorageBackend = legacy;
    await ExtensionPermissions._uninit();
    await ExtensionPermissions.removeAll(ID);
    await ExtensionParent.StartupCache.permissions.set(ID, permission());
    Assert.deepEqual((await ExtensionPermissions.get(ID)).permissions, [], "stale cache cannot resurrect grant");
    await ExtensionPermissions.add(ID, permission());
    await ExtensionParent.StartupCache.permissions.set(ID, { permissions: [], origins: [] });
    Assert.deepEqual(await ExtensionPermissions.get(ID), permission(), "stale cache cannot erase grant");
    await ExtensionPermissions.removeAll(ID);
  }
  ExtensionPermissions._useLegacyStorageBackend = true;
  await ExtensionPermissions._uninit();
});

add_task(async function geckoview_uninstall_waits_original_permission_cleanup() {
  const sandbox = sinon.createSandbox();
  const cleanup = Promise.withResolvers();
  let emitted = false;
  sandbox.stub(GeckoViewWebExtension, "extensionById").resolves({
    async uninstall() {
      Management.emit("cleanupAfterUninstall", ID, [
        { name: `Clear ExtensionPermissions for ${ID}`, promise: cleanup.promise },
      ]);
      emitted = true;
    },
  });
  try {
    let completed = false;
    const result = GeckoViewWebExtension.uninstallWebExtension(ID);
    result.then(() => { completed = true; }, () => {});
    await TestUtils.waitForCondition(() => emitted);
    Assert.ok(!completed, "uninstall completion waits for permission persistence");
    cleanup.reject(new Error("original permission write failed"));
    await Assert.rejects(result, /original permission write failed/);
  } finally {
    sandbox.restore();
  }
});
