/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

"use strict";

// XPCShellMain does not call InitializeUserPrefs, including on Android.
// do_get_profile() registers directories, not the native current prefs file.
// Actual current-profile I/O belongs to GeckoView PrefSaveFileAsyncTest.
const PREF = "test.librewolf.savePrefFileAsync.value";
let fixture;

function childFile(name) {
  const file = fixture.clone();
  file.append(name);
  return file;
}

async function savedValue(file) {
  let value;
  const record = (_kind, name, saved) => {
    if (name === PREF) {
      value = saved;
    }
  };
  Services.prefs.parsePrefsFromBuffer(await IOUtils.read(file.path), {
    onStringPref: record,
    onIntPref: record,
    onBoolPref: record,
    onError(message) {
      Assert.ok(false, `Malformed saved preference file: ${message}`);
    },
  });
  return value;
}

async function rejectsWithoutCurrentProfile() {
  // Capture either an XPIDL synchronous error or a rejected DOM Promise.
  await Assert.rejects(
    Promise.resolve().then(() => Services.prefs.savePrefFileAsync()),
    /NS_ERROR_NOT_INITIALIZED/
  );
}

add_setup(async function initialize() {
  Assert.equal(typeof Services.prefs.savePrefFileAsync, "function");
  Assert.ok(Services.prefs.getBoolPref("preferences.allow.omt-write"));
  Assert.ok(!Services.prefs.prefHasUserValue(PREF));
  await rejectsWithoutCurrentProfile();
  fixture = do_get_profile().clone();
  fixture.append("lw-m7-35-backups");
  fixture.createUnique(Ci.nsIFile.DIRECTORY_TYPE, 0o700);
  registerCleanupFunction(() => {
    Services.prefs.clearUserPref(PREF);
    Services.prefs.QueryInterface(Ci.nsIObserver).observe(
      null,
      "suspend_process_notification",
      null
    );
    if (fixture.exists()) {
      fixture.remove(true);
    }
  });
});

add_task(async function directory_registration_is_not_native_initialization() {
  await rejectsWithoutCurrentProfile();
});

add_task(async function backup_snapshots_fail_independently_and_suspend_drains() {
  const backupA = childFile("a.js");
  const backupB = childFile("b.js");
  const failed = childFile("directory");
  failed.create(Ci.nsIFile.DIRECTORY_TYPE, 0o700);

  // No yield between requests: each destination needs its own captured data.
  Services.prefs.setStringPref(PREF, "backup-a");
  const first = Services.prefs.backupPrefFile(backupA);
  Services.prefs.setStringPref(PREF, "failed-backup");
  const rejection = Assert.rejects(
    Services.prefs.backupPrefFile(failed),
    /NS_ERROR_/
  );
  Services.prefs.setStringPref(PREF, "backup-b");
  const second = Services.prefs.backupPrefFile(backupB);

  // Direct invocation preserves the observer's nsresult. No current profile
  // exists, but its serial backup queue must still be drained before returning.
  Services.prefs.QueryInterface(Ci.nsIObserver).observe(
    null,
    "suspend_process_notification",
    null
  );
  Assert.ok(backupA.isFile(), "First backup exists at blocking return");
  Assert.ok(backupB.isFile(), "Second backup exists at blocking return");
  await Promise.all([first, rejection, second]);
  Assert.equal(await savedValue(backupA), "backup-a");
  Assert.equal(await savedValue(backupB), "backup-b");
  Assert.ok(failed.isDirectory(), "Failed write preserved its target");
  await rejectsWithoutCurrentProfile();

  // A subsequent successful request must not inherit the preceding error.
  failed.remove(false);
  Services.prefs.setStringPref(PREF, "retry");
  await Services.prefs.backupPrefFile(failed);
  Assert.equal(await savedValue(failed), "retry");
  await rejectsWithoutCurrentProfile();
});
