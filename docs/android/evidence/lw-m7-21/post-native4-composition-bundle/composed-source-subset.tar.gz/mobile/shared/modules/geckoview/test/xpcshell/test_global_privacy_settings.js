/* Any copyright is dedicated to the Public Domain.
   http://creativecommons.org/publicdomain/zero/1.0/ */

const { GlobalPrivacySettings } = ChromeUtils.importESModule("resource://gre/modules/GeckoViewGlobalPrivacy.sys.mjs");
const RFP = "privacy.resistFingerprinting";
const POLICY = "network.http.referer.XOriginPolicy";
const WEBGL = "librewolf.webgl.prompt";

// xpcshell do_get_profile does not establish Preferences.mCurrentFile. These
// tests use actual native pref/permission services and an explicitly injected
// save boundary. Real current-profile durability is covered by Task35 and the
// GeckoRuntime GlobalPrivacySettingsTest; it is not asserted by this file.
function controller(save = async () => {}) {
  const names = ["getPrefType", "prefHasUserValue", "prefHasDefaultValue", "prefIsLocked", "getDefaultBranch",
    "getBoolPref", "getIntPref", "getStringPref", "setBoolPref", "setIntPref", "clearUserPref"];
  const prefs = Object.fromEntries(names.map(name => [name, Services.prefs[name].bind(Services.prefs)]));
  prefs.savePrefFileAsync = save;
  return new GlobalPrivacySettings(prefs);
}
function entry(state, id) { return state.settings.find(row => row.id === id); }

add_setup(function setup() {
  do_get_profile();
  for (const [name, value] of [[RFP, true], [WEBGL, true], ["librewolf.webgl.prompt.hide", true], ["network.dns.disableIPv6", false], [POLICY, 0]]) {
    const defaults = Services.prefs.getDefaultBranch("");
    Assert.ok(Services.prefs.prefHasDefaultValue(name), "patched target defines each supported native preference");
    const oldDefault = typeof value === "boolean" ? defaults.getBoolPref(name) : defaults.getIntPref(name);
    const hadUser = Services.prefs.prefHasUserValue(name);
    const wasLocked = Services.prefs.prefIsLocked(name);
    Assert.ok(!wasLocked, "isolated xpcshell fixture must not begin with a hidden locked user value");
    const before = typeof value === "boolean" ? Services.prefs.getBoolPref(name, value) : Services.prefs.getIntPref(name, value);
    if (typeof value === "boolean") defaults.setBoolPref(name, value); else defaults.setIntPref(name, value);
    Services.prefs.clearUserPref(name);
    registerCleanupFunction(() => {
      Services.prefs.unlockPref(name);
      if (typeof value === "boolean") defaults.setBoolPref(name, oldDefault); else defaults.setIntPref(name, oldDefault);
      if (hadUser) { if (typeof value === "boolean") Services.prefs.setBoolPref(name, before); else Services.prefs.setIntPref(name, before); }
      else Services.prefs.clearUserPref(name);
    });
  }
});

add_task(async function native_locked_user_state_is_honest() {
  Services.prefs.setBoolPref(RFP, false); Services.prefs.lockPref(RFP);
  try {
    const service = controller(); const read = entry(await service.request({ action: "get" }), "rfp");
    Assert.equal(read.value, 1); Assert.ok(read.hasUser); Assert.ok(read.locked);
    Assert.equal(read.userValue, null); Assert.ok(!read.userValueKnown);
    Assert.equal((await service.request({ action: "set", id: "rfp", value: false })).reason, "locked");
  } finally { Services.prefs.unlockPref(RFP); Services.prefs.clearUserPref(RFP); }
});

add_task(async function native_int_one_and_reset_preserve_real_branches() {
  const service = controller();
  const changed = await service.request({ action: "set", id: "referrerPolicy", value: 1 });
  Assert.equal(changed.status, "saved"); Assert.equal(Services.prefs.getIntPref(POLICY), 1);
  Assert.ok(Services.prefs.prefHasUserValue(POLICY));
  await service.request({ action: "reset", id: "referrerPolicy" });
  Assert.ok(!Services.prefs.prefHasUserValue(POLICY)); Assert.equal(Services.prefs.getIntPref(POLICY), 0);
});

add_task(async function final_save_failure_keeps_native_memory_and_uncertainty() {
  let calls = 0; const service = controller(async () => { if (++calls === 2) throw new Error("injected final-save failure"); });
  const changed = await service.request({ action: "set", id: "rfp", value: false });
  Assert.equal(changed.status, "unconfirmed"); Assert.ok(!Services.prefs.getBoolPref(RFP));
  Assert.ok(entry(await service.request({ action: "get" }), "rfp").persistenceUnconfirmed);
  Assert.equal(calls, 2); Services.prefs.clearUserPref(RFP);
});

add_task(async function WebGL_global_choices_preserve_actual_site_permissions() {
  const principal = Services.scriptSecurityManager.createContentPrincipal(Services.io.newURI("https://global-privacy.example:8443"), {});
  Services.perms.addFromPrincipal(principal, "webgl", Ci.nsIPermissionManager.DENY_ACTION);
  try {
    const service = controller(); await service.request({ action: "set", id: "webglPrompt", value: false });
    Assert.equal(Services.perms.testExactPermissionFromPrincipal(principal, "webgl"), Ci.nsIPermissionManager.DENY_ACTION);
    await service.request({ action: "reset", id: "webglPrompt" });
    Assert.equal(Services.perms.testExactPermissionFromPrincipal(principal, "webgl"), Ci.nsIPermissionManager.DENY_ACTION);
  } finally { Services.perms.removeFromPrincipal(principal, "webgl"); Services.prefs.clearUserPref(WEBGL); }
});

add_task(async function setting_the_native_default_does_not_invent_a_user_branch() {
  const service = controller();
  Services.prefs.setBoolPref(RFP, false);
  const result = await service.request({ action: "set", id: "rfp", value: true });
  Assert.equal(result.status, "saved");
  Assert.ok(!Services.prefs.prefHasUserValue(RFP));
  Assert.ok(!entry(result.state, "rfp").hasUser);
  Assert.equal(entry(result.state, "rfp").value, 1);
});
