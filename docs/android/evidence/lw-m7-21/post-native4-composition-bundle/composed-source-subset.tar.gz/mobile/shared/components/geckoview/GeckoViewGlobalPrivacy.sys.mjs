/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

// A deliberately separate interface from generic GeckoView preferences and
// RuntimeSettings: these five user prefs must survive startup reset ownership.
const SETTINGS = Object.freeze({
  rfp: { name: "privacy.resistFingerprinting", type: "bool" },
  webglPrompt: { name: "librewolf.webgl.prompt", type: "bool" },
  webglHide: { name: "librewolf.webgl.prompt.hide", type: "bool" },
  disableIPv6: { name: "network.dns.disableIPv6", type: "bool" },
  referrerPolicy: { name: "network.http.referer.XOriginPolicy", type: "int" },
});

export class GlobalPrivacySettings {
  constructor(prefs = Services.prefs) {
    this.prefs = prefs;
    this.queue = Promise.resolve();
    this.unconfirmed = new Set();
  }

  // Reads join the same queue so an acknowledgment cannot be overtaken by a
  // later UI read/reset. External native pref writers remain independent.
  request(operation) {
    const captured = operation && typeof operation === "object" && !Array.isArray(operation)
      ? Object.freeze({ ...operation }) : operation;
    const run = this.queue.then(() => this.perform(captured));
    this.queue = run.catch(() => {});
    return run;
  }

  readValue(branch, definition) {
    return definition.type === "bool"
      ? Number(branch.getBoolPref(definition.name))
      : branch.getIntPref(definition.name);
  }

  readSetting(id) {
    const definition = SETTINGS[id];
    const { prefs } = this;
    const expectedType = definition.type === "bool"
      ? Ci.nsIPrefBranch.PREF_BOOL : Ci.nsIPrefBranch.PREF_INT;
    const available = prefs.getPrefType(definition.name) === expectedType;
    const hasUser = prefs.prefHasUserValue(definition.name);
    const hasDefault = prefs.prefHasDefaultValue(definition.name);
    const locked = prefs.prefIsLocked(definition.name);
    // A normal user-branch getter resolves locks to the default. Never unlock
    // to inspect, and never pretend that effective value is a hidden user value.
    const userValueKnown = !hasUser || (!locked && available);
    return {
      id, type: definition.type, available, hasUser, hasDefault, locked, userValueKnown,
      persistenceUnconfirmed: this.unconfirmed.has(id),
      value: available ? this.readValue(prefs, definition) : null,
      defaultValue: available && hasDefault
        ? this.readValue(prefs.getDefaultBranch(""), definition) : null,
      userValue: available && hasUser && !locked
        ? this.readValue(prefs, definition) : null,
    };
  }

  context() {
    const bool = name => {
      try { return this.prefs.getBoolPref(name); } catch (_) { return null; }
    };
    const integer = name => {
      try { return this.prefs.getIntPref(name); } catch (_) { return null; }
    };
    const configured = name => {
      try { return Boolean(this.prefs.getStringPref(name).trim()); } catch (_) { return null; }
    };
    return {
      rfpPrivate: bool("privacy.resistFingerprinting.pbmode"),
      fingerprintingProtection: bool("privacy.fingerprintingProtection"),
      fingerprintingProtectionPrivate: bool("privacy.fingerprintingProtection.pbmode"),
      rfpExemptions: configured("privacy.resistFingerprinting.exemptedDomains"),
      fingerprintingOverrides: configured("privacy.fingerprintingProtection.overrides"),
      webglDisabled: bool("webgl.disabled"),
      referrerTrimming: integer("network.http.referer.XOriginTrimmingPolicy"),
      dnsOverHttpsMode: integer("network.trr.mode"),
    };
  }

  snapshot() {
    return { settings: Object.keys(SETTINGS).map(id => this.readSetting(id)), context: this.context() };
  }

  validate(operation) {
    if (!operation || typeof operation !== "object" || Array.isArray(operation) ||
        typeof operation.id !== "string" || !Object.hasOwn(SETTINGS, operation.id) ||
        (operation.action !== "set" && operation.action !== "reset")) {
      return "invalid-request";
    }
    const allowedKeys = operation.action === "set" ? ["action", "id", "value"] : ["action", "id"];
    if (Object.keys(operation).some(key => !allowedKeys.includes(key))) return "invalid-request";
    const definition = SETTINGS[operation.id];
    if (operation.action === "set" &&
        (definition.type === "bool" ? typeof operation.value !== "boolean" :
          !Number.isInteger(operation.value) || operation.value < 0 || operation.value > 2)) {
      return "invalid-value";
    }
    const state = this.readSetting(operation.id);
    if (!state.available) return "unavailable";
    if (state.locked) return "locked";
    return null;
  }

  identity(state) {
    const { persistenceUnconfirmed, ...nativeState } = state;
    return JSON.stringify(nativeState);
  }

  async flush() {
    const pending = new Map([...this.unconfirmed].map(id => [id, this.identity(this.readSetting(id))]));
    await this.prefs.savePrefFileAsync();
    for (const [id, saved] of pending) {
      if (this.identity(this.readSetting(id)) === saved) this.unconfirmed.delete(id);
    }
  }

  async perform(operation) {
    const rejected = reason => ({ status: "rejected", reason, state: this.snapshot() });
    if (!operation || typeof operation !== "object" || Array.isArray(operation)) return rejected("invalid-request");
    if (operation.action === "get" && Object.keys(operation).length === 1) {
      return this.snapshot();
    }
    let reason = this.validate(operation);
    if (reason) return rejected(reason);
    // A forced preflight rejects no-profile, shutdown and write-path errors
    // before this operation mutates a preference. It is not a future guarantee.
    try {
      await this.flush();
    } catch (_) {
      return rejected("preflight-save-failed");
    }
    reason = this.validate(operation); // Recheck locks/type after the await.
    if (reason) return rejected(reason);
    const definition = SETTINGS[operation.id];
    this.unconfirmed.add(operation.id);
    try {
      if (operation.action === "reset") {
        this.prefs.clearUserPref(definition.name);
      } else if (definition.type === "bool") {
        this.prefs.setBoolPref(definition.name, operation.value);
      } else {
        this.prefs.setIntPref(definition.name, operation.value);
      }
    } catch (_) {
      // Synchronous observers can intervene while setters notify. Report actual
      // state and do not claim this error proves that no mutation happened.
      return { status: "unconfirmed", reason: "write-failed", state: this.snapshot() };
    }
    const written = this.readSetting(operation.id);
    // Native SetUserValue clears a non-sticky user value that equals its
    // default. Match the requested effective value without inventing a user
    // branch or treating normal native normalization as supersession.
    const requested = !written.locked && written.available &&
      (operation.action === "reset" ? !written.hasUser :
        written.value === Number(operation.value));
    try {
      // Task35 owns an immutable snapshot and resolves only the actual current
      // profile write result. An already-started save cannot be cancelled.
      await this.flush();
    } catch (_) {
      return { status: "unconfirmed", reason: "save-failed", state: this.snapshot() };
    }
    const state = this.snapshot();
    const current = state.settings.find(entry => entry.id === operation.id);
    // An independent writer or lock may change this pref while disk I/O runs.
    // Saved refers to this setting's snapshot, never a promise about other prefs.
    const matches = requested && this.identity(current) === this.identity(written);
    return { status: matches ? "saved" : "superseded", reason: matches ? "" : "changed-during-save", state };
  }
}

const settings = new GlobalPrivacySettings();
export const GeckoViewGlobalPrivacy = {
  onEvent(event, data, callback) {
    if (event !== "GeckoView:GlobalPrivacy:Operation") {
      callback.onError("Unsupported global privacy operation");
      return;
    }
    settings.request(data).then(
      state => callback.onSuccess(state),
      () => callback.onError("Could not read native global privacy state")
    );
  },
};
