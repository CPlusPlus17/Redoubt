/* Any copyright is dedicated to the Public Domain.
   http://creativecommons.org/publicdomain/zero/1.0/ */
package org.mozilla.geckoview.test

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.MediumTest
import org.junit.Assert.*
import org.junit.Assume.assumeTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.mozilla.geckoview.GeckoGlobalPrivacyController as Controller

/** These tests require a real GeckoRuntime profile; host source tests cannot replace them. */
@RunWith(AndroidJUnit4::class)
@MediumTest
class GlobalPrivacySettingsTest : BaseSessionTest() {
    private fun state() = sessionRule.waitForResult(Controller.getState())
    private fun preference(id: String) = state().settings.single { it.id == id }
    private fun restore(original: Controller.PreferenceState) {
        if (!original.hasUserValue) {
            assertEquals(Controller.ChangeResult.SAVED, sessionRule.waitForResult(Controller.reset(original.id)).status)
        } else if (original.id == Controller.REFERRER_POLICY) {
            assertEquals(Controller.ChangeResult.SAVED, sessionRule.waitForResult(Controller.setReferrerPolicy(requireNotNull(original.userValue))).status)
        } else {
            assertEquals(Controller.ChangeResult.SAVED, sessionRule.waitForResult(Controller.setBoolean(original.id, original.userValue == 1)).status)
        }
    }

    @Test fun acknowledgedBooleanWriteAndResetReadNativeBranches() {
        val original = preference(Controller.RFP); assumeTrue(original.available && !original.locked)
        try {
            val value = original.value != 1
            val changed = sessionRule.waitForResult(Controller.setBoolean(Controller.RFP, value))
            assertEquals(Controller.ChangeResult.SAVED, changed.status)
            val read = preference(Controller.RFP)
            assertEquals(if (value) 1 else 0, read.value); assertTrue(read.hasUserValue); assertFalse(read.persistenceUnconfirmed)
            val reset = sessionRule.waitForResult(Controller.reset(Controller.RFP))
            assertEquals(Controller.ChangeResult.SAVED, reset.status)
            val restoredDefault = preference(Controller.RFP)
            assertFalse(restoredDefault.hasUserValue); assertEquals(restoredDefault.defaultValue, restoredDefault.value)
            val sameDefault = sessionRule.waitForResult(Controller.setBoolean(Controller.RFP, restoredDefault.value == 1))
            assertEquals(Controller.ChangeResult.SAVED, sameDefault.status)
            assertFalse(preference(Controller.RFP).hasUserValue)
        } finally { restore(original) }
    }

    @Test fun middleReferrerPolicySurvivesTheActualPublicApi() {
        val original = preference(Controller.REFERRER_POLICY)
        assumeTrue(original.available && !original.locked && (!original.hasUserValue || original.userValue?.let { it in 0..2 } == true))
        try {
            assertEquals(Controller.ChangeResult.SAVED, sessionRule.waitForResult(Controller.setReferrerPolicy(1)).status)
            assertEquals(1, preference(Controller.REFERRER_POLICY).value)
            assertEquals(Controller.ChangeResult.SAVED, sessionRule.waitForResult(Controller.setReferrerPolicy(2)).status)
            assertEquals(2, preference(Controller.REFERRER_POLICY).value)
        } finally { restore(original) }
    }

    @Test fun publicApiRejectsAdditionalPrefsAndInvalidValuesBeforeDispatch() {
        try { Controller.setBoolean("webgl.disabled", true); fail("must reject") } catch (_: IllegalArgumentException) { }
        try { Controller.setBoolean(Controller.REFERRER_POLICY, true); fail("must reject") } catch (_: IllegalArgumentException) { }
        try { Controller.setReferrerPolicy(3); fail("must reject") } catch (_: IllegalArgumentException) { }
        assertEquals(5, state().settings.size)
    }
}
