/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.fenix.settings.search

import org.json.JSONObject
import java.security.MessageDigest
import java.util.Locale

internal data class SuggestDataAttachment(val recordId: String, val url: String, val size: Int, val sha256: String)

internal data class SuggestDataSet(
    val id: String,
    val collection: String,
    val kind: String,
    val language: String?,
    val country: String?,
    val attachments: List<SuggestDataAttachment>,
) {
    val downloadBytes: Long get() = attachments.sumOf { it.size.toLong() }

    fun label(displayLocale: Locale): String = if (kind == "wikipedia") {
        Locale.forLanguageTag(requireNotNull(language)).getDisplayName(displayLocale)
    } else {
        Locale.Builder().setRegion(requireNotNull(country)).build().getDisplayCountry(displayLocale)
    }
}

internal class SuggestDataCatalog(val datasets: List<SuggestDataSet>) {
    fun preferred(kind: String, browserLocale: Locale): SuggestDataSet? = datasets.firstOrNull {
        it.kind == kind && if (kind == "wikipedia") {
            Locale.forLanguageTag(requireNotNull(it.language)).language == browserLocale.language
        } else {
            it.country == browserLocale.country
        }
    }

    companion object {
        const val ASSET = "firefox-suggest-catalog.json"
        const val SHA256 = "4960be774112710a938ec47bfea0588697dd35de445aea909be675595ae503aa"
        private const val CATALOG_SIZE = 52962
        private const val CDN = "https://firefox-settings-attachments.cdn.mozilla.net/"

        fun parse(bytes: ByteArray): SuggestDataCatalog {
            require(bytes.size == CATALOG_SIZE && digest(bytes) == SHA256) { "Suggest catalog differs from the release pin" }
            val root = JSONObject(bytes.toString(Charsets.UTF_8))
            require(root.getInt("format") == 1)
            val icons = root.getJSONArray("icons")
            val iconRecords = (0 until icons.length()).associate {
                val record = icons.getJSONObject(it)
                record.getString("id") to record
            }
            val rows = root.getJSONArray("datasets")
            val datasets = (0 until rows.length()).map { index ->
                val row = rows.getJSONObject(index)
                val required = mutableListOf(row.getJSONObject("record"))
                val ids = row.getJSONArray("icon_ids")
                for (i in 0 until ids.length()) required += iconRecords.getValue(ids.getString(i))
                val attachments = required.map { record ->
                    val attachment = record.getJSONObject("attachment")
                    val location = attachment.getString("location")
                    require(location.startsWith("main-workspace/quicksuggest-") && !location.contains(".."))
                    SuggestDataAttachment(
                        record.getString("id"), CDN + location, attachment.getInt("size"), attachment.getString("hash"),
                    )
                }
                SuggestDataSet(
                    row.getString("id"), row.getString("collection"), row.getString("kind"),
                    row.optString("language").takeUnless { row.isNull("language") },
                    row.optString("country").takeUnless { row.isNull("country") }, attachments,
                ).also { require(it.downloadBytes == row.getLong("download_bytes")) }
            }
            return SuggestDataCatalog(datasets)
        }

        fun digest(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes)
            .joinToString("") { "%02x".format(it) }
    }
}
