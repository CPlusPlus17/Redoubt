/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.fenix.settings

import mozilla.components.concept.engine.preferences.CrossHostReferrerPolicy
import mozilla.components.concept.engine.preferences.GlobalPrivacyChangeResult
import mozilla.components.concept.engine.preferences.GlobalPrivacyController
import mozilla.components.concept.engine.preferences.GlobalPrivacySaveStatus
import mozilla.components.concept.engine.preferences.GlobalPrivacySetting
import mozilla.components.concept.engine.preferences.GlobalPrivacyState

/** Presentation state only. Values originate in Gecko and are never persisted by Fenix. */
internal data class GlobalPrivacyUiState(
    val native: GlobalPrivacyState? = null,
    val busy: Boolean = false,
    val status: GlobalPrivacySaveStatus? = null,
    val transportError: Boolean = false,
)

/** Keeps an authorized save running across view detach; late callbacks never touch a detached view. */
internal class GlobalPrivacySettingsModel(private val controller: GlobalPrivacyController) {
    var state = GlobalPrivacyUiState()
        private set
    private var listener: ((GlobalPrivacyUiState) -> Unit)? = null

    fun attach(listener: (GlobalPrivacyUiState) -> Unit) {
        this.listener = listener
        listener(state)
    }

    fun detach() { listener = null }

    private fun publish(state: GlobalPrivacyUiState) {
        this.state = state
        listener?.invoke(state)
    }

    fun refresh() {
        if (state.busy) return
        publish(state.copy(busy = true, status = null))
        try {
            controller.read(
                { native -> publish(state.copy(native = native, busy = false, transportError = false)) },
                { publish(state.copy(busy = false, transportError = true)) },
            )
        } catch (_: Exception) {
            publish(state.copy(busy = false, transportError = true))
        }
    }

    fun editable(setting: GlobalPrivacySetting): Boolean {
        val native = state.native ?: return false
        val preference = native.settings[setting] ?: return false
        if (state.busy || state.transportError || preference.locked || preference.value == null) return false
        return setting != GlobalPrivacySetting.WEBGL_HIDE_POPUP ||
            native.settings[GlobalPrivacySetting.WEBGL_PERMISSION_REQUIRED]?.value == 1
    }

    fun displayedBoolean(setting: GlobalPrivacySetting): Boolean? {
        val value = state.native?.settings?.get(setting)?.value ?: return null
        if (!setting.isBoolean || value !in 0..1) return null
        val nativeValue = value == 1
        return if (setting == GlobalPrivacySetting.WEBGL_PERMISSION_REQUIRED ||
            setting == GlobalPrivacySetting.DISABLE_IPV6_DNS) !nativeValue else nativeValue
    }

    fun setDisplayedBoolean(setting: GlobalPrivacySetting, value: Boolean) {
        if (!setting.isBoolean || !editable(setting)) return
        val nativeValue = if (setting == GlobalPrivacySetting.WEBGL_PERMISSION_REQUIRED ||
            setting == GlobalPrivacySetting.DISABLE_IPV6_DNS) !value else value
        change { success, failure -> controller.setBoolean(setting, nativeValue, success, failure) }
    }

    fun setReferrerPolicy(value: Int) {
        if (!editable(GlobalPrivacySetting.REFERRER_HOST_POLICY)) return
        val policy = CrossHostReferrerPolicy.entries.firstOrNull { it.value == value } ?: return
        change { success, failure -> controller.setReferrerPolicy(policy, success, failure) }
    }

    fun reset(setting: GlobalPrivacySetting) {
        if (!editable(setting)) return
        change { success, failure -> controller.reset(setting, success, failure) }
    }

    fun canSaveDisplayed(setting: GlobalPrivacySetting): Boolean = editable(setting) &&
        if (setting.isBoolean) displayedBoolean(setting) != null else
            CrossHostReferrerPolicy.entries.any { it.value == state.native?.settings?.get(setting)?.value }

    fun saveDisplayed(setting: GlobalPrivacySetting) {
        if (!canSaveDisplayed(setting)) return
        if (setting.isBoolean) {
            displayedBoolean(setting)?.let { setDisplayedBoolean(setting, it) }
        } else {
            state.native?.settings?.get(setting)?.value?.let(::setReferrerPolicy)
        }
    }

    private fun change(operation: ((GlobalPrivacyChangeResult) -> Unit, (Throwable) -> Unit) -> Unit) {
        if (state.busy) return
        // Keep the previous native value displayed until Gecko returns its reread.
        publish(state.copy(busy = true, status = null, transportError = false))
        try {
            operation(
                { result -> publish(GlobalPrivacyUiState(native = result.state, status = result.status)) },
                { publish(state.copy(busy = false, transportError = true)) },
            )
        } catch (_: Exception) {
            publish(state.copy(busy = false, transportError = true))
        }
    }
}
