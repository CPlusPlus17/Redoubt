/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package mozilla.components.concept.engine.preferences

import androidx.annotation.MainThread

/** Keys for the five supported native user preferences; no arbitrary-pref write route. */
enum class GlobalPrivacySetting(val id: String, val isBoolean: Boolean = true) {
    RESIST_FINGERPRINTING("rfp"),
    WEBGL_PERMISSION_REQUIRED("webglPrompt"),
    WEBGL_HIDE_POPUP("webglHide"),
    DISABLE_IPV6_DNS("disableIPv6"),
    REFERRER_HOST_POLICY("referrerPolicy", false),
}

/** Additional referrer constraint; scheme, port and other policies are separate. */
enum class CrossHostReferrerPolicy(val value: Int) {
    NO_EXTRA_HOST_CONSTRAINT(0), SAME_BASE_DOMAIN(1), SAME_HOST(2),
}

/** Booleans use0/1. An unfamiliar existing integer remains visible instead of being overwritten. */
data class GlobalPrivacyPreference(
    val value: Int?,
    val defaultValue: Int?,
    val userValue: Int?,
    val locked: Boolean,
    val hasUserValue: Boolean,
    val userValueKnown: Boolean,
    val persistenceUnconfirmed: Boolean,
)

/** Context helps the UI describe scope without changing additional native preferences. */
data class GlobalPrivacyContext(
    val rfpPrivate: Boolean?,
    val fingerprintingProtection: Boolean?,
    val fingerprintingProtectionPrivate: Boolean?,
    val rfpExemptions: Boolean?,
    val fingerprintingOverrides: Boolean?,
    val webglDisabled: Boolean?,
    val referrerTrimming: Int?,
    val dnsOverHttpsMode: Int?,
)

/** A snapshot of memory state is not an assertion that all preferences are saved. */
data class GlobalPrivacyState(
    val settings: Map<GlobalPrivacySetting, GlobalPrivacyPreference>,
    val context: GlobalPrivacyContext,
)

enum class GlobalPrivacySaveStatus { SAVED, REJECTED, UNCONFIRMED, SUPERSEDED }

data class GlobalPrivacyChangeResult(
    val status: GlobalPrivacySaveStatus,
    val reason: String,
    val state: GlobalPrivacyState,
)

/** Reads and mutations serialize in native code. These operations do not own RuntimeSettings defaults. */
@MainThread
interface GlobalPrivacyController {
    fun read(onSuccess: (GlobalPrivacyState) -> Unit, onError: (Throwable) -> Unit)
    fun setBoolean(setting: GlobalPrivacySetting, value: Boolean, onResult: (GlobalPrivacyChangeResult) -> Unit, onError: (Throwable) -> Unit)
    fun setReferrerPolicy(policy: CrossHostReferrerPolicy, onResult: (GlobalPrivacyChangeResult) -> Unit, onError: (Throwable) -> Unit)
    fun reset(setting: GlobalPrivacySetting, onResult: (GlobalPrivacyChangeResult) -> Unit, onError: (Throwable) -> Unit)
}
