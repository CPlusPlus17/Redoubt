/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
package org.mozilla.fenix.settings

import androidx.appcompat.app.AppCompatActivity
import androidx.preference.ListPreference
import androidx.preference.SwitchPreferenceCompat
import io.mockk.every
import mozilla.components.concept.engine.preferences.CrossHostReferrerPolicy
import mozilla.components.concept.engine.preferences.GlobalPrivacyChangeResult
import mozilla.components.concept.engine.preferences.GlobalPrivacyContext
import mozilla.components.concept.engine.preferences.GlobalPrivacyController
import mozilla.components.concept.engine.preferences.GlobalPrivacyPreference
import mozilla.components.concept.engine.preferences.GlobalPrivacySaveStatus
import mozilla.components.concept.engine.preferences.GlobalPrivacySetting
import mozilla.components.concept.engine.preferences.GlobalPrivacyState
import mozilla.components.support.test.robolectric.testContext
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.mozilla.fenix.ext.components
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class GlobalPrivacySettingsModelTest {
    private class Controller : GlobalPrivacyController {
        val calls = mutableListOf<Pair<GlobalPrivacySetting, Any?>>()
        var readSuccess: ((GlobalPrivacyState) -> Unit)? = null
        var result: ((GlobalPrivacyChangeResult) -> Unit)? = null
        var error: ((Throwable) -> Unit)? = null
        override fun read(onSuccess: (GlobalPrivacyState) -> Unit, onError: (Throwable) -> Unit) { readSuccess = onSuccess; error = onError }
        override fun setBoolean(setting: GlobalPrivacySetting, value: Boolean, onResult: (GlobalPrivacyChangeResult) -> Unit, onError: (Throwable) -> Unit) {
            calls += setting to value; result = onResult; error = onError
        }
        override fun setReferrerPolicy(policy: CrossHostReferrerPolicy, onResult: (GlobalPrivacyChangeResult) -> Unit, onError: (Throwable) -> Unit) {
            calls += GlobalPrivacySetting.REFERRER_HOST_POLICY to policy; result = onResult; error = onError
        }
        override fun reset(setting: GlobalPrivacySetting, onResult: (GlobalPrivacyChangeResult) -> Unit, onError: (Throwable) -> Unit) { calls += setting to null; result = onResult; error = onError }
    }

    private fun snapshot() = GlobalPrivacyState(
        GlobalPrivacySetting.entries.associateWith { key ->
            val value = if (key == GlobalPrivacySetting.DISABLE_IPV6_DNS) 0 else 1
            GlobalPrivacyPreference(value, value, null, false, false, true, false)
        }, GlobalPrivacyContext(false, true, false, false, false, false, 2, 2),
    )
    private fun GlobalPrivacyState.with(setting: GlobalPrivacySetting, update: (GlobalPrivacyPreference) -> GlobalPrivacyPreference) =
        copy(settings = settings + (setting to update(settings.getValue(setting))))
    private fun loaded(controller: Controller, native: GlobalPrivacyState = snapshot()) = GlobalPrivacySettingsModel(controller).also {
        it.refresh(); controller.readSuccess!!(native)
    }

    @Test fun `native defaults and referrer middle value are preserved with both inversions`() {
        val controller = Controller(); val model = loaded(controller)
        assertEquals(false, model.displayedBoolean(GlobalPrivacySetting.WEBGL_PERMISSION_REQUIRED))
        assertEquals(true, model.displayedBoolean(GlobalPrivacySetting.DISABLE_IPV6_DNS))
        assertEquals(1, model.state.native!!.settings.getValue(GlobalPrivacySetting.REFERRER_HOST_POLICY).value)
        assertTrue(controller.calls.isEmpty())
    }

    @Test fun `always allow waits for actual native acknowledgment and writes inverse`() {
        val controller = Controller(); val model = loaded(controller)
        model.setDisplayedBoolean(GlobalPrivacySetting.WEBGL_PERMISSION_REQUIRED, true)
        assertEquals(GlobalPrivacySetting.WEBGL_PERMISSION_REQUIRED to false, controller.calls.single())
        assertTrue(model.state.busy); assertEquals(false, model.displayedBoolean(GlobalPrivacySetting.WEBGL_PERMISSION_REQUIRED))
        controller.result!!(GlobalPrivacyChangeResult(GlobalPrivacySaveStatus.SAVED, "", snapshot().with(GlobalPrivacySetting.WEBGL_PERMISSION_REQUIRED) { it.copy(value = 0, userValue = 0, hasUserValue = true) }))
        assertEquals(true, model.displayedBoolean(GlobalPrivacySetting.WEBGL_PERMISSION_REQUIRED)); assertFalse(model.state.busy)
    }

    @Test fun `disable IPv6 in the UI sets native DNS disable true`() {
        val controller = Controller(); val model = loaded(controller)
        model.setDisplayedBoolean(GlobalPrivacySetting.DISABLE_IPV6_DNS, false)
        assertEquals(GlobalPrivacySetting.DISABLE_IPV6_DNS to true, controller.calls.single())
    }

    @Test fun `locks and hidden user value never permit a change or reset`() {
        val controller = Controller(); val model = loaded(controller, snapshot().with(GlobalPrivacySetting.RESIST_FINGERPRINTING) {
            it.copy(locked = true, hasUserValue = true, userValueKnown = false)
        })
        model.setDisplayedBoolean(GlobalPrivacySetting.RESIST_FINGERPRINTING, false); model.reset(GlobalPrivacySetting.RESIST_FINGERPRINTING)
        assertFalse(model.editable(GlobalPrivacySetting.RESIST_FINGERPRINTING)); assertTrue(controller.calls.isEmpty())
    }

    @Test fun `quiet control is unavailable during bypass without replacing its stored choice`() {
        val controller = Controller(); val native = snapshot().with(GlobalPrivacySetting.WEBGL_PERMISSION_REQUIRED) { it.copy(value = 0) }
            .with(GlobalPrivacySetting.WEBGL_HIDE_POPUP) { it.copy(value = 0, hasUserValue = true) }
        val model = loaded(controller, native); model.setDisplayedBoolean(GlobalPrivacySetting.WEBGL_HIDE_POPUP, true)
        assertFalse(model.editable(GlobalPrivacySetting.WEBGL_HIDE_POPUP)); assertTrue(controller.calls.isEmpty())
        assertEquals(false, model.displayedBoolean(GlobalPrivacySetting.WEBGL_HIDE_POPUP))
    }

    @Test fun `busy state blocks a second user operation until the first result`() {
        val controller = Controller(); val model = loaded(controller)
        model.setDisplayedBoolean(GlobalPrivacySetting.RESIST_FINGERPRINTING, false)
        model.reset(GlobalPrivacySetting.DISABLE_IPV6_DNS); model.setReferrerPolicy(2)
        assertEquals(1, controller.calls.size)
    }

    @Test fun `save failure displays changed native memory and retains unconfirmed state`() {
        val controller = Controller(); val model = loaded(controller)
        model.setDisplayedBoolean(GlobalPrivacySetting.RESIST_FINGERPRINTING, false)
        val changed = snapshot().with(GlobalPrivacySetting.RESIST_FINGERPRINTING) { it.copy(value = 0, userValue = 0, hasUserValue = true, persistenceUnconfirmed = true) }
        controller.result!!(GlobalPrivacyChangeResult(GlobalPrivacySaveStatus.UNCONFIRMED, "save-failed", changed))
        assertEquals(false, model.displayedBoolean(GlobalPrivacySetting.RESIST_FINGERPRINTING))
        assertEquals(GlobalPrivacySaveStatus.UNCONFIRMED, model.state.status)
        model.refresh(); controller.readSuccess!!(changed)
        assertNull(model.state.status) // A reread cannot claim the previous save status for later state.
        assertTrue(model.state.native!!.settings.getValue(GlobalPrivacySetting.RESIST_FINGERPRINTING).persistenceUnconfirmed)
    }

    @Test fun `transport failure disables stale controls until a successful reread`() {
        val controller = Controller(); val model = loaded(controller)
        model.setDisplayedBoolean(GlobalPrivacySetting.RESIST_FINGERPRINTING, false); controller.error!!(IllegalStateException("response lost"))
        assertFalse(model.editable(GlobalPrivacySetting.RESIST_FINGERPRINTING)); assertTrue(model.state.transportError)
        model.refresh(); controller.readSuccess!!(snapshot()); assertTrue(model.editable(GlobalPrivacySetting.RESIST_FINGERPRINTING))
    }

    @Test fun `detached view is not called while authorized save still completes`() {
        val controller = Controller(); val model = loaded(controller); var rendered = 0
        model.attach { rendered++ }; model.setReferrerPolicy(2); model.detach(); val prior = rendered
        controller.result!!(GlobalPrivacyChangeResult(GlobalPrivacySaveStatus.SAVED, "", snapshot().with(GlobalPrivacySetting.REFERRER_HOST_POLICY) { it.copy(value = 2, hasUserValue = true) }))
        assertEquals(prior, rendered); assertFalse(model.state.busy)
        model.attach { rendered++ }; assertEquals(prior + 1, rendered)
        assertEquals(2, model.state.native!!.settings.getValue(GlobalPrivacySetting.REFERRER_HOST_POLICY).value)
    }

    @Test fun `reset delegates clearing user state and accepts the actual native default`() {
        val controller = Controller(); val model = loaded(controller)
        model.reset(GlobalPrivacySetting.REFERRER_HOST_POLICY)
        assertEquals(GlobalPrivacySetting.REFERRER_HOST_POLICY to null, controller.calls.single())
        val resetState = snapshot().with(GlobalPrivacySetting.REFERRER_HOST_POLICY) { it.copy(value = 2, defaultValue = 2, hasUserValue = false) }
        controller.result!!(GlobalPrivacyChangeResult(GlobalPrivacySaveStatus.SAVED, "", resetState))
        assertEquals(2, model.state.native!!.settings.getValue(GlobalPrivacySetting.REFERRER_HOST_POLICY).value)
    }

    @Test fun `actual nonpersistent switch listener waits for authoritative inverse result`() {
        val controller = Controller(); every { testContext.components.core.engine.globalPrivacyController } returns controller
        val activity = Robolectric.buildActivity(AppCompatActivity::class.java).create().get()
        val fragment = GlobalPrivacySettingsFragment()
        activity.supportFragmentManager.beginTransaction().add(fragment, "privacy").commitNow()
        fragment.onResume(); controller.readSuccess!!(snapshot())
        val preference = requireNotNull(fragment.findPreference<SwitchPreferenceCompat>("webglPrompt"))
        assertFalse(preference.isPersistent); assertFalse(preference.isChecked)
        assertFalse(preference.callChangeListener(true)); assertFalse(preference.isChecked)
        assertEquals(GlobalPrivacySetting.WEBGL_PERMISSION_REQUIRED to false, controller.calls.single())
        controller.result!!(GlobalPrivacyChangeResult(GlobalPrivacySaveStatus.SAVED, "", snapshot().with(GlobalPrivacySetting.WEBGL_PERMISSION_REQUIRED) { it.copy(value = 0, hasUserValue = true) }))
        assertTrue(preference.isChecked); fragment.onPause()
    }

    @Test fun `actual referrer list preserves one and shows locked native value without persistence`() {
        val controller = Controller(); every { testContext.components.core.engine.globalPrivacyController } returns controller
        val activity = Robolectric.buildActivity(AppCompatActivity::class.java).create().get()
        val fragment = GlobalPrivacySettingsFragment()
        activity.supportFragmentManager.beginTransaction().add(fragment, "privacy").commitNow()
        fragment.onResume(); controller.readSuccess!!(snapshot().with(GlobalPrivacySetting.REFERRER_HOST_POLICY) { it.copy(locked = true, hasUserValue = true, userValueKnown = false) })
        val preference = requireNotNull(fragment.findPreference<ListPreference>("referrerPolicy"))
        assertEquals("1", preference.value); assertFalse(preference.isPersistent); assertFalse(preference.isEnabled)
        assertFalse(preference.callChangeListener("2")); assertTrue(controller.calls.isEmpty()); fragment.onPause()
    }
    @Test fun `unsupported existing referrer integer is visible and resettable but cannot be resaved`() {
        val controller = Controller()
        val setting = GlobalPrivacySetting.REFERRER_HOST_POLICY
        val model = loaded(controller, snapshot().with(setting) { it.copy(value = 99, hasUserValue = true) })
        assertEquals(99, model.state.native!!.settings.getValue(setting).value)
        assertTrue(model.editable(setting)); assertFalse(model.canSaveDisplayed(setting))
        model.saveDisplayed(setting); assertTrue(controller.calls.isEmpty())
        model.reset(setting); assertEquals(setting to null, controller.calls.single())
    }

}
