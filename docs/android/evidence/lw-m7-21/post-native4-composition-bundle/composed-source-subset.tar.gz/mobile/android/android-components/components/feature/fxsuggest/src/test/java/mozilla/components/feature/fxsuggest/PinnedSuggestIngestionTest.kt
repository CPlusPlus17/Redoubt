/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
package mozilla.components.feature.fxsuggest

import androidx.test.ext.junit.runners.AndroidJUnit4
import io.mockk.every
import io.mockk.mockk
import io.mockk.spyk
import io.mockk.verify
import kotlinx.coroutines.runBlocking
import mozilla.appservices.suggest.SuggestStore
import mozilla.appservices.suggest.SuggestionProvider
import mozilla.components.support.test.robolectric.testContext
import org.junit.After
import org.junit.Assert.assertFalse
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class PinnedSuggestIngestionTest {
    private val providers = listOf(SuggestionProvider.AMP, SuggestionProvider.WIKIPEDIA)
    @After fun restore() { FxSuggestAdmission.configure { FxSuggestChoices() } }

    @Test
    fun `configured provider set reaches startup and periodic native ingestion`() = runBlocking {
        FxSuggestAdmission.configure { FxSuggestChoices() }
        val native = mockk<SuggestStore>(relaxed = true)
        val storage = spyk(FxSuggestStorage(testContext, mockk(), defaultIngestionProviders = providers))
        every { storage.store } returns lazy { native }
        storage.runStartupIngestion()
        storage.ingest()
        verify { native.ingest(match { it.providers == providers && it.emptyOnly }) }
        verify { native.ingest(match { it.providers == providers && !it.emptyOnly }) }
    }

    @Test
    fun `an off restored storage reference does not initialize the native store`() = runBlocking {
        FxSuggestAdmission.configure { FxSuggestChoices(false, false, false, false) }
        val storage = FxSuggestStorage(testContext, mockk(), defaultIngestionProviders = providers)
        storage.runStartupIngestion()
        storage.ingest()
        assertFalse(storage.store.isInitialized())
    }

    @Test
    fun `other embedders retain their unspecified provider default`() = runBlocking {
        FxSuggestAdmission.configure { FxSuggestChoices() }
        val native = mockk<SuggestStore>(relaxed = true)
        val storage = spyk(FxSuggestStorage(testContext, mockk()))
        every { storage.store } returns lazy { native }
        storage.ingest()
        verify { native.ingest(match { it.providers == null }) }
    }
}
