/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.fenix.settings.search

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import mozilla.components.concept.fetch.Client
import mozilla.components.concept.fetch.Request
import mozilla.components.concept.fetch.Response
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

/** An attempt owns one native cancellation token; tests can supply a native-free backend. */
internal interface SuggestDataImport {
    fun install(dataset: SuggestDataSet, attachments: List<Pair<String, ByteArray>>)
    fun cancel(): Boolean
}

/** Only an explicit UI Download action calls this class. No worker uses it. */
internal class SuggestDataInstaller(
    private val clientFactory: () -> Client,
    private val importFactory: (SuggestDataSet) -> SuggestDataImport,
    private val isAllowed: () -> Boolean,
) {
    private class Attempt {
        @Volatile var cancelled = false
        @Volatile var importer: SuggestDataImport? = null
        @Volatile var response: Response? = null
    }

    @Volatile private var active: Attempt? = null

    /** A false result means native publication already began; no rollback is promised. */
    fun cancel(): Boolean {
        val attempt = active ?: return true
        attempt.cancelled = true
        // A failed stream close must not prevent native cancellation.
        runCatching { attempt.response?.close() }
        return attempt.importer?.cancel() ?: true
    }

    suspend fun install(dataset: SuggestDataSet) = withContext(Dispatchers.IO) {
        val attempt = Attempt()
        synchronized(this@SuggestDataInstaller) {
            check(active == null) { "A Suggest install is already running" }
            if (!isAllowed()) throw CancellationException("Suggest data installation is disabled")
            active = attempt
        }
        fun checkAdmission() {
            if (attempt.cancelled || !isAllowed()) throw CancellationException("Suggest data installation stopped")
        }
        try {
            currentCoroutineContext().ensureActive()
            checkAdmission()
            val importer = importFactory(dataset)
            attempt.importer = importer
            checkAdmission()
            val client = clientFactory()
            val attachments = mutableListOf<Pair<String, ByteArray>>()
            for (attachment in dataset.attachments) {
                currentCoroutineContext().ensureActive()
                checkAdmission()
                val request = Request(
                    url = attachment.url,
                    redirect = Request.Redirect.MANUAL,
                    cookiePolicy = Request.CookiePolicy.OMIT,
                    useCaches = false,
                    connectTimeout = 15L to TimeUnit.SECONDS,
                    readTimeout = 30L to TimeUnit.SECONDS,
                )
                client.fetch(request).use { response ->
                    attempt.response = response
                    currentCoroutineContext().ensureActive()
                    checkAdmission()
                    if (response.status != 200 || response.url != attachment.url) throw IOException("Unexpected Suggest download response")
                    val bytes = response.body.useStream { stream ->
                        val output = ByteArrayOutputStream(attachment.size)
                        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                        while (true) {
                            checkAdmission()
                            val count = stream.read(buffer)
                            if (count < 0) break
                            if (output.size().toLong() + count > attachment.size) throw IOException("Suggest download is larger than its pin")
                            output.write(buffer, 0, count)
                        }
                        output.toByteArray()
                    }
                    if (bytes.size != attachment.size || SuggestDataCatalog.digest(bytes) != attachment.sha256) {
                        throw IOException("Suggest download does not match its pin")
                    }
                    attachments += attachment.recordId to bytes
                    attempt.response = null
                }
            }
            currentCoroutineContext().ensureActive()
            checkAdmission()
            importer.install(dataset, attachments)
        } finally {
            runCatching { attempt.response?.close() }
            try {
                attempt.importer?.cancel()
            } finally {
                synchronized(this@SuggestDataInstaller) { if (active === attempt) active = null }
            }
        }
    }
}
