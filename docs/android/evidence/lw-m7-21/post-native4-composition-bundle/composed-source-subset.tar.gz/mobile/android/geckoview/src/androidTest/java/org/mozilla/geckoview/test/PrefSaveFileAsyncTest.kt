/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

package org.mozilla.geckoview.test

import android.util.Log
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.MediumTest
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

// Uses RuntimeCreator's normal XRE_main profile. Xpcshell, even Android
// xpcshell, cannot cover mCurrentFile because it enters XRE_XPCShellMain.
@RunWith(AndroidJUnit4::class)
@MediumTest
class PrefSaveFileAsyncTest : BaseSessionTest() {
    private fun receipt(scenario: String): JSONObject {
        val value = sessionRule.evaluateExtensionJS(
            "return JSON.stringify(await browser.test.runPrefSaveFileAsyncIOTest('$scenario', false));",
        ) as String
        Log.i("PrefSaveFileAsyncTest", value)
        return JSONObject(value).also {
            assertEquals(scenario, it.getString("scenario"))
            assertEquals(it.getString("profile") + "/prefs.js", it.getString("currentFile"))
        }
    }

    @Test
    fun currentAndBackupSnapshotsHaveIndependentOutcomes() {
        val result = receipt("snapshots")
        for (name in listOf("first", "backupA", "backupB", "final")) {
            assertTrue("$name completed", result.getJSONObject(name).getBoolean("resolved"))
        }
        assertFalse(result.getJSONObject("failed").getBoolean("resolved"))
        assertTrue(result.getJSONObject("failed").getJSONObject("error").getString("message").isNotEmpty())
        assertEquals("backup-a", result.getString("backupAValue"))
        assertEquals("backup-b", result.getString("backupBValue"))
        assertEquals("final-current", result.getString("currentValue"))
        assertTrue(result.getBoolean("failedTargetIsDirectory"))
    }

    @Test
    fun cleanStateBarrierRecreatesCurrentFileAndPersistsReset() {
        val result = receipt("clean")
        assertFalse(result.getBoolean("dirtyBeforeRemoval"))
        assertFalse(result.getBoolean("dirtyAfterRemoval"))
        assertTrue(result.getBoolean("fileAbsentBeforeBarrier"))
        assertEquals("clean-state", result.getString("recreatedValue"))
        assertTrue("Reset removed the user value from saved bytes", result.isNull("resetValue"))
    }

    @Test
    fun actualCurrentFileFailureRejectsSuspendAndRetries() {
        val result = receipt("failure")
        for (name in listOf("failedSave", "failedSuspend")) {
            assertFalse("$name reports I/O failure", result.getJSONObject(name).getBoolean("resolved"))
            assertTrue(result.getJSONObject(name).getJSONObject("error").getString("message").isNotEmpty())
        }
        assertTrue(result.getBoolean("failureTargetIsDirectory"))
        assertEquals("after-disk-error", result.getString("memoryValueAfterFailure"))
        assertTrue(result.getJSONObject("retry").getBoolean("resolved"))
        assertEquals("after-disk-error", result.getString("retryValue"))
        assertFalse(result.getBoolean("dirtyAfterRetry"))
    }
}
