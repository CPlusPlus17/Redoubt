/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.geckoview;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.UiThread;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.mozilla.gecko.EventDispatcher;
import org.mozilla.gecko.util.GeckoBundle;
import org.mozilla.gecko.util.ThreadUtils;

/** Authoritative, durable user controls for five global privacy preferences. */
public final class GeckoGlobalPrivacyController {
  /** ResistFingerprinting. */
  public static final String RFP = "rfp";
  /** Require WebGL permission; false means always allow. */
  public static final String WEBGL_PROMPT = "webglPrompt";
  /** Keep WebGL permission enforcement quiet. */
  public static final String WEBGL_HIDE = "webglHide";
  /** Restrict DNS lookups to IPv4; false permits IPv6 DNS results. */
  public static final String DISABLE_IPV6 = "disableIPv6";
  /** Additional referrer host constraint: 0 unrestricted, 1 base domain, 2 host. */
  public static final String REFERRER_POLICY = "referrerPolicy";

  private static final Set<String> IDS = Collections.unmodifiableSet(
      new HashSet<>(Arrays.asList(RFP, WEBGL_PROMPT, WEBGL_HIDE, DISABLE_IPV6, REFERRER_POLICY)));
  private static final String EVENT = "GeckoView:GlobalPrivacy:Operation";

  private GeckoGlobalPrivacyController() {}

  /** State is reread from Gecko; reading does not persist or change preferences. */
  @UiThread
  public static @NonNull GeckoResult<State> getState() {
    final GeckoBundle request = new GeckoBundle(1);
    request.putString("action", "get");
    return query(request).map(State::new);
  }

  /**
   * Change one of the four boolean controls. An acknowledgment reports actual
   * disk completion separately from effective memory state. Existing documents,
   * connections and WebGL contexts may require reload or recreation.
   *
   * @param id One of RFP, WEBGL_PROMPT, WEBGL_HIDE, DISABLE_IPV6.
   * @param value Native preference value; inverse UI labels invert this value.
   * @return Refreshed native state and explicit persistence status.
   */
  @UiThread
  public static @NonNull GeckoResult<ChangeResult> setBoolean(
      @NonNull final String id, final boolean value) {
    if (!IDS.contains(id) || REFERRER_POLICY.equals(id)) {
      throw new IllegalArgumentException("Not an allowlisted boolean control");
    }
    final GeckoBundle request = operation("set", id);
    request.putBoolean("value", value);
    return query(request).map(ChangeResult::new);
  }

  /**
   * Set the additional cross-host referrer constraint. Mode 2 compares ASCII host,
   * not scheme or port. Other referrer policies may impose stricter restrictions.
   * @param value 0 (no additional host constraint), 1 (same base domain), or 2 (same host).
   * @return Refreshed native state and explicit persistence status.
   */
  @UiThread
  public static @NonNull GeckoResult<ChangeResult> setReferrerPolicy(final int value) {
    if (value < 0 || value > 2) throw new IllegalArgumentException("Referrer policy must be 0, 1 or 2");
    final GeckoBundle request = operation("set", REFERRER_POLICY);
    request.putInt("value", value);
    return query(request).map(ChangeResult::new);
  }

  /** Clear only this setting's user branch and await the current-profile save result. */
  @UiThread
  public static @NonNull GeckoResult<ChangeResult> reset(@NonNull final String id) {
    if (!IDS.contains(id)) throw new IllegalArgumentException("Not an allowlisted control");
    return query(operation("reset", id)).map(ChangeResult::new);
  }

  private static GeckoBundle operation(final String action, final String id) {
    final GeckoBundle request = new GeckoBundle(3);
    request.putString("action", action);
    request.putString("id", id);
    return request;
  }

  private static GeckoResult<GeckoBundle> query(final GeckoBundle request) {
    ThreadUtils.assertOnUiThread();
    return EventDispatcher.getInstance().queryBundle(EVENT, request).map(result -> {
      if (result == null) throw new IllegalStateException("Missing global privacy response");
      return result;
    });
  }

  /** Native state for one setting. Boolean values use 0/1; referrer values are integers. */
  public static final class PreferenceState {
    public final @NonNull String id;
    /** True only when Gecko's actual pref type matches this control. */
    public final boolean available;
    public final boolean locked;
    public final boolean hasUserValue;
    /** False when a lock hides a stored user value; no temporary unlock is performed. */
    public final boolean userValueKnown;
    /** This controller has an earlier write whose current value has not been confirmed saved. */
    public final boolean persistenceUnconfirmed;
    public final @Nullable Integer value;
    public final @Nullable Integer defaultValue;
    public final @Nullable Integer userValue;

    private PreferenceState(final GeckoBundle data) {
      id = data.getString("id");
      if (id == null || !IDS.contains(id)) throw new IllegalStateException("Unknown native control");
      final String expectedType = REFERRER_POLICY.equals(id) ? "int" : "bool";
      if (!expectedType.equals(data.getString("type"))) throw new IllegalStateException("Wrong native control type");
      available = data.getBoolean("available");
      locked = data.getBoolean("locked");
      hasUserValue = data.getBoolean("hasUser");
      userValueKnown = data.getBoolean("userValueKnown");
      persistenceUnconfirmed = data.getBoolean("persistenceUnconfirmed");
      value = nullableInt(data, "value");
      defaultValue = nullableInt(data, "defaultValue");
      userValue = nullableInt(data, "userValue");
    }
  }

  /** Read-only surrounding settings; these are not writable through this controller. */
  public static final class Context {
    public final @Nullable Boolean rfpPrivate;
    public final @Nullable Boolean fingerprintingProtection;
    public final @Nullable Boolean fingerprintingProtectionPrivate;
    public final @Nullable Boolean rfpExemptions;
    public final @Nullable Boolean fingerprintingOverrides;
    public final @Nullable Boolean webglDisabled;
    public final @Nullable Integer referrerTrimming;
    public final @Nullable Integer dnsOverHttpsMode;

    private Context(final GeckoBundle data) {
      rfpPrivate = nullableBoolean(data, "rfpPrivate");
      fingerprintingProtection = nullableBoolean(data, "fingerprintingProtection");
      fingerprintingProtectionPrivate = nullableBoolean(data, "fingerprintingProtectionPrivate");
      rfpExemptions = nullableBoolean(data, "rfpExemptions");
      fingerprintingOverrides = nullableBoolean(data, "fingerprintingOverrides");
      webglDisabled = nullableBoolean(data, "webglDisabled");
      referrerTrimming = nullableInt(data, "referrerTrimming");
      dnsOverHttpsMode = nullableInt(data, "dnsOverHttpsMode");
    }
  }

  /** Complete current native state; this object alone makes no disk-durability claim. */
  public static final class State {
    public final @NonNull List<PreferenceState> settings;
    public final @NonNull Context context;

    private State(final GeckoBundle data) {
      final GeckoBundle[] entries = data.getBundleArray("settings");
      final GeckoBundle contextBundle = data.getBundle("context");
      if (entries == null || entries.length != IDS.size() || contextBundle == null) {
        throw new IllegalStateException("Incomplete global privacy state");
      }
      final List<PreferenceState> result = new ArrayList<>();
      final Set<String> seen = new HashSet<>();
      for (final GeckoBundle entry : entries) {
        final PreferenceState pref = new PreferenceState(entry);
        if (!seen.add(pref.id)) throw new IllegalStateException("Duplicate native control");
        result.add(pref);
      }
      settings = Collections.unmodifiableList(result);
      context = new Context(contextBundle);
    }
  }

  /** Persistence result for one operation. A failed save does not promise rollback. */
  public static final class ChangeResult {
    /** Saved snapshot still matches this setting's reread state. */
    public static final int SAVED = 0;
    /** Validation or preflight failed before this operation mutated the setting. */
    public static final int REJECTED = 1;
    /** Mutation/write failed; displayed memory state is authoritative, disk state is unconfirmed. */
    public static final int UNCONFIRMED = 2;
    /** Snapshot was saved, but an independent change superseded this operation. */
    public static final int SUPERSEDED = 3;
    public final int status;
    public final @NonNull String reason;
    public final @NonNull State state;

    private ChangeResult(final GeckoBundle data) {
      final String result = data.getString("status", "");
      switch (result) {
        case "saved": status = SAVED; break;
        case "rejected": status = REJECTED; break;
        case "unconfirmed": status = UNCONFIRMED; break;
        case "superseded": status = SUPERSEDED; break;
        default: throw new IllegalStateException("Unknown persistence status");
      }
      reason = data.getString("reason", "");
      final GeckoBundle stateBundle = data.getBundle("state");
      if (stateBundle == null) throw new IllegalStateException("Missing native state after change");
      state = new State(stateBundle);
    }
  }

  private static Integer nullableInt(final GeckoBundle data, final String key) {
    return data.get(key) == null ? null : data.getInt(key);
  }

  private static Boolean nullableBoolean(final GeckoBundle data, final String key) {
    return data.get(key) == null ? null : data.getBoolean(key);
  }
}
