/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.fenix.settings

import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.preference.ListPreference
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.SwitchPreferenceCompat
import mozilla.components.concept.engine.preferences.GlobalPrivacySaveStatus
import mozilla.components.concept.engine.preferences.GlobalPrivacySetting
import org.mozilla.fenix.R
import org.mozilla.fenix.e2e.SystemInsetsPaddedFragment
import org.mozilla.fenix.ext.components
import org.mozilla.fenix.ext.showToolbar

/** Native-backed global controls; every Preference explicitly opts out of local persistence. */
class GlobalPrivacySettingsFragment : PreferenceFragmentCompat(), SystemInsetsPaddedFragment {
    private var model: GlobalPrivacySettingsModel? = null
    private val switches = mutableMapOf<GlobalPrivacySetting, SwitchPreferenceCompat>()
    private lateinit var policy: ListPreference
    private lateinit var status: Preference
    private lateinit var reset: Preference
    private lateinit var retry: Preference
    private lateinit var contextInfo: Preference
    private var wasBusy = false

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.global_privacy_settings, rootKey)
        val controller = requireContext().components.core.engine.globalPrivacyController
        model = controller?.let(::GlobalPrivacySettingsModel)
        GlobalPrivacySetting.entries.filter { it.isBoolean }.forEach { setting ->
            val preference = requireNotNull(findPreference<SwitchPreferenceCompat>(setting.id))
            switches[setting] = preference
            preference.onPreferenceChangeListener = Preference.OnPreferenceChangeListener { _, value ->
                (value as? Boolean)?.let { model?.setDisplayedBoolean(setting, it) }
                false // The widget changes only after an authoritative native reread.
            }
        }
        policy = requireNotNull(findPreference(GlobalPrivacySetting.REFERRER_HOST_POLICY.id))
        policy.onPreferenceChangeListener = Preference.OnPreferenceChangeListener { _, value ->
            (value as? String)?.toIntOrNull()?.let { model?.setReferrerPolicy(it) }
            false
        }
        status = requireNotNull(findPreference("global_privacy_status"))
        contextInfo = requireNotNull(findPreference("global_privacy_context"))
        reset = requireNotNull(findPreference("global_privacy_reset"))
        retry = requireNotNull(findPreference("global_privacy_retry"))
        reset.setOnPreferenceClickListener { chooseSetting(reset = true); true }
        retry.setOnPreferenceClickListener { chooseSetting(reset = false); true }
        status.setOnPreferenceClickListener { model?.refresh(); true }
        render(GlobalPrivacyUiState(transportError = controller == null))
    }

    override fun onResume() {
        super.onResume()
        showToolbar(getString(R.string.global_privacy_title))
        model?.attach(::render)
        model?.refresh()
    }

    override fun onPause() {
        model?.detach()
        super.onPause()
    }

    override fun onDestroyView() {
        model?.detach()
        super.onDestroyView()
    }

    private fun title(setting: GlobalPrivacySetting): CharSequence =
        requireNotNull(if (setting.isBoolean) requireNotNull(switches[setting]).title else policy.title)

    private fun chooseSetting(reset: Boolean) {
        val current = model ?: return
        val available = GlobalPrivacySetting.entries.filter { setting ->
            if (reset) current.editable(setting) && current.state.native?.settings?.get(setting)?.hasUserValue == true
            else current.canSaveDisplayed(setting)
        }
        if (available.isEmpty()) return
        AlertDialog.Builder(requireContext())
            .setTitle(if (reset) R.string.global_privacy_reset else R.string.global_privacy_retry)
            .setItems(available.map(::title).toTypedArray()) { _, index ->
                // Revalidate the current model when a dialog outlives a lock or write.
                if (reset) current.reset(available[index]) else current.saveDisplayed(available[index])
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun render(state: GlobalPrivacyUiState) {
        val current = model
        if (wasBusy && !state.busy && view != null &&
            (state.transportError || state.status in setOf(GlobalPrivacySaveStatus.REJECTED, GlobalPrivacySaveStatus.UNCONFIRMED, GlobalPrivacySaveStatus.SUPERSEDED))) {
            val message = when {
                state.transportError -> R.string.global_privacy_transport_error
                state.status == GlobalPrivacySaveStatus.REJECTED -> R.string.global_privacy_rejected
                state.status == GlobalPrivacySaveStatus.SUPERSEDED -> R.string.global_privacy_superseded
                else -> R.string.global_privacy_unconfirmed
            }
            AlertDialog.Builder(requireContext()).setMessage(message).setPositiveButton(android.R.string.ok, null).show()
        }
        wasBusy = state.busy
        switches.forEach { (setting, preference) ->
            preference.isEnabled = current?.editable(setting) == true
            preference.isChecked = current?.displayedBoolean(setting) == true
            preference.summary = summary(setting, state)
        }
        val nativePolicy = state.native?.settings?.get(GlobalPrivacySetting.REFERRER_HOST_POLICY)?.value
        policy.value = nativePolicy?.toString()
        policy.isEnabled = current?.editable(GlobalPrivacySetting.REFERRER_HOST_POLICY) == true
        policy.summary = summary(GlobalPrivacySetting.REFERRER_HOST_POLICY, state)
        reset.isEnabled = !state.busy && state.native?.settings?.any { (key, value) -> current?.editable(key) == true && value.hasUserValue } == true
        retry.isEnabled = !state.busy && GlobalPrivacySetting.entries.any { current?.canSaveDisplayed(it) == true }
        status.isEnabled = !state.busy
        status.setSummary(when {
            state.busy -> R.string.global_privacy_busy
            state.transportError -> R.string.global_privacy_transport_error
            state.native?.settings?.values?.any { it.persistenceUnconfirmed } == true -> R.string.global_privacy_unconfirmed
            state.status == GlobalPrivacySaveStatus.UNCONFIRMED -> R.string.global_privacy_unconfirmed
            state.status == GlobalPrivacySaveStatus.REJECTED -> R.string.global_privacy_rejected
            state.status == GlobalPrivacySaveStatus.SUPERSEDED -> R.string.global_privacy_superseded
            state.status == GlobalPrivacySaveStatus.SAVED -> R.string.global_privacy_saved
            else -> R.string.global_privacy_current
        })
        val context = state.native?.context
        val globalRfp = state.native?.settings?.get(GlobalPrivacySetting.RESIST_FINGERPRINTING)?.value
        val privateRfp = if (globalRfp == 1) true else if (globalRfp == 0) context?.rfpPrivate else null
        val privateFpp = when {
            context?.fingerprintingProtection == true || context?.fingerprintingProtectionPrivate == true -> true
            context?.fingerprintingProtection == false && context?.fingerprintingProtectionPrivate == false -> false
            else -> null
        }
        contextInfo.summary = getString(
            R.string.global_privacy_context_summary,
            booleanLabel(privateRfp), booleanLabel(context?.fingerprintingProtection),
            booleanLabel(privateFpp), booleanLabel(context?.rfpExemptions),
            booleanLabel(context?.fingerprintingOverrides), booleanLabel(context?.webglDisabled),
        )
    }

    private fun booleanLabel(value: Boolean?) = getString(when (value) {
        true -> R.string.global_privacy_on
        false -> R.string.global_privacy_off
        null -> R.string.global_privacy_unknown
    })

    private fun valueLabel(setting: GlobalPrivacySetting, value: Int?): String {
        if (value == null) return getString(R.string.global_privacy_unknown)
        if (!setting.isBoolean) return resources.getStringArray(R.array.global_privacy_referrer_entries).getOrNull(value)
            ?: getString(R.string.global_privacy_custom_value, value)
        val displayed = if (setting == GlobalPrivacySetting.WEBGL_PERMISSION_REQUIRED || setting == GlobalPrivacySetting.DISABLE_IPV6_DNS) value == 0 else value == 1
        return booleanLabel(displayed)
    }

    private fun summary(setting: GlobalPrivacySetting, state: GlobalPrivacyUiState): String {
        val description = getString(when (setting) {
            GlobalPrivacySetting.RESIST_FINGERPRINTING -> R.string.global_privacy_rfp_summary
            GlobalPrivacySetting.WEBGL_PERMISSION_REQUIRED -> R.string.global_privacy_webgl_summary
            GlobalPrivacySetting.WEBGL_HIDE_POPUP -> R.string.global_privacy_hide_summary
            GlobalPrivacySetting.DISABLE_IPV6_DNS -> R.string.global_privacy_ipv6_summary
            GlobalPrivacySetting.REFERRER_HOST_POLICY -> R.string.global_privacy_referrer_summary
        })
        val pref = state.native?.settings?.get(setting) ?: return description
        val source = getString(when {
            pref.locked -> R.string.global_privacy_locked
            pref.hasUserValue -> R.string.global_privacy_custom
            else -> R.string.global_privacy_default
        })
        return getString(R.string.global_privacy_value_summary, description, valueLabel(setting, pref.value), valueLabel(setting, pref.defaultValue), source)
    }
}
