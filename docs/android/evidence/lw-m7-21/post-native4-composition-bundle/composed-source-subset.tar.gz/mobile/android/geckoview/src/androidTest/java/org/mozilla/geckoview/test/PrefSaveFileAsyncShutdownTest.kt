/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

package org.mozilla.geckoview.test

import android.util.Log
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.MediumTest
import androidx.test.platform.app.InstrumentationRegistry
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeTrue
import org.junit.BeforeClass
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Destructive native profile-service shutdown: run in a fresh instrumentation
 * process with this exact class selector and redoubtAllowProfileShutdown=true.
 * RuntimeCreator shares its runtime across classes, so a broad suite must skip
 * this class. A skip is pending shutdown coverage, never a successful check.
 * This tests the real preference observer's acknowledgment, not full app exit.
 */
@RunWith(AndroidJUnit4::class)
@MediumTest
class PrefSaveFileAsyncShutdownTest : BaseSessionTest() {
    companion object {
        @JvmStatic
        @BeforeClass
        fun requireIsolatedInvocation() {
            val args = InstrumentationRegistry.getArguments()
            assumeTrue(
                "Pending: requires an isolated shutdown-only instrumentation process",
                args.getString("redoubtAllowProfileShutdown") == "true" &&
                    args.getString("class") == PrefSaveFileAsyncShutdownTest::class.java.name,
            )
        }
    }

    @Test
    fun failedFinalSaveLeavesProfileOpenAndSuccessfulFinalSaveClosesIt() {
        val value = sessionRule.evaluateExtensionJS(
            "return JSON.stringify(await browser.test.runPrefSaveFileAsyncIOTest('shutdown', true));",
        ) as String
        Log.i("PrefSaveFileAsyncTest", value)
        val result = JSONObject(value)
        assertEquals("shutdown", result.getString("scenario"))
        assertEquals(result.getString("profile") + "/prefs.js", result.getString("currentFile"))
        for (name in listOf("failedSave", "failedSuspend", "failedShutdown")) {
            assertFalse("$name reports real I/O failure", result.getJSONObject(name).getBoolean("resolved"))
        }
        assertTrue(result.getBoolean("failureTargetIsDirectory"))
        assertEquals("after-disk-error", result.getString("memoryValueAfterFailure"))
        assertTrue("Failed shutdown did not close profile", result.getJSONObject("retry").getBoolean("resolved"))
        assertEquals("after-disk-error", result.getString("retryValue"))
        assertFalse(result.getBoolean("dirtyAfterRetry"))
        assertEquals("shutdown-final", result.getString("finalValue"))
        val afterShutdown = result.getJSONObject("afterShutdown")
        assertFalse(afterShutdown.getBoolean("resolved"))
        assertEquals(
            result.getLong("expectedShutdownError"),
            afterShutdown.getJSONObject("error").getLong("result"),
        )
    }
}
