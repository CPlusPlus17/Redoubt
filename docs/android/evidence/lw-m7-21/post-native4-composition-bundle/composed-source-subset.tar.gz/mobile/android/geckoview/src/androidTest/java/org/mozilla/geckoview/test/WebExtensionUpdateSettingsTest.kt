/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
package org.mozilla.geckoview.test

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.MediumTest
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

/** Separate instrumented test profile; production restart/network acceptance is additional. */
@RunWith(AndroidJUnit4::class)
@MediumTest
class WebExtensionUpdateSettingsTest : BaseSessionTest() {
    private val controller get() = sessionRule.runtime.webExtensionController

    @Test
    fun combinedSettingWritesBothPrefsAndMixedStateIsUnchecked() {
        sessionRule.setPrefsUntilTestEnd(
            mapOf("extensions.update.enabled" to true, "extensions.update.autoUpdateDefault" to false),
        )
        val mixed = sessionRule.waitForResult(controller.getAutomaticUpdateSettings())
        assertTrue(mixed.updateEnabled)
        assertFalse(mixed.autoUpdateDefault)
        assertFalse(mixed.enabled)
        assertFalse(mixed.locked)
        val enabled = sessionRule.waitForResult(controller.setAutomaticUpdateSettings(true))
        assertTrue(enabled.enabled && enabled.updateEnabled && enabled.autoUpdateDefault)
        val disabled = sessionRule.waitForResult(controller.setAutomaticUpdateSettings(false))
        assertFalse(disabled.enabled || disabled.updateEnabled || disabled.autoUpdateDefault)
        val read = sessionRule.waitForResult(controller.getAutomaticUpdateSettings())
        assertFalse(read.enabled || read.updateEnabled || read.autoUpdateDefault)
    }

    @Test
    fun concurrentChoicesCompleteInNativeQueueOrder() {
        sessionRule.setPrefsUntilTestEnd(
            mapOf("extensions.update.enabled" to true, "extensions.update.autoUpdateDefault" to true),
        )
        val off = controller.setAutomaticUpdateSettings(false)
        val on = controller.setAutomaticUpdateSettings(true)
        assertFalse(sessionRule.waitForResult(off).enabled)
        assertTrue(sessionRule.waitForResult(on).enabled)
        val current = sessionRule.waitForResult(controller.getAutomaticUpdateSettings())
        assertTrue(current.enabled && current.updateEnabled && current.autoUpdateDefault)
    }
}
