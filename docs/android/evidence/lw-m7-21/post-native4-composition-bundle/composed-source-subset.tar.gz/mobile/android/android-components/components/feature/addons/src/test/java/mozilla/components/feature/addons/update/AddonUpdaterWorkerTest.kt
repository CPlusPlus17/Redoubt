/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package mozilla.components.feature.addons.update

import android.content.Context
import androidx.concurrent.futures.await
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.work.ListenableWorker
import androidx.work.WorkerFactory
import androidx.work.WorkerParameters
import androidx.work.testing.TestListenableWorkerBuilder
import junit.framework.TestCase.assertEquals
import junit.framework.TestCase.assertTrue
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.runTest
import mozilla.components.browser.state.store.BrowserStore
import mozilla.components.concept.engine.Engine
import mozilla.components.concept.engine.webextension.WebExtension
import mozilla.components.concept.engine.webextension.WebExtensionException
import mozilla.components.feature.addons.AddonManager
import mozilla.components.support.test.any
import mozilla.components.support.test.argumentCaptor
import mozilla.components.support.test.mock
import mozilla.components.support.test.robolectric.testContext
import mozilla.components.support.test.whenever
import mozilla.components.support.webextensions.WebExtensionSupport
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.ArgumentMatchers.anyString
import org.mockito.Mockito.never
import org.mockito.Mockito.doReturn
import org.mockito.Mockito.spy
import org.mockito.Mockito.verify

@RunWith(AndroidJUnit4::class)
class AddonUpdaterWorkerTest {

    private val testDispatcher = StandardTestDispatcher()

    @Before
    fun setUp() {
        GlobalAddonDependencyProvider.addonManager = null

        initWebExtensionSupport()
    }

    private fun initWebExtensionSupport() {
        val store = BrowserStore()
        val engine: Engine = mock()
        val extension: WebExtension = mock()
        whenever(extension.id).thenReturn("addonId")
        val callbackCaptor = argumentCaptor<((List<WebExtension>) -> Unit)>()
        whenever(engine.listInstalledWebExtensions(callbackCaptor.capture(), any())).thenAnswer {
            callbackCaptor.value.invoke(listOf(extension))
        }
        WebExtensionSupport.initialize(engine, store)
    }

    private fun createWorker(addonId: String, tags: List<String> = emptyList()): AddonUpdaterWorker {
        return TestListenableWorkerBuilder<AddonUpdaterWorker>(testContext)
            .setInputData(AddonUpdaterWorker.createWorkerData(addonId))
            .setTags(tags)
            .setWorkerFactory(object : WorkerFactory() {
                override fun createWorker(
                    appContext: Context,
                    workerClassName: String,
                    workerParameters: WorkerParameters,
                ): ListenableWorker {
                    return spy(AddonUpdaterWorker(appContext, workerParameters, testDispatcher))
                }
            })
            .build()
    }

    @After
    fun after() {
        GlobalAddonDependencyProvider.addonManager = null
    }

    @Test
    fun `doWork - will return Result_success when SuccessfullyUpdated`() = runTest(testDispatcher) {
        val updateAttemptStorage = mock<DefaultAddonUpdater.UpdateAttemptStorage>()
        val addonId = "addonId"
        val onFinishCaptor = argumentCaptor<((AddonUpdater.Status) -> Unit)>()
        val addonManager = mock<AddonManager>()
        val worker = createWorker(addonId)

        doReturn(updateAttemptStorage).`when`(worker).updateAttemptStorage
        GlobalAddonDependencyProvider.initialize(addonManager, mock())

        whenever(addonManager.updateAddonAutomatically(anyString(), onFinishCaptor.capture())).then {
            onFinishCaptor.value.invoke(AddonUpdater.Status.SuccessfullyUpdated)
        }

        doReturn(this).`when`(worker).attemptScope

        val result = worker.startWork().await()

        assertEquals(ListenableWorker.Result.success(), result)
        verify(worker).saveUpdateAttempt(addonId, AddonUpdater.Status.SuccessfullyUpdated)
    }

    @Test
    fun `doWork - will return Result_success when NoUpdateAvailable`() = runTest(testDispatcher) {
        val addonId = "addonId"
        val onFinishCaptor = argumentCaptor<((AddonUpdater.Status) -> Unit)>()
        val addonManager = mock<AddonManager>()
        val worker = createWorker(addonId)

        GlobalAddonDependencyProvider.initialize(addonManager, mock())

        whenever(addonManager.updateAddonAutomatically(anyString(), onFinishCaptor.capture())).then {
            onFinishCaptor.value.invoke(AddonUpdater.Status.NoUpdateAvailable)
        }

        val result = worker.startWork().await()

        assertEquals(ListenableWorker.Result.success(), result)
    }

    @Test
    fun `doWork - will return Result_failure when NotInstalled`() = runTest(testDispatcher) {
        val addonId = "addonId"
        val onFinishCaptor = argumentCaptor<((AddonUpdater.Status) -> Unit)>()
        val addonManager = mock<AddonManager>()
        val worker = createWorker(addonId)

        GlobalAddonDependencyProvider.initialize(addonManager, mock())

        whenever(addonManager.updateAddonAutomatically(anyString(), onFinishCaptor.capture())).then {
            onFinishCaptor.value.invoke(AddonUpdater.Status.NotInstalled)
        }

        val result = worker.startWork().await()

        assertEquals(ListenableWorker.Result.failure(), result)
    }

    @Test
    fun `doWork - will return Result_failure when an Error happens`() = runTest(testDispatcher) {
        val updateAttemptStorage = mock<DefaultAddonUpdater.UpdateAttemptStorage>()
        val addonId = "addonId"
        val onFinishCaptor = argumentCaptor<((AddonUpdater.Status) -> Unit)>()
        val addonManager = mock<AddonManager>()
        val worker = createWorker(addonId)

        val exception = WebExtensionException(Exception())
        worker.updateAttemptStorage = updateAttemptStorage

        GlobalAddonDependencyProvider.initialize(addonManager, mock())

        whenever(addonManager.updateAddonAutomatically(anyString(), onFinishCaptor.capture())).then {
            onFinishCaptor.value.invoke(AddonUpdater.Status.Error("error", exception))
        }

        val result = worker.startWork().await()

        assertEquals(ListenableWorker.Result.failure(), result)
        updateAttemptStorage.saveOrUpdate(any())
    }

    @Test
    fun `doWork - will try pass any exceptions to the crashReporter`() = runTest(testDispatcher) {
        val addonId = "addonId"
        val onFinishCaptor = argumentCaptor<((AddonUpdater.Status) -> Unit)>()
        val addonManager = mock<AddonManager>()
        val worker = createWorker(addonId)

        var crashWasReported = false
        val crashReporter: ((Throwable) -> Unit) = { _ ->
            crashWasReported = true
        }

        GlobalAddonDependencyProvider.initialize(addonManager, mock(), crashReporter)
        GlobalAddonDependencyProvider.addonManager = null

        whenever(addonManager.updateAddonAutomatically(anyString(), onFinishCaptor.capture())).then {
            onFinishCaptor.value.invoke(AddonUpdater.Status.Error("error", Exception()))
        }

        val result = worker.startWork().await()

        assertEquals(ListenableWorker.Result.failure(), result)
        assertTrue(crashWasReported)
    }
    @Test
    fun `restored periodic work uses automatic path and explicit work uses manual path`() = runTest(testDispatcher) {
        val manager = mock<AddonManager>()
        val automatic = argumentCaptor<((AddonUpdater.Status) -> Unit)>()
        val manual = argumentCaptor<((AddonUpdater.Status) -> Unit)>()
        GlobalAddonDependencyProvider.initialize(manager, mock())
        whenever(manager.updateAddonAutomatically(anyString(), automatic.capture())).then {
            automatic.value(AddonUpdater.Status.NoUpdateAvailable)
        }
        whenever(manager.updateAddon(anyString(), manual.capture())).then {
            manual.value(AddonUpdater.Status.NoUpdateAvailable)
        }
        val restored = createWorker("restored", listOf(DefaultAddonUpdater.WORK_TAG_PERIODIC))
        doReturn(this).`when`(restored).attemptScope
        restored.updateAttemptStorage = mock()
        assertEquals(ListenableWorker.Result.success(), restored.startWork().await())
        verify(manager).updateAddonAutomatically(org.mockito.ArgumentMatchers.eq("restored"), any())
        verify(manager, never()).updateAddon(org.mockito.ArgumentMatchers.eq("restored"), any())

        val explicit = createWorker("explicit", listOf(DefaultAddonUpdater.WORK_TAG_IMMEDIATE))
        doReturn(this).`when`(explicit).attemptScope
        explicit.updateAttemptStorage = mock()
        assertEquals(ListenableWorker.Result.success(), explicit.startWork().await())
        verify(manager).updateAddon(org.mockito.ArgumentMatchers.eq("explicit"), any())
        verify(manager, never()).updateAddonAutomatically(org.mockito.ArgumentMatchers.eq("explicit"), any())
    }

}
