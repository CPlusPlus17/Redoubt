/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
package mozilla.components.browser.engine.gecko.preferences

import android.os.Looper
import mozilla.components.concept.engine.preferences.GlobalPrivacyChangeResult
import mozilla.components.concept.engine.preferences.GlobalPrivacySaveStatus
import mozilla.components.concept.engine.preferences.GlobalPrivacySetting
import mozilla.components.concept.engine.preferences.GlobalPrivacyState
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.mozilla.gecko.util.GeckoBundle
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoGlobalPrivacyController as Native
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows.shadowOf

@RunWith(RobolectricTestRunner::class)
class GeckoGlobalPrivacyControllerTest {
    private fun stateBundle(locked: Boolean = false, unconfirmed: Boolean = false): GeckoBundle = GeckoBundle().apply {
        putBundleArray("settings", GlobalPrivacySetting.entries.map { key -> GeckoBundle().apply {
            putString("id", key.id); putString("type", if (key.isBoolean) "bool" else "int")
            putBoolean("available", true); putBoolean("hasDefault", true); putBoolean("hasUser", true)
            putBoolean("locked", locked); putBoolean("userValueKnown", !locked)
            putBoolean("persistenceUnconfirmed", unconfirmed); putInt("value", 1); putInt("defaultValue", 0)
            if (locked) putString("userValue", null) else putInt("userValue", 1)
        } }.toTypedArray())
        putBundle("context", GeckoBundle())
    }
    // Exercise the real GV bundle parser without starting the native runtime.
    private inline fun <reified T> parse(bundle: GeckoBundle): T = T::class.java.getDeclaredConstructor(GeckoBundle::class.java)
        .apply { isAccessible = true }.newInstance(bundle)
    private fun resultBundle(status: String, unconfirmed: Boolean = false) = GeckoBundle().apply {
        putString("status", status); putString("reason", if (unconfirmed) "save-failed" else "")
        putBundle("state", stateBundle(unconfirmed = unconfirmed))
    }
    private inner class Api : NativeGlobalPrivacyApi {
        var calls = 0; var lastId: String? = null; var lastValue: Boolean? = null
        var locked = false; var unconfirmed = false; var throwOnRead = false; var rejectRead = false
        override fun read(): GeckoResult<Native.State> {
            calls++
            if (throwOnRead) error("dispatch failed")
            if (rejectRead) return GeckoResult.fromException(IllegalStateException("native read failed"))
            return GeckoResult.fromValue(parse(stateBundle(locked)))
        }
        override fun setBoolean(id: String, value: Boolean): GeckoResult<Native.ChangeResult> {
            calls++; lastId = id; lastValue = value
            return GeckoResult.fromValue(parse(resultBundle(if (unconfirmed) "unconfirmed" else "saved", unconfirmed)))
        }
        override fun setReferrerPolicy(value: Int): GeckoResult<Native.ChangeResult> = error("not used")
        override fun reset(id: String): GeckoResult<Native.ChangeResult> {
            calls++; lastId = id; return GeckoResult.fromValue(parse(resultBundle("saved")))
        }
    }

    @Test fun `locked actual GV state preserves hidden user uncertainty and enum one`() {
        val api = Api().apply { locked = true }; var state: GlobalPrivacyState? = null
        GeckoGlobalPrivacyController(api).read({ state = it }, { throw it }); shadowOf(Looper.getMainLooper()).idle()
        val preference = state!!.settings.getValue(GlobalPrivacySetting.REFERRER_HOST_POLICY)
        assertEquals(1, preference.value); assertTrue(preference.locked); assertTrue(preference.hasUserValue)
        assertFalse(preference.userValueKnown); assertNull(preference.userValue)
    }
    @Test fun `wrong boolean key is rejected before any native call`() {
        val api = Api(); var failure: Throwable? = null
        GeckoGlobalPrivacyController(api).setBoolean(GlobalPrivacySetting.REFERRER_HOST_POLICY, true, { fail("must reject") }, { failure = it })
        assertEquals(0, api.calls); assertTrue(failure is IllegalArgumentException)
    }
    @Test fun `native failed save is a typed unconfirmed result with actual state`() {
        val api = Api().apply { unconfirmed = true }; var result: GlobalPrivacyChangeResult? = null
        GeckoGlobalPrivacyController(api).setBoolean(GlobalPrivacySetting.RESIST_FINGERPRINTING, false, { result = it }, { throw it })
        shadowOf(Looper.getMainLooper()).idle()
        assertEquals("rfp", api.lastId); assertEquals(false, api.lastValue)
        assertEquals(GlobalPrivacySaveStatus.UNCONFIRMED, result!!.status)
        assertTrue(result!!.state.settings.getValue(GlobalPrivacySetting.RESIST_FINGERPRINTING).persistenceUnconfirmed)
    }
    @Test fun `synchronous and asynchronous native failures both reach the error callback`() {
        for (synchronous in listOf(false, true)) {
            val api = Api().apply { throwOnRead = synchronous; rejectRead = !synchronous }; var failure: Throwable? = null
            GeckoGlobalPrivacyController(api).read({ fail("must fail") }, { failure = it }); shadowOf(Looper.getMainLooper()).idle()
            assertNotNull(failure)
        }
    }
    @Test fun `reset delegates exact native key and maps the result instead of rewriting a default`() {
        val api = Api(); var result: GlobalPrivacyChangeResult? = null
        GeckoGlobalPrivacyController(api).reset(GlobalPrivacySetting.WEBGL_HIDE_POPUP, { result = it }, { throw it })
        shadowOf(Looper.getMainLooper()).idle()
        assertEquals("webglHide", api.lastId); assertEquals(GlobalPrivacySaveStatus.SAVED, result!!.status)
    }
}
