/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
package org.mozilla.fenix.settings.search

import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.runBlocking
import mozilla.components.concept.fetch.Client
import mozilla.components.concept.fetch.MutableHeaders
import mozilla.components.concept.fetch.Request
import mozilla.components.concept.fetch.Response
import mozilla.components.feature.fxsuggest.FxSuggestAdmission
import mozilla.components.feature.fxsuggest.FxSuggestChoices
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import org.junit.runner.RunWith
import java.io.IOException
import java.io.InputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

@RunWith(AndroidJUnit4::class)
class SuggestDataInstallerTest {
    private val attachment = SuggestDataAttachment("fixture", "https://firefox-settings-attachments.cdn.mozilla.net/fixture", 3,
        "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad")
    private val dataset = SuggestDataSet("fixture", "quicksuggest-other", "wikipedia", "en", null, listOf(attachment))
    private class Backend : SuggestDataImport {
        val installs = AtomicInteger()
        val cancels = AtomicInteger()
        var received = emptyList<Pair<String, ByteArray>>()
        override fun cancel(): Boolean { cancels.incrementAndGet(); return true }
        override fun install(dataset: SuggestDataSet, attachments: List<Pair<String, ByteArray>>) {
            installs.incrementAndGet()
            received = attachments
        }
    }
    private fun client(block: (Request) -> Response) = object : Client() {
        override fun fetch(request: Request): Response = block(request)
    }
    private fun response(request: Request, content: String = "abc", status: Int = 200, url: String = request.url) =
        Response(url, status, MutableHeaders(), Response.Body(content.byteInputStream()))

    @After fun resetAdmission() { FxSuggestAdmission.configure { FxSuggestChoices() } }

    @Test
    fun `off admission leaves both backend factories untouched`() = runBlocking {
        val created = AtomicInteger()
        val installer = SuggestDataInstaller({ created.incrementAndGet(); error("client") }, { created.incrementAndGet(); error("native") }, { false })
        try { installer.install(dataset); fail("must reject off") } catch (_: CancellationException) { }
        assertEquals(0, created.get())
    }

    @Test
    fun `explicit download validates bytes and omits cookies redirects and referrer`() = runBlocking {
        val backend = Backend()
        val requests = mutableListOf<Request>()
        val installer = SuggestDataInstaller({ client { request -> requests += request; response(request) } }, { backend }, { true })
        installer.install(dataset)
        assertEquals(1, backend.installs.get())
        assertEquals(1, requests.size)
        assertEquals(Request.CookiePolicy.OMIT, requests.single().cookiePolicy)
        assertEquals(Request.Redirect.MANUAL, requests.single().redirect)
        assertEquals(null, requests.single().referrerUrl)
        assertFalse(requests.single().useCaches)
        assertArrayEquals("abc".toByteArray(), backend.received.single().second)
    }

    @Test
    fun `bad hash truncation oversize redirect and error status never reach import`() = runBlocking {
        for (variant in 0..4) {
            val backend = Backend()
            val requests = AtomicInteger()
            val installer = SuggestDataInstaller({ client { request ->
                requests.incrementAndGet()
                when (variant) {
                    0 -> response(request, "abd")
                    1 -> response(request, "ab")
                    2 -> response(request, "abcd")
                    3 -> response(request, url = "https://example.org/redirect")
                    else -> response(request, status = 302)
                }
            } }, { backend }, { true })
            try { installer.install(dataset); fail("must reject invalid response") } catch (_: IOException) { }
            assertEquals(0, backend.installs.get())
            assertEquals(1, requests.get())
        }
    }

    @Test
    fun `turning off after response prevents import and later attachment requests`() = runBlocking {
        val allowed = AtomicBoolean(true)
        val backend = Backend()
        val requests = AtomicInteger()
        val installer = SuggestDataInstaller({ client { request -> requests.incrementAndGet(); allowed.set(false); response(request) } }, { backend }, allowed::get)
        try { installer.install(dataset.copy(attachments = listOf(attachment, attachment.copy(recordId = "second")))); fail("must stop") } catch (_: CancellationException) { }
        assertEquals(1, requests.get())
        assertEquals(0, backend.installs.get())
    }

    @Test
    fun `off then on cannot revive a retained earlier admission snapshot`() = runBlocking {
        FxSuggestAdmission.configure { FxSuggestChoices() }
        val snapshot = FxSuggestAdmission.snapshot()
        val backend = Backend()
        val installer = SuggestDataInstaller({ client { request ->
            FxSuggestAdmission.configure { FxSuggestChoices(false, false, false, false) }
            FxSuggestAdmission.configure { FxSuggestChoices() }
            response(request)
        } }, { backend }, { FxSuggestAdmission.isCurrent(snapshot) })
        try { installer.install(dataset); fail("must drop stale response") } catch (_: CancellationException) { }
        assertEquals(0, backend.installs.get())
    }

    @Test
    fun `cancellation during backend construction still cancels before network construction`() = runBlocking {
        val constructing = CountDownLatch(1)
        val release = CountDownLatch(1)
        val backend = Backend()
        val networkConstructed = AtomicInteger()
        val installer = SuggestDataInstaller({ networkConstructed.incrementAndGet(); error("client must stay lazy") }, {
            constructing.countDown()
            check(release.await(5, TimeUnit.SECONDS))
            backend
        }, { true })
        val job = async(Dispatchers.Default) { installer.install(dataset) }
        assertTrue(constructing.await(5, TimeUnit.SECONDS))
        assertTrue(installer.cancel())
        release.countDown()
        try { job.await(); fail("must cancel") } catch (_: CancellationException) { }
        assertEquals(0, networkConstructed.get())
        assertEquals(0, backend.installs.get())
        assertTrue(backend.cancels.get() > 0)
    }
    @Test
    fun `stream close failure cannot bypass native cancellation or cleanup`() = runBlocking {
        val reading = CountDownLatch(1)
        val release = CountDownLatch(1)
        val backend = Backend()
        val installer = SuggestDataInstaller({ client { request ->
            val stream = object : InputStream() {
                override fun read(): Int {
                    reading.countDown()
                    check(release.await(5, TimeUnit.SECONDS))
                    return -1
                }
                override fun close() { throw IOException("close failed") }
            }
            Response(request.url, 200, MutableHeaders(), Response.Body(stream))
        } }, { backend }, { true })
        val job = async(Dispatchers.Default) { runCatching { installer.install(dataset) } }
        assertTrue(reading.await(5, TimeUnit.SECONDS))
        assertTrue(installer.cancel())
        assertTrue(backend.cancels.get() > 0)
        release.countDown()
        assertTrue(job.await().isFailure)
        assertEquals(0, backend.installs.get())
        assertTrue(installer.cancel())
    }

}
