/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.fenix.settings.search

import android.content.SharedPreferences
import android.text.format.Formatter
import androidx.appcompat.app.AlertDialog
import androidx.core.os.ConfigurationCompat
import androidx.lifecycle.lifecycleScope
import androidx.preference.Preference
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import mozilla.appservices.remotesettings.PinnedSuggestAttachment
import mozilla.appservices.remotesettings.SuggestDataInstallToken
import mozilla.appservices.suggest.SuggestIngestionConstraints
import mozilla.appservices.suggest.SuggestionProvider
import mozilla.components.feature.fxsuggest.FxSuggestAdmission
import mozilla.components.support.locale.LocaleManager
import org.mozilla.fenix.HomeActivity
import org.mozilla.fenix.R
import org.mozilla.fenix.ext.components
import org.mozilla.fenix.utils.isLargeScreenSize

/** Explicit data actions alongside the default-off Suggest controls. */
internal class SuggestDataPreferences(private val fragment: SearchEngineFragment) {
    private val context = fragment.requireContext()
    private val preferences = context.components.settings.preferences
    private val catalog by lazy {
        context.assets.open(SuggestDataCatalog.ASSET).use { SuggestDataCatalog.parse(it.readBytes()) }
    }
    private val web = requireNotNull(fragment.findPreference<Preference>(WEB_KEY))
    private val sponsored = requireNotNull(fragment.findPreference<Preference>(SPONSORED_KEY))
    private var installJob: Job? = null
    private var statusJob: Job? = null
    private var installer: SuggestDataInstaller? = null
    private var progress: AlertDialog? = null
    private var installSnapshot: FxSuggestAdmission.Snapshot? = null
    @Volatile private var resumed = false
    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        installSnapshot?.let {
            if (!FxSuggestAdmission.isCurrent(it)) {
                installer?.cancel()
                installJob?.cancel()
            }
        }
        if (resumed) fragment.lifecycleScope.launch { refresh() }
    }

    init {
        web.setOnPreferenceClickListener { choose("wikipedia"); true }
        sponsored.setOnPreferenceClickListener { choose("amp"); true }
    }

    fun onResume() {
        resumed = true
        preferences.registerOnSharedPreferenceChangeListener(listener)
        refresh()
    }

    fun onStop() {
        resumed = false
        preferences.unregisterOnSharedPreferenceChangeListener(listener)
        installer?.cancel()
        installJob?.cancel()
        statusJob?.cancel()
        progress?.dismiss()
        progress = null
    }

    private fun displayLocale() =
        ConfigurationCompat.getLocales(context.resources.configuration).get(0) ?: LocaleManager.getSystemDefault()

    private fun inPrivateMode(): Boolean =
        (fragment.activity as? HomeActivity)?.browsingModeManager?.mode?.isPrivate != false

    private fun allowed(kind: String, snapshot: FxSuggestAdmission.Snapshot): Boolean =
        resumed && !inPrivateMode() && FxSuggestAdmission.isCurrent(snapshot) && snapshot.choices.enabled &&
            if (kind == "wikipedia") snapshot.choices.web else snapshot.choices.sponsored && !context.isLargeScreenSize()

    private fun refresh() {
        val snapshot = FxSuggestAdmission.snapshot()
        val busy = installJob != null
        web.isEnabled = !busy && allowed("wikipedia", snapshot)
        sponsored.isEnabled = !busy && allowed("amp", snapshot)
        web.setSummary(if (inPrivateMode()) R.string.suggest_data_private else R.string.suggest_data_web_available)
        sponsored.setSummary(
            when {
                inPrivateMode() -> R.string.suggest_data_private
                context.isLargeScreenSize() -> R.string.suggest_data_no_tablet
                else -> R.string.suggest_data_regions_available
            },
        )
        if (installJob?.isCancelled == true) {
            web.setSummary(R.string.suggest_data_finishing)
            sponsored.setSummary(R.string.suggest_data_finishing)
        }
        statusJob?.cancel()
        if (busy || !snapshot.choices.localEnabled || inPrivateMode()) return
        statusJob = fragment.lifecycleScope.launch {
            for (kind in listOf("wikipedia", "amp")) {
                if (!allowed(kind, snapshot)) continue
                try {
                    val available = catalog.datasets.filter { it.kind == kind }
                    val installed = withContext(Dispatchers.IO) {
                        if (!allowed(kind, snapshot)) return@withContext null
                        context.components.remoteSettingsService.value.remoteSettingsService
                            .makeClient(available.first().collection).installedPinnedSuggestData()
                    }
                    if (!allowed(kind, snapshot)) continue
                    available.firstOrNull { it.id == installed }?.let { dataset ->
                        (if (kind == "wikipedia") web else sponsored).summary = context.getString(
                            R.string.suggest_data_installed, dataset.label(displayLocale()),
                        )
                    }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (_: Exception) {
                    if (allowed(kind, snapshot)) (if (kind == "wikipedia") web else sponsored)
                        .setSummary(R.string.suggest_data_status_failed)
                }
            }
        }
    }

    private fun choose(kind: String) {
        val snapshot = FxSuggestAdmission.snapshot()
        if (!allowed(kind, snapshot) || installJob != null) return
        val available = try {
            // LocaleManager can override Locale.getDefault at app startup. The
            // saved app language is the selection hint; it is not a data gate.
            val browserLocale = LocaleManager.getCurrentLocale(context) ?: LocaleManager.getSystemDefault()
            val preferred = catalog.preferred(kind, browserLocale)
            catalog.datasets.filter { it.kind == kind }.sortedWith(
                compareBy<SuggestDataSet> { it.id != preferred?.id }.thenBy { it.label(browserLocale) },
            )
        } catch (_: Exception) {
            showFailure()
            return
        }
        val displayLocale = displayLocale()
        AlertDialog.Builder(context)
            .setTitle(if (kind == "wikipedia") R.string.suggest_data_choose_language else R.string.suggest_data_choose_region)
            .setItems(available.map { "${it.label(displayLocale)} (${Formatter.formatFileSize(context, it.downloadBytes)})" }.toTypedArray()) { _, index ->
                val dataset = available[index]
                if (!allowed(kind, snapshot)) return@setItems
                AlertDialog.Builder(context)
                    .setTitle(dataset.label(displayLocale))
                    .setMessage(context.getString(R.string.suggest_data_download_disclosure, Formatter.formatFileSize(context, dataset.downloadBytes)))
                    .setNegativeButton(android.R.string.cancel, null)
                    .setPositiveButton(R.string.suggest_data_download) { _, _ -> start(dataset, snapshot) }
                    .show()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun start(dataset: SuggestDataSet, snapshot: FxSuggestAdmission.Snapshot) {
        if (!allowed(dataset.kind, snapshot) || installJob != null) return
        installSnapshot = snapshot
        val attempt = SuggestDataInstaller(
            clientFactory = { context.components.core.client },
            importFactory = { selected ->
                val service = context.components.remoteSettingsService.value.remoteSettingsService
                check(service.clientUrl().trimEnd('/') == "https://firefox.settings.services.mozilla.com/v1")
                val client = service.makeClient(selected.collection)
                val token = SuggestDataInstallToken()
                object : SuggestDataImport {
                    override fun cancel(): Boolean = token.cancel()
                    override fun install(dataset: SuggestDataSet, attachments: List<Pair<String, ByteArray>>) {
                        client.installPinnedSuggestData(
                            dataset.id, attachments.map { (id, bytes) -> PinnedSuggestAttachment(id, bytes) }, token,
                        )
                    }
                }
            },
            isAllowed = { allowed(dataset.kind, snapshot) },
        )
        installer = attempt
        progress = AlertDialog.Builder(context)
            .setMessage(R.string.suggest_data_downloading)
            .setCancelable(false)
            .setNegativeButton(android.R.string.cancel) { _, _ ->
                attempt.cancel()
                installJob?.cancel()
            }.show()
        installJob = fragment.lifecycleScope.launch {
            var imported = false
            try {
                attempt.install(dataset)
                imported = true
                if (allowed(dataset.kind, snapshot)) {
                    val provider = if (dataset.kind == "wikipedia") SuggestionProvider.WIKIPEDIA else SuggestionProvider.AMP
                    val ready = context.components.fxSuggest.storage.ingest(SuggestIngestionConstraints(providers = listOf(provider)))
                    if (!ready && allowed(dataset.kind, snapshot)) showFailure(dataSaved = true)
                }
            } catch (cancelled: CancellationException) {
                // Native publication may already have won. refresh() reads the
                // installed state; cancellation does not promise to retract it.
                throw cancelled
            } catch (_: Exception) {
                if (resumed) showFailure(dataSaved = imported)
            } finally {
                // Keep the attempt owned until blocking fetch/native cleanup
                // completes. A cancelled Job is not yet a finished operation.
                installer = null
                installSnapshot = null
                progress?.dismiss()
                progress = null
                installJob = null
                if (resumed) refresh()
            }
        }
        refresh()
    }

    private fun showFailure(dataSaved: Boolean = false) {
        if (resumed) AlertDialog.Builder(context)
            .setMessage(if (dataSaved) R.string.suggest_data_prepare_failed else R.string.suggest_data_failed)
            .setPositiveButton(android.R.string.ok, null).show()
    }

    companion object {
        const val WEB_KEY = "redoubt_suggest_web_data"
        const val SPONSORED_KEY = "redoubt_suggest_sponsored_data"
    }
}
