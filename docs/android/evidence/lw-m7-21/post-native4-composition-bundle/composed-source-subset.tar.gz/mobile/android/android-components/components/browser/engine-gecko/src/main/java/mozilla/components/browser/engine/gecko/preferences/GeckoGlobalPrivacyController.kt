/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package mozilla.components.browser.engine.gecko.preferences

import mozilla.components.concept.engine.preferences.CrossHostReferrerPolicy
import mozilla.components.concept.engine.preferences.GlobalPrivacyChangeResult
import mozilla.components.concept.engine.preferences.GlobalPrivacyContext
import mozilla.components.concept.engine.preferences.GlobalPrivacyController
import mozilla.components.concept.engine.preferences.GlobalPrivacyPreference
import mozilla.components.concept.engine.preferences.GlobalPrivacySaveStatus
import mozilla.components.concept.engine.preferences.GlobalPrivacySetting
import mozilla.components.concept.engine.preferences.GlobalPrivacyState
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoGlobalPrivacyController as NativeController

internal interface NativeGlobalPrivacyApi {
    fun read(): GeckoResult<NativeController.State>
    fun setBoolean(id: String, value: Boolean): GeckoResult<NativeController.ChangeResult>
    fun setReferrerPolicy(value: Int): GeckoResult<NativeController.ChangeResult>
    fun reset(id: String): GeckoResult<NativeController.ChangeResult>
}

private object DefaultNativeGlobalPrivacyApi : NativeGlobalPrivacyApi {
    override fun read() = NativeController.getState()
    override fun setBoolean(id: String, value: Boolean) = NativeController.setBoolean(id, value)
    override fun setReferrerPolicy(value: Int) = NativeController.setReferrerPolicy(value)
    override fun reset(id: String) = NativeController.reset(id)
}

/** Translates the native authoritative contract without caching or duplicating pref storage. */
internal class GeckoGlobalPrivacyController(
    private val native: NativeGlobalPrivacyApi = DefaultNativeGlobalPrivacyApi,
) : GlobalPrivacyController {
    override fun read(onSuccess: (GlobalPrivacyState) -> Unit, onError: (Throwable) -> Unit) {
        deliver({ native.read() }, { onSuccess(it.into()) }, onError)
    }

    override fun setBoolean(setting: GlobalPrivacySetting, value: Boolean, onResult: (GlobalPrivacyChangeResult) -> Unit, onError: (Throwable) -> Unit) {
        if (!setting.isBoolean) {
            onError(IllegalArgumentException("Referrer policy is not a boolean control"))
            return
        }
        deliver({ native.setBoolean(setting.id, value) }, { onResult(it.into()) }, onError)
    }

    override fun setReferrerPolicy(policy: CrossHostReferrerPolicy, onResult: (GlobalPrivacyChangeResult) -> Unit, onError: (Throwable) -> Unit) {
        deliver({ native.setReferrerPolicy(policy.value) }, { onResult(it.into()) }, onError)
    }

    override fun reset(setting: GlobalPrivacySetting, onResult: (GlobalPrivacyChangeResult) -> Unit, onError: (Throwable) -> Unit) {
        deliver({ native.reset(setting.id) }, { onResult(it.into()) }, onError)
    }
}

private fun NativeController.State.into() = GlobalPrivacyState(
    settings = settings.associate { entry ->
        val setting = GlobalPrivacySetting.entries.single { it.id == entry.id }
        setting to GlobalPrivacyPreference(
            value = entry.value.takeIf { entry.available },
            defaultValue = entry.defaultValue,
            userValue = entry.userValue,
            locked = entry.locked,
            hasUserValue = entry.hasUserValue,
            userValueKnown = entry.userValueKnown,
            persistenceUnconfirmed = entry.persistenceUnconfirmed,
        )
    },
    context = GlobalPrivacyContext(
        context.rfpPrivate, context.fingerprintingProtection, context.fingerprintingProtectionPrivate,
        context.rfpExemptions, context.fingerprintingOverrides, context.webglDisabled,
        context.referrerTrimming, context.dnsOverHttpsMode,
    ),
)

private fun NativeController.ChangeResult.into() = GlobalPrivacyChangeResult(
    status = when (status) {
        NativeController.ChangeResult.SAVED -> GlobalPrivacySaveStatus.SAVED
        NativeController.ChangeResult.REJECTED -> GlobalPrivacySaveStatus.REJECTED
        NativeController.ChangeResult.UNCONFIRMED -> GlobalPrivacySaveStatus.UNCONFIRMED
        NativeController.ChangeResult.SUPERSEDED -> GlobalPrivacySaveStatus.SUPERSEDED
        else -> error("Unknown native persistence status")
    },
    reason = reason,
    state = state.into(),
)

private fun <T : Any> deliver(request: () -> GeckoResult<T>, onSuccess: (T) -> Unit, onError: (Throwable) -> Unit) {
    try {
        request().then(
            { value ->
                try {
                    if (value == null) onError(IllegalStateException("Missing native privacy state")) else onSuccess(value)
                } catch (error: Exception) {
                    onError(error)
                }
                GeckoResult<Void>()
            },
            { error -> onError(error); GeckoResult<Void>() },
        )
    } catch (error: Exception) {
        onError(error)
    }
}
