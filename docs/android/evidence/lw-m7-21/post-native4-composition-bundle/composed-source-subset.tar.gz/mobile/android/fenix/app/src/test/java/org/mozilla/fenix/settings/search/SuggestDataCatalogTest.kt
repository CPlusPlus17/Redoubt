/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
package org.mozilla.fenix.settings.search

import androidx.test.ext.junit.runners.AndroidJUnit4
import mozilla.components.support.test.robolectric.testContext
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import java.util.Locale

@RunWith(AndroidJUnit4::class)
class SuggestDataCatalogTest {
    private fun bytes() = testContext.assets.open(SuggestDataCatalog.ASSET).use { it.readBytes() }

    @Test
    fun `production catalog exposes reviewed language and phone region choices`() {
        val catalog = SuggestDataCatalog.parse(bytes())
        assertEquals(21, catalog.datasets.count { it.kind == "wikipedia" })
        assertEquals(setOf("DE", "FR", "GB", "IT", "US"), catalog.datasets.filter { it.kind == "amp" }.map { it.country }.toSet())
        val german = catalog.datasets.single { it.id == "sponsored-suggestions-de-phone" }
        assertEquals(5, german.attachments.size)
        assertEquals(6957, german.attachments.first().size)
        assertEquals("041f91936d4a986593b1e4418b7553e4f54227a113d0fc13efee938e69921a09", german.attachments.first().sha256)
        assertTrue(catalog.datasets.all { d -> d.attachments.all { it.url.startsWith("https://firefox-settings-attachments.cdn.mozilla.net/main-workspace/quicksuggest-") } })
    }

    @Test
    fun `corrupt and truncated catalog cannot select any download`() {
        val original = bytes()
        val changed = original.copyOf().also { it[10] = (it[10].toInt() xor 1).toByte() }
        assertThrows(IllegalArgumentException::class.java) { SuggestDataCatalog.parse(changed) }
        assertThrows(IllegalArgumentException::class.java) { SuggestDataCatalog.parse(original.copyOf(original.size - 1)) }
    }

    @Test
    fun `language hint remains separate from actual region and does not mutate system locale`() {
        val catalog = SuggestDataCatalog.parse(bytes())
        val before = Locale.getDefault()
        assertEquals("data-wikipedia-de", catalog.preferred("wikipedia", Locale.forLanguageTag("de-CH"))?.id)
        assertNull(catalog.preferred("amp", Locale.forLanguageTag("de-CH")))
        assertNull(catalog.preferred("wikipedia", Locale.forLanguageTag("ja-JP")))
        assertEquals(before, Locale.getDefault())
    }
}
