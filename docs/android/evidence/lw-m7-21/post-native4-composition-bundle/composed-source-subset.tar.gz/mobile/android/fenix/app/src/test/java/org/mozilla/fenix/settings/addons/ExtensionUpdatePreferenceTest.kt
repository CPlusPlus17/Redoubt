/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
package org.mozilla.fenix.settings.addons

import androidx.preference.PreferenceManager
import androidx.preference.SwitchPreferenceCompat
import mozilla.components.support.test.robolectric.testContext
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.mozilla.fenix.R
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class ExtensionUpdatePreferenceTest {
    private class Gateway : ExtensionUpdatePreference.Gateway {
        data class Call(
            val enabled: Boolean?,
            val success: (ExtensionUpdatePreference.State) -> Unit,
            val error: () -> Unit,
        )
        val calls = mutableListOf<Call>()
        override fun read(onSuccess: (ExtensionUpdatePreference.State) -> Unit, onError: () -> Unit) {
            calls.add(Call(null, onSuccess, onError))
        }
        override fun write(
            enabled: Boolean,
            onSuccess: (ExtensionUpdatePreference.State) -> Unit,
            onError: () -> Unit,
        ) {
            calls.add(Call(enabled, onSuccess, onError))
        }
    }

    @Test
    fun `XML control is visible and never mirrors Gecko prefs in SharedPreferences`() {
        val manager = PreferenceManager(testContext)
        val screen = manager.inflateFromResource(testContext, R.xml.preferences, null)
        val preference = requireNotNull(screen.findPreference<SwitchPreferenceCompat>("automatic_extension_updates"))
        assertEquals(testContext.getString(R.string.extension_update_title), preference.title)
        assertTrue(preference.isVisible)
        assertFalse(preference.isPersistent)
        assertFalse(preference.isEnabled)
    }

    @Test
    fun `native state and locks determine UI with no write on refresh`() {
        val preference = SwitchPreferenceCompat(testContext)
        val gateway = Gateway()
        val binding = ExtensionUpdatePreference(preference, gateway)
        binding.refresh()
        assertFalse(preference.isEnabled)
        assertEquals(null, gateway.calls.single().enabled)
        gateway.calls.single().success(ExtensionUpdatePreference.State(true, true))
        assertTrue(preference.isChecked)
        assertFalse(preference.isEnabled)
        assertFalse(preference.callChangeListener(false))
        assertEquals(1, gateway.calls.size)
    }

    @Test
    fun `change waits for native durable completion and rejects duplicate clicks`() {
        val preference = SwitchPreferenceCompat(testContext)
        val gateway = Gateway()
        val binding = ExtensionUpdatePreference(preference, gateway)
        binding.refresh()
        gateway.calls.single().success(ExtensionUpdatePreference.State(true, false))
        assertFalse(preference.callChangeListener(false))
        assertTrue(preference.isChecked)
        assertFalse(preference.isEnabled)
        assertEquals(false, gateway.calls.last().enabled)
        assertFalse(preference.callChangeListener(true))
        binding.refresh()
        assertEquals(2, gateway.calls.size)
        gateway.calls.last().success(ExtensionUpdatePreference.State(false, false))
        assertFalse(preference.isChecked)
        assertTrue(preference.isEnabled)
    }

    @Test
    fun `save failure rereads actual native state and allows retry`() {
        val preference = SwitchPreferenceCompat(testContext)
        val gateway = Gateway()
        val binding = ExtensionUpdatePreference(preference, gateway)
        binding.refresh()
        gateway.calls.single().success(ExtensionUpdatePreference.State(true, false))
        preference.callChangeListener(false)
        gateway.calls.last().error()
        assertEquals(null, gateway.calls.last().enabled)
        gateway.calls.last().success(ExtensionUpdatePreference.State(true, false))
        assertTrue(preference.isChecked)
        assertTrue(preference.isEnabled)
        assertEquals(testContext.getString(R.string.extension_update_save_failed), preference.summary)
        preference.callChangeListener(false)
        assertEquals(false, gateway.calls.last().enabled)
    }

    @Test
    fun `late read and completion after view destruction cannot rewrite UI`() {
        val preference = SwitchPreferenceCompat(testContext)
        val gateway = Gateway()
        val binding = ExtensionUpdatePreference(preference, gateway)
        binding.refresh()
        val oldRead = gateway.calls.last()
        binding.refresh()
        gateway.calls.last().success(ExtensionUpdatePreference.State(false, false))
        oldRead.success(ExtensionUpdatePreference.State(true, false))
        assertFalse(preference.isChecked)
        preference.callChangeListener(true)
        val write = gateway.calls.last()
        binding.close()
        write.success(ExtensionUpdatePreference.State(true, false))
        assertFalse(preference.isChecked)
    }

    @Test
    fun `reopening settings retains native unconfirmed save state`() {
        val preference = SwitchPreferenceCompat(testContext)
        val gateway = Gateway()
        val binding = ExtensionUpdatePreference(preference, gateway)
        binding.refresh()
        gateway.calls.single().success(ExtensionUpdatePreference.State(true, false, false))
        assertTrue(preference.isChecked)
        assertEquals(testContext.getString(R.string.extension_update_save_failed), preference.summary)
    }

    @Test
    fun `read failure leaves setting disabled instead of inventing a default`() {
        val preference = SwitchPreferenceCompat(testContext)
        val gateway = Gateway()
        val binding = ExtensionUpdatePreference(preference, gateway)
        binding.refresh()
        gateway.calls.single().error()
        assertFalse(preference.isEnabled)
        assertEquals(testContext.getString(R.string.extension_update_unavailable), preference.summary)
    }
}
