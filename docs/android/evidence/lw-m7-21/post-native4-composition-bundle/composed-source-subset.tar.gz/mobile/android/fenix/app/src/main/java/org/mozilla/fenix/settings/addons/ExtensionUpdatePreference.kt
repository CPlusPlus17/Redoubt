/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

package org.mozilla.fenix.settings.addons

import androidx.preference.SwitchPreferenceCompat
import org.mozilla.fenix.R
import org.mozilla.geckoview.WebExtensionController

/** Bind a non-persistent switch to the authoritative native preference pair. */
internal class ExtensionUpdatePreference(
    private val preference: SwitchPreferenceCompat,
    private val gateway: Gateway,
) {
    internal data class State(val enabled: Boolean, val locked: Boolean, val saveConfirmed: Boolean = true)

    internal interface Gateway {
        fun read(onSuccess: (State) -> Unit, onError: () -> Unit)
        fun write(enabled: Boolean, onSuccess: (State) -> Unit, onError: () -> Unit)
    }

    internal class NativeGateway(private val controller: WebExtensionController) : Gateway {
        override fun read(onSuccess: (State) -> Unit, onError: () -> Unit) {
            controller.getAutomaticUpdateSettings().accept(
                { state ->
                    if (state == null) onError() else onSuccess(State(state.enabled, state.locked, state.saveConfirmed))
                },
                { onError() },
            )
        }

        override fun write(enabled: Boolean, onSuccess: (State) -> Unit, onError: () -> Unit) {
            controller.setAutomaticUpdateSettings(enabled).accept(
                { state ->
                    if (state == null) onError() else onSuccess(State(state.enabled, state.locked, state.saveConfirmed))
                },
                { onError() },
            )
        }
    }

    private var revision = 0
    private var closed = false
    private var saving = false

    init {
        preference.isPersistent = false
        preference.isEnabled = false
        preference.setOnPreferenceChangeListener { _, value ->
            if (value is Boolean && preference.isEnabled && !saving && !closed) {
                save(value)
            }
            // Show a new value only after the native write acknowledges it.
            false
        }
    }

    fun refresh() {
        if (!closed && !saving) readState(false)
    }

    private fun readState(failedSave: Boolean) {
        val request = ++revision
        preference.isEnabled = false
        gateway.read(
            { state ->
                if (!closed && revision == request) render(state, failedSave)
            },
            {
                if (!closed && revision == request) {
                    preference.isEnabled = false
                    preference.setSummary(R.string.extension_update_unavailable)
                }
            },
        )
    }

    private fun save(enabled: Boolean) {
        val request = ++revision
        saving = true
        preference.isEnabled = false
        gateway.write(
            enabled,
            { state ->
                if (!closed && revision == request) {
                    saving = false
                    render(state, false)
                }
            },
            {
                if (!closed && revision == request) {
                    saving = false
                    readState(true)
                }
            },
        )
    }

    private fun render(state: State, failedSave: Boolean) {
        preference.isChecked = state.enabled
        preference.isEnabled = !state.locked
        preference.setSummary(
            when {
                state.locked -> R.string.extension_update_locked
                failedSave || !state.saveConfirmed -> R.string.extension_update_save_failed
                else -> R.string.extension_update_summary
            },
        )
    }

    fun close() {
        closed = true
        revision++
        preference.onPreferenceChangeListener = null
        // Leaving Settings does not revoke an already accepted user choice.
        // Native persistence completes independently of this view's lifetime.
    }
}
